
// system headers
#include <afxwin.h>
#include <Tlhelp32.h>

// local headers
#include "an_applicationcontroller.h"

#pragma warning ( disable : 4311 )  // warning about DWORD -> LPVOID conversion 
#pragma warning ( disable : 4312 )  // warning about LPVOID -> DWORD conversion 




CAN_SyncVariable<CSemaphore,CAN_ApplicationController*> CAN_ApplicationController::s_applicationController;

CAN_ApplicationController::CAN_ApplicationController(void)
{
}

CAN_ApplicationController::~CAN_ApplicationController(void)
{
}

void CAN_ApplicationController::SetMaxProcessorPercentUsage( DWORD applicationID, int maxPercent, DWORD threadID )
{
	CSingleLock objectInstanceLocker( &s_applicationController, FALSE );
	objectInstanceLocker.Lock();

	try
	{
		// creating the object instance if it is not created
		if( NULL == s_applicationController.GetObjectItself() )
		{
			s_applicationController.GetObjectItself() = new CAN_ApplicationController();
		}

		// setting the limit to the requested application
		if( NULL != s_applicationController.GetObjectItself() )
		{
			objectInstanceLocker.Unlock();
			s_applicationController.GetObjectItself()->RemoveProcessorLimit( applicationID, threadID );
			s_applicationController.GetObjectItself()->SetProcessorLimit( applicationID, maxPercent, threadID );
		}
		else
            objectInstanceLocker.Unlock();
	}
	catch(...)
	{
		objectInstanceLocker.Unlock();
	}
}

void CAN_ApplicationController::RemoveProcessorLimit( DWORD applicationID, DWORD threadID )
{
	CSingleLock objectInstanceLocker( &s_applicationController, FALSE );
	objectInstanceLocker.Lock();

	// removing the limit from the application
	if( NULL != s_applicationController.GetObjectItself() )
	{
		Applications& applications = s_applicationController.GetObjectItself()->_applications;
		Applications::iterator application = applications.find( applicationID );
        if( applications.end() != application )
		{
			// removing from the applications list
			applications.erase( application );
			
			// removing the threadID from the exclusion list
			s_applicationController.GetObjectItself()->_threadIDListToExcludeFromSlowingDown.remove( threadID );
		}
	}

	objectInstanceLocker.Unlock();
}

void CAN_ApplicationController::SetProcessorLimit( DWORD applicationID, int maxPercent, DWORD threadID )
{
    // here we don't have to check the value for "s_applicationController", because this method will execute only if it is valid

	// adding new application for monitoring
	s_applicationController.GetObjectItself()->_threadIDListToExcludeFromSlowingDown.push_back( threadID );

	s_applicationController.GetObjectItself()->_applications.insert( ApplicationPair(applicationID,maxPercent) );
	AfxBeginThread( ApplicationMonitorThread, (LPVOID)applicationID );
}

UINT CAN_ApplicationController::ApplicationMonitorThread( LPVOID applicationToMonitor )
{
	DWORD applicationID = (DWORD)applicationToMonitor;

	CSingleLock objectInstanceLocker( &s_applicationController, FALSE );
	objectInstanceLocker.Lock();

	if( NULL == s_applicationController.GetObjectItself() )
	{
		objectInstanceLocker.Unlock();
		return 0;
	}

	// getting the thread id for current thread and setting it to be excluded from slowing down
	DWORD threadToExclude = GetCurrentThreadId();
	s_applicationController.GetObjectItself()->_threadIDListToExcludeFromSlowingDown.push_back( threadToExclude );

    objectInstanceLocker.Unlock();
	while( objectInstanceLocker.Lock(), (NULL != s_applicationController.GetObjectItself()) )
	{
		// checking if we still have to monitor the application
		Applications& applications = s_applicationController.GetObjectItself()->_applications;
		Applications::iterator application = applications.find( applicationID );
        if( applications.end() == application )
		{
			s_applicationController.GetObjectItself()->_threadIDListToExcludeFromSlowingDown.remove( threadToExclude );
			objectInstanceLocker.Unlock();
            return 0;
		}

		// getting here means we still have to limit the destination application
		ThreadHandleList threadHandleList;
		s_applicationController.GetObjectItself()->SlowDownApplicationsThreads( applicationID, threadHandleList );

		// getting the time out to wait for
		DWORD timeOut = 100 - application->second;
		if( timeOut < 0 )
			timeOut = 0;
		Sleep( timeOut  );

		// wakeup the sleeping threads
		s_applicationController.GetObjectItself()->UnSlowDownApplicationsThreads( applicationID, threadHandleList );

		objectInstanceLocker.Unlock();
		Sleep( timeOut/2  );
	}

	return 0;
}

void CAN_ApplicationController::SlowDownApplicationsThreads( DWORD applicationID, ThreadHandleList& threadHandleList )
{
	// getting the process' handle
	HANDLE processHandle = NULL;
	processHandle = OpenProcess( PROCESS_QUERY_INFORMATION , FALSE, applicationID );
	if( NULL != processHandle )
	{
		// finding all the threads from this application and slowing them down
		HANDLE processesSnapshot = CreateToolhelp32Snapshot( TH32CS_SNAPTHREAD, 0UL );
		if( INVALID_HANDLE_VALUE != processesSnapshot )
		{
			THREADENTRY32 threadEntry;
			threadEntry.dwSize = sizeof( THREADENTRY32 );
			if( TRUE == Thread32First(processesSnapshot, &threadEntry) )
			{
				do
				{
                    // suspending the thread
					if( (threadEntry.th32OwnerProcessID == applicationID) )
					{
						// checking if we have to skip this thread from sleeping
						ThreadIDList::const_iterator threadID = _threadIDListToExcludeFromSlowingDown.begin();
						ThreadIDList::const_iterator end = _threadIDListToExcludeFromSlowingDown.end();
						BOOL haveToSkip = FALSE;
						while( threadID != end )
						{
							if( *threadID == threadEntry.th32ThreadID  )
							{
								haveToSkip = true;
								break;
							}
							++threadID;
						}
						if( TRUE == haveToSkip )
							continue;         

						HANDLE threadHandle = NULL;
						threadHandle = OpenThread( THREAD_SUSPEND_RESUME, FALSE, threadEntry.th32ThreadID );
						if( NULL != threadHandle )
						{							
							SuspendThread( threadHandle );
							threadHandleList.push_back( threadHandle );
						}
					}
				} while( TRUE == Thread32Next( processesSnapshot, &threadEntry ) ); 
			}
			CloseHandle( processesSnapshot );
		}
		CloseHandle( processHandle );
	}
}

void CAN_ApplicationController::UnSlowDownApplicationsThreads( DWORD applicationID, ThreadHandleList& threadHandleList )
{
	ThreadHandleList::const_iterator threadHandle = threadHandleList.begin();
    ThreadHandleList::const_iterator end = threadHandleList.end();

	// resuming and removing all the handles
	while( threadHandle != end )
	{
		ResumeThread( *threadHandle );
		CloseHandle( *threadHandle );
		++threadHandle;
	}

    threadHandleList.clear();
}

void CAN_ApplicationController::CleanUp()
{
	CSingleLock objectInstanceLocker( &s_applicationController, FALSE );
	objectInstanceLocker.Lock();

	if( NULL != s_applicationController.GetObjectItself() )
	{
		// this will inform all the running monitoring threads to stop
		s_applicationController.GetObjectItself()->_applications.clear();

		// cleaning the exclude list
		s_applicationController.GetObjectItself()->_threadIDListToExcludeFromSlowingDown.clear();

		delete s_applicationController.GetObjectItself();
		s_applicationController.GetObjectItself() = NULL;
	}

	objectInstanceLocker.Unlock();
}
