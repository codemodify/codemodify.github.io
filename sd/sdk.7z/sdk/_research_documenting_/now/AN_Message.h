#pragma once


#include <afx.h>

/************************************************************************/
/* 
/*		The class is designed to store in an abstract form any data is needed
/*		through serialization mechanism
/*
/************************************************************************/
class CAN_Message
{

public:		// providing useful constructors
	CAN_Message();
	CAN_Message( const CAN_Message& theObjectToCopy );
	~CAN_Message();


public:		// overloading some stuff
	CAN_Message& operator = ( const CAN_Message& theObjectToCopy );
	operator CMemFile* () ;


public:		// class' interface
	void Empty();
	BOOL IsEmpty();


private:	// private stuff
	CMemFile _memoryFile;
};
