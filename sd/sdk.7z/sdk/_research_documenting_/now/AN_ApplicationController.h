#pragma once

// system headers
#include <map>
#include <afxmt.h>
#include <list>


// local headers
#include "AN_SyncVariable.h"



/************************************************************************/
/*		
/*		The class is designed to implement a mechanism of controlling the behavior for 
/*		a windows process(application).
/*
/*		The aim is to set a maximum percent limit of the processor that the application can take.
/*
/*		
/*		Ex of usage:
/*		CAN_ApplicationController::SetMaxProcessorPercentUsage( application.processID, 80, application.threadID );
/*		...
/*		// at this step it is assured that anything the application will do, it will not take 100% of the processor
/*		// the max it can take is "80%"
/*		...
/*		CAN_ApplicationController::RemoveProcessorLimit( application.processID );
/*		
/*
/************************************************************************/

class CAN_ApplicationController
{
public:

	~CAN_ApplicationController();

    // Limits an application to not take more processor percent usage than indicated
	//		"applicationID"		- is used to scan the application for threads, and manage them later
	//		"maxPercent"		- is the limit the application should take from processor
	//		"threadID"			- is the application's "main()" thread, used to be excluded from managed threads
	static void SetMaxProcessorPercentUsage( DWORD applicationID, int maxPercent, DWORD threadID );

	// Removes the limit for an application if any
	static void RemoveProcessorLimit( DWORD applicationID, DWORD threadID );

	// Removes all the limits, and stops all monitoring threads
	static void CleanUp();

private:

	// Disabling direct creation
	CAN_ApplicationController();




private:

	// The object's instance to work with
	static CAN_SyncVariable<CSemaphore,CAN_ApplicationController*> s_applicationController;





private:

	// The applications' attributes
    typedef std::map<DWORD, int> Applications;
	typedef std::pair<DWORD, int> ApplicationPair;
	Applications _applications;




private:

	// The list of threads ID to be excluded from management
	typedef std::list<DWORD> ThreadIDList;
	ThreadIDList _threadIDListToExcludeFromSlowingDown;




private:	// Internal stuff, used to manage states for running applications

	void SetProcessorLimit( DWORD applicationID, int maxPercent, DWORD threadID );

	// defines a list of thread handles, used to store current list of applications threads
	typedef std::list<HANDLE> ThreadHandleList;

	void SlowDownApplicationsThreads( DWORD applicationID, ThreadHandleList& threadHandleList );
	void UnSlowDownApplicationsThreads( DWORD applicationID, ThreadHandleList& threadHandleList );
	static UINT ApplicationMonitorThread(LPVOID applicationToMonitor);

};
