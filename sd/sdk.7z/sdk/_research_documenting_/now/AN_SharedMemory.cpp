#include "AN_SharedMemory.h"

// disabling the warning about conversion from hex-value to HANDLE ('type1' to 'type2')
#pragma warning ( disable : 4312 )
#pragma warning ( disable : 4018 )

CAN_SharedMemory::CAN_SharedMemory()
{
	_memoryHandle = NULL;
	_memoryData = NULL;
	_allocatedMemorySize = 0;
	_memoryIdentifier = "";
	_readOnly = TRUE;
}

CAN_SharedMemory::~CAN_SharedMemory()
{
	CleanInternalData();
}

BOOL CAN_SharedMemory::SharedMemoryExists( std::string memoryIdentifier )
{

    return FALSE;
}

BOOL	CAN_SharedMemory::CreateSharedMemory( std::string memoryIdentifier, DWORD memorySize, BOOL readOnly, LPSECURITY_ATTRIBUTES securityAttributes )
{
    // try to map this shared memory
	DWORD memoryProtection = readOnly ? PAGE_READONLY : PAGE_READWRITE;
	_memoryHandle = CreateFileMapping( (HANDLE)0xFFFFFFFF, securityAttributes, memoryProtection, 0, memorySize, memoryIdentifier.c_str() );
	if( NULL == _memoryHandle )
	{
        CleanInternalData();
		return FALSE;
	}

	// try to map the view of recently created memory for mapping
	DWORD memoryAccess = readOnly ? FILE_MAP_READ : FILE_MAP_WRITE;
	_memoryData = MapViewOfFile( _memoryHandle, memoryAccess, 0, 0, memorySize );
	if( NULL == _memoryData )
	{
        CleanInternalData();
		return FALSE;
	}

	// we've succeeded in previous steps, we need to store the params internally
    _allocatedMemorySize = memorySize;
	_memoryIdentifier = memoryIdentifier;
	_readOnly = readOnly;

	EmptyData();

	return TRUE;
}

BOOL	CAN_SharedMemory::OpenExistingSharedMemory( std::string memoryIdentifier, DWORD memorySize, BOOL readOnly )
{
	// try to access a claimed existing shared memory
	DWORD memoryAccess = readOnly ? FILE_MAP_READ : FILE_MAP_WRITE;
    _memoryHandle = OpenFileMapping( memoryAccess, 0, memoryIdentifier.c_str() );
	if( NULL == _memoryHandle )
	{
		CleanInternalData();
		return FALSE;
	}

	// try to map the view of recently opened memory ready for mapping
	_memoryData = MapViewOfFile( _memoryHandle, memoryAccess, 0, 0, memorySize );
	if( NULL == _memoryData )
	{
        CleanInternalData();
		return FALSE;
	}

	// we've succeeded in the previous steps, we can now init internal data
	_memoryIdentifier = memoryIdentifier;
	_allocatedMemorySize = memorySize;
	_readOnly = readOnly;

	EmptyData();

	return TRUE;
}

void CAN_SharedMemory::CleanInternalData()
{
	if( NULL != _memoryData )
	{
		FlushViewOfFile( _memoryData, 0 );
		UnmapViewOfFile( _memoryData );
	}

	if( NULL != _memoryHandle )
		CloseHandle( _memoryHandle );

	_memoryHandle = NULL;
	_memoryData = NULL;
	_allocatedMemorySize = 0;
	_memoryIdentifier = "";
	_readOnly = TRUE;
}

DWORD CAN_SharedMemory::GetAllocatedMemorySize() const
{
    return _allocatedMemorySize;
}

LPVOID CAN_SharedMemory::GetData() const
{
	LPVOID data = (LPVOID)( (DWORD*)_memoryData + sizeof(DWORD) );
	return data;
}

DWORD CAN_SharedMemory::GetDataSize()
{
	DWORD dataSize;
	memcpy( (void*)(&dataSize), _memoryData, sizeof(DWORD) );
	return dataSize;
}

BOOL CAN_SharedMemory::IsEmpty()
{
    return ( 0 == GetDataSize() );
}

void CAN_SharedMemory::SetDataSize( DWORD dataSize )
{
    memcpy( _memoryData, (void*)(&dataSize), sizeof(DWORD) );
}

void CAN_SharedMemory::EmptyData()
 {
     memset( _memoryData, 0, _allocatedMemorySize );
 }
