
// compilers directives
#pragma warning ( disable : 4244 )

// local headers
#include "AN_InterApplicationCommunicator.h"
#include "AN_SharedMemory.h"
#include "AN_Logger.h"

CAN_InterApplicationCommunicator::CAN_InterApplicationCommunicator( std::string localApplicationIdentifier, std::string remoteApplicationIdentifier )
{

	_localApplicationIdentifier = localApplicationIdentifier;
	_remoteApplicationIdentifier = remoteApplicationIdentifier;
	_haveToStop.GetObjectItself() = FALSE;
	_receivedMessage.GetObjectItself().Empty();

	::AfxBeginThread( CAN_InterApplicationCommunicator::SenderThread, this );
	::AfxBeginThread( CAN_InterApplicationCommunicator::ReceiverThread, this );
}

CAN_InterApplicationCommunicator::~CAN_InterApplicationCommunicator()
{
	StopThreads();
	CleanUp();
}

void CAN_InterApplicationCommunicator::StopThreads()
{
	CSingleLock locker( &_haveToStop );
	locker.Lock();
	_haveToStop.GetObjectItself() = TRUE;
	locker.Unlock();
}

BOOL CAN_InterApplicationCommunicator::HaveToStop()
{
	BOOL result = FALSE;

	CSingleLock locker( &_haveToStop );
	locker.Lock();
	result = _haveToStop.GetObjectItself();
	locker.Unlock();

	return result;
}

void CAN_InterApplicationCommunicator::CleanUp()
{
	// clean up the pending list
	CSingleLock locker( &_pendingMessagesToSend );
	locker.Lock();

	_pendingMessagesToSend.GetObjectItself().clear();
	
	// destroy the receivedMessage object if exists
	CSingleLock( &_receivedMessage, TRUE );
	if( FALSE == _receivedMessage.GetObjectItself().IsEmpty() )
	{
		_receivedMessage.GetObjectItself().Empty();
	}

	locker.Unlock();
}

void CAN_InterApplicationCommunicator::SendMessage( CAN_Message& message )
{
	// checking for message validity
	if( TRUE == message.IsEmpty() )
	{
		return;
	}

	// adding to the pending list, to be sent later
	CSingleLock locker( &_pendingMessagesToSend );
	locker.Lock();
	_pendingMessagesToSend->push_back( message );
	locker.Unlock();
}

void CAN_InterApplicationCommunicator::ReadMessage( CAN_Message& message, BOOL removeMessage )	
{
	// sync access to '_receivedMessage'
	CSingleLock locker( &_receivedMessage );
	locker.Lock();

	if( FALSE == _receivedMessage.GetObjectItself().IsEmpty() )
	{
		// copying the message
		message = _receivedMessage.GetObjectItself();

		// delete the message if it was requested
		if( TRUE==removeMessage )
		{
			_receivedMessage.GetObjectItself().Empty();
		}
	}

	locker.Unlock();
}


#define MEM_FILE_SIZE ( 1024 * 1024 )

UINT CAN_InterApplicationCommunicator::SenderThread( LPVOID pointerToThisObjectInstance )
{
	// getting the pointer to object instance
	CAN_InterApplicationCommunicator* theObjectInstance = reinterpret_cast<CAN_InterApplicationCommunicator*>( pointerToThisObjectInstance );
	if( NULL == theObjectInstance )
	{
		// we're in trouble, we don't have a valid instance, have to do some trace stuff here
		return -1;
	}

	// the target we have to write to
	std::string targetIdentifier = theObjectInstance->_localApplicationIdentifier+ "_sends_to_" +theObjectInstance->_remoteApplicationIdentifier;

	// the shared memory where we're going to write to
    CAN_SharedMemory outputFile;
	BOOL result = outputFile.CreateSharedMemory( targetIdentifier.c_str(), MEM_FILE_SIZE );
	if( FALSE == result )
	{
		// we have an error on accessing the shared memory file, try to access it as existing
		result = outputFile.OpenExistingSharedMemory( targetIdentifier.c_str(), MEM_FILE_SIZE );
		if( FALSE == result )
			return -1;
	}

	// sync-object
	std::string semaphoreName = targetIdentifier + "_SEMAPHORE_";
	CSemaphore writeSemaphore( 1, 1, semaphoreName.c_str() );

	
	// Getting here means we have validated all the objects we need to correctly operate, we can start send messages now

	// while the object is not in destroying state we're allowed to send messages
	while( FALSE == theObjectInstance->HaveToStop() )
	{
		writeSemaphore.Lock();	

		if( TRUE == outputFile.IsEmpty() )
		{
			CSingleLock pendinMessagesLocker( &(theObjectInstance->_pendingMessagesToSend) );
			pendinMessagesLocker.Lock();

			// getting the message from the list
			if( false == theObjectInstance->_pendingMessagesToSend->empty() )
			{
				// getting the message and removing it from the list
				CAN_Message messageToSend = theObjectInstance->_pendingMessagesToSend->front();
				theObjectInstance->_pendingMessagesToSend->pop_front();

				//	writing data to shared memory
				CMemFile* file = messageToSend;
				if( NULL != file )
				{
					ULONGLONG bufferSize = file->GetLength();
					BYTE* buffer = file->Detach();
					if( NULL != buffer )
					{
						outputFile.EmptyData();
						LPVOID address = outputFile.GetData();
						memcpy( address, buffer, bufferSize );
						delete buffer;

					}
					outputFile.SetDataSize( bufferSize );
				}
			}

			pendinMessagesLocker.Unlock();
		}
		
		writeSemaphore.Unlock();
	}

	return 0;
}

UINT CAN_InterApplicationCommunicator::ReceiverThread( LPVOID pointerToThisObjectInstance )
{
	// getting the pointer to object instance
	CAN_InterApplicationCommunicator* theObjectInstance = reinterpret_cast<CAN_InterApplicationCommunicator*>( pointerToThisObjectInstance );
	if( NULL == theObjectInstance )
	{
		// we're in trouble, we don't have a valid instance, have to do some trace stuff here
		return -1;
	}

	// the source identifier from where to read
	std::string sourceIdentifier = theObjectInstance->_remoteApplicationIdentifier+ "_sends_to_" +theObjectInstance->_localApplicationIdentifier;

	// the shared memory from where we're going to read
	CAN_SharedMemory inputFile;
	BOOL result = inputFile.CreateSharedMemory( sourceIdentifier.c_str(), MEM_FILE_SIZE );
	if( FALSE == result )
	{
		// we have an error on accessing the shared memory file, try to access it as existing
		result = inputFile.OpenExistingSharedMemory( sourceIdentifier.c_str(), MEM_FILE_SIZE );
		if( FALSE == result )
            return -1;
	}

	// the sync-object
	std::string semaphoreName = sourceIdentifier + "_SEMAPHORE_";
	CSemaphore readSemaphore( 1, 1, semaphoreName.c_str() );


	// Getting here means we have validated all the objects we need to correctly operate, we can start receive messages

	// while the object is not destroyed we're allowed to send messages
	while( FALSE == theObjectInstance->HaveToStop() )
	{

		// reading data from the shared memory
		readSemaphore.Lock();
		if( FALSE == inputFile.IsEmpty() )
		{
			
			CSingleLock recievedMessageLocker( &(theObjectInstance->_receivedMessage) );
			BOOL canRunFurther = FALSE;
			CAN_Message& receivedMessage = theObjectInstance->_receivedMessage.GetObjectItself();

			// waiting for the last message to be read and removed, only then we can continue
			do 
			{
				recievedMessageLocker.Lock();
				canRunFurther = receivedMessage.IsEmpty();
				recievedMessageLocker.Unlock();
			} while( FALSE == canRunFurther );

			recievedMessageLocker.Lock();
			CMemFile* file = receivedMessage;
			if( NULL != file )
			{
				DWORD bufferSize = inputFile.GetDataSize();
				LPVOID address = inputFile.GetData();

				BYTE* buffer = new BYTE[ bufferSize ];
				if( NULL != buffer )
				{
					memcpy( buffer, address, bufferSize);
					file->Attach( buffer, bufferSize );
				}
			}
			recievedMessageLocker.Unlock();			

			// showing that data was read from buffer, and there is no data
			inputFile.EmptyData();
		}

		readSemaphore.Unlock();
	}

	return 0;
}
