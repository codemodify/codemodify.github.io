
// headers
#include <afxwin.h>
#include "AN_Logger.h"

#define LOGGER "Logger"

#pragma warning ( disable : 4267 )

// init the static variable
Logger* Logger::s_loggerObject = 0;

Logger::Logger(void)
{
	// setting the default log file
	SetLogFile();

	AddInfo( "Logger is up and running", LOGGER );
}

Logger::~Logger(void)
{
	CSingleLock locker( &_logFile );
	locker.Lock();
	_logFile->Close();
	locker.Unlock();
}

Logger* Logger::GetInstance()
{
	// checking if we have a valid object, create one if not
	if( 0 == s_loggerObject )
	{
        s_loggerObject = new Logger();
	}

	return s_loggerObject;
}

void Logger::DestroyInstance()
{
	// checking if we're destroying a valid object
	if( 0 != s_loggerObject )
	{
		s_loggerObject->AddInfo( "Logger is going down", LOGGER );
		delete s_loggerObject;
		s_loggerObject = 0;
	}
}

void Logger::SetLogFile( std::string filePath )
{
	if( 0 == filePath.length() )
	{
		CHAR currentDirectory[255];
		GetCurrentDirectory(254,currentDirectory);
		filePath = currentDirectory;
		filePath += "\\";
		filePath += AfxGetAppName();
		filePath.append(".log");
	}

	_logFile->Open( filePath.c_str(), CFile::modeWrite | CFile::modeNoTruncate | CFile::modeCreate );
	_logFile->SeekToEnd();
}

void Logger::AddMessage( std::string logMessage, std::string sender )
{
	// if the sender is empty, we assign a default value
	if( sender.empty() )
		sender = LOGGER;
	
	// build the message to write to the log-file
	std::string message = sender;
	message.append( " - " );
	message.append( logMessage );
	message.append( "..." );
	message.append( "\n" );

	// writing to the file
	CSingleLock locker( &_logFile );
	locker.Lock();
	_logFile->Write( message.c_str(), message.length() );
	_logFile->Flush();
	locker.Unlock();
}

void Logger::AddInfo( std::string logMessage, std::string sender )
{
	// build the Info message
	std::string message = "Info: ";
	message.append( logMessage );

	// finally add the message
	AddMessage( message, sender );
}

void Logger::AddInfo( char logMessage, std::string sender )
{
	// build the Info message
	std::string message;
	message.append( 1, logMessage );

	// finally add the message
	AddMessage( message, sender );
}

void Logger::AddInfo( int logMessage, std::string sender )
{
	// build the Info message
	std::string message;
	char out[30];
	itoa(logMessage, out, 10);
	message.append( out );

	// finally add the message
	AddMessage( message, sender );
}

void Logger::AddInfo( unsigned long logMessage, std::string sender )
{
	// build the Info message
	std::string message;
	char out[30];
	ltoa(logMessage, out, 10);
	message.append( out );

	// finally add the message
	AddMessage( message, sender );
}

void Logger::AddError( std::string logMessage, std::string sender )
{
	// build the Error message
	std::string message = "Error: ";
	message.append( logMessage );

	// finally add the message
	AddMessage( message, sender );
}

void Logger::AddWarning( std::string logMessage, std::string sender )
{
	// build the Error message
	std::string message = "Warning: ";
	message.append( logMessage );

	// finally add the message
	AddMessage( message, sender );
}
