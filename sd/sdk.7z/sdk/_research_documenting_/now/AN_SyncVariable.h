#pragma once


template < class SyncObjectClass, class VariableItem >
class CAN_SyncVariable : public SyncObjectClass
{
	VariableItem _item;
public:
	
	// permits easily to call any member of the object if it has any
	VariableItem* operator -> ()
	{
		return &_item;
	}

	// gets direct access to the object, so we can apply any ++/--/= operations if it supports it
    VariableItem& GetObjectItself()
	{
        return _item;
	}
};