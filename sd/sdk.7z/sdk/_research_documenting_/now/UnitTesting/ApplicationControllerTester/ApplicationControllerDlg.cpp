// ApplicationControllerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ApplicationController.h"
#include "ApplicationControllerDlg.h"
#include "AN_ApplicationController.h"
#include ".\applicationcontrollerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CApplicationControllerDlg dialog



CApplicationControllerDlg::CApplicationControllerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CApplicationControllerDlg::IDD, pParent)
	, m_processorUsage(0)
	, m_linesNumber(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    _allowedToRun.GetObjectItself() = TRUE;
}

void CApplicationControllerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_listBox);
	DDX_Slider(pDX, IDC_PROCESSOR_PERCENT, m_processorUsage);
	DDX_Text(pDX, IDC_STATIC_LINES, m_linesNumber);
}

BEGIN_MESSAGE_MAP(CApplicationControllerDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_START_STRESS, OnBnClickedStartStress)
	ON_BN_CLICKED(IDC_STOP_STRESS, OnBnClickedStopStress)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_PROCESSOR_PERCENT, OnNMReleasedcaptureProcessorPercent)
END_MESSAGE_MAP()


// CApplicationControllerDlg message handlers

BOOL CApplicationControllerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here


	CWnd* button = GetDlgItem( IDC_START_STRESS );
	if( NULL != button )
	{
		button->EnableWindow( TRUE );
	}

	button = GetDlgItem( IDC_STOP_STRESS );
	if( NULL != button )
	{
		button->EnableWindow( FALSE );
	}

	button = GetDlgItem( IDC_PROCESSOR_PERCENT );
	if( NULL != button )
	{
		button->EnableWindow( FALSE );
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CApplicationControllerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CApplicationControllerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CApplicationControllerDlg::OnBnClickedStartStress()
{
	_allowedToRun.GetObjectItself() = TRUE;

	for( int threadIndex = 0; threadIndex<THREAD_COUNT; ++threadIndex )
	{
		AfxBeginThread( CApplicationControllerDlg::TesterThread, this );
	}

	CWnd* button = GetDlgItem( IDC_START_STRESS );
	if( NULL != button )
	{
		button->EnableWindow( FALSE );
	}
    
	button = GetDlgItem( IDC_STOP_STRESS );
	if( NULL != button )
	{
		button->EnableWindow( TRUE );
	}

	button = GetDlgItem( IDC_PROCESSOR_PERCENT );
	if( NULL != button )
	{
		button->EnableWindow( TRUE );
	}

    UpdateData();
	CAN_ApplicationController::SetMaxProcessorPercentUsage( GetCurrentProcessId(), m_processorUsage, GetCurrentThreadId() );
}

void CApplicationControllerDlg::OnBnClickedStopStress()
{
	CAN_ApplicationController::RemoveProcessorLimit( GetCurrentProcessId(), GetCurrentThreadId() );
	//CAN_ApplicationController::CleanUp();

	_allowedToRun.GetObjectItself() = FALSE;

	CWnd* button = GetDlgItem( IDC_START_STRESS );
	if( NULL != button )
	{
		button->EnableWindow( TRUE );
	}

	button = GetDlgItem( IDC_STOP_STRESS );
	if( NULL != button )
	{
		button->EnableWindow( FALSE );
	}

	button = GetDlgItem( IDC_PROCESSOR_PERCENT );
	if( NULL != button )
	{
		button->EnableWindow( FALSE );
	}

}

UINT CApplicationControllerDlg::TesterThread( LPVOID pointerToThisObjectInstance )
{
	CApplicationControllerDlg* theObjectInstance = reinterpret_cast<CApplicationControllerDlg*>( pointerToThisObjectInstance );
	if( NULL == theObjectInstance  )
		return 0;

	CSingleLock locker( &(theObjectInstance->_allowedToRun), FALSE );
	while( locker.Lock(), theObjectInstance->_allowedToRun.GetObjectItself() )
	{
        locker.Unlock();

		char buffer[ 100 ];
		memset( (void*)buffer, 0, 100 );
		sprintf( buffer, "%d", theObjectInstance->m_listBox.GetCount() );
		theObjectInstance->m_listBox.InsertString( 0, buffer );
    }
}

void CApplicationControllerDlg::OnBnClickedOk()
{
	OnOK();
}

void CApplicationControllerDlg::OnNMReleasedcaptureProcessorPercent(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	UpdateData();
	CAN_ApplicationController::SetMaxProcessorPercentUsage( GetCurrentProcessId(), m_processorUsage, GetCurrentThreadId() );
}
