// ApplicationControllerDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "afxmt.h"
#include "AN_SyncVariable.h"

// CApplicationControllerDlg dialog
class CApplicationControllerDlg : public CDialog
{
// Construction
public:
	CApplicationControllerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_APPLICATIONCONTROLLER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListBox m_listBox;
	afx_msg void OnBnClickedStartStress();
	afx_msg void OnBnClickedStopStress();
	int m_processorUsage;



private:		// stuff used to test the "CAN_ApplicationController" class
	#define THREAD_COUNT 200
	static UINT TesterThread( LPVOID pointerToThisObjectInstance );
	CAN_SyncVariable<CSemaphore, BOOL> _allowedToRun;

public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnNMReleasedcaptureProcessorPercent(NMHDR *pNMHDR, LRESULT *pResult);
	CString m_linesNumber;
};
