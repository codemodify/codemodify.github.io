//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ApplicationController.rc
//
#define IDR_MANIFEST                    1
#define IDD_APPLICATIONCONTROLLER_DIALOG 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_SLIDER1                     1000
#define IDC_PROCESSOR_PERCENT           1000
#define IDC_MAX                         1003
#define IDC_MIN                         1004
#define IDC_START_STRESS                1005
#define IDC_STOP_STRESS                 1007
#define IDC_LIST1                       1008
#define IDC_STATIC_LINES                1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
