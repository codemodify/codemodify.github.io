// QueueManagerTester.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ApplicationCommunicatorTester.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		// init the random generation
		srand( (unsigned)time(NULL) );

		// the queue-manager object
		//InterApplicationCommunicator interApplicationCommunicator( "me", "friend" );
		CAN_InterApplicationCommunicator interApplicationCommunicator( "friend", "me" );

		// the number to send
		int randomNumber = 0;

		// the same number as string
		double randomNumberAsDouble = 0;

		// the running mode
		char ch = 'r';
		while( 1 )
		{
			if( kbhit() )
			{
				ch = _getch();

                if( ch == 'r' )
					printf("The mode was changed to receive only, no messages will be sent.\n");
				else if ( ch == 's' )
					printf("The mode was changed to send only, no messages will be received.\n");
				else if ( ch == 'a' )
					printf("The mode was changed to send/receive.\n");
			}

			randomNumber = rand();			
			randomNumberAsDouble = randomNumber;

			if( ch == 'r' )
			{
				CAN_Message message;
				interApplicationCommunicator.ReadMessage( message, TRUE );

				if ( !message.IsEmpty() )
				{
					CArchive archive( message, CArchive::load );
					archive >> randomNumber;
					archive >> randomNumberAsDouble;
					cout << "read: "<< randomNumber << "  " << randomNumberAsDouble << endl;
				}
			}
			else if ( ch == 's' )
			{
				CAN_Message message;
				CArchive archive( message, CArchive::store );
				archive << randomNumber;
				archive << randomNumberAsDouble;
				archive.Close();
				interApplicationCommunicator.SendMessage( message );
				cout << "sent: " << randomNumber << "  " << randomNumberAsDouble << endl;
			}
			else if ( ch == 'a' )
			{
				CAN_Message message;
				CArchive archive( message, CArchive::store );
				archive << randomNumber;
				archive << randomNumberAsDouble;
				archive.Close();
				interApplicationCommunicator.SendMessage( message );
				cout << "sent: " << randomNumber << "  " << randomNumberAsDouble << endl;

				message.Empty();
				interApplicationCommunicator.ReadMessage( message, TRUE );
				if ( !message.IsEmpty() )
				{
					CArchive archive2( message, CArchive::load );
					archive2 >> randomNumber;
					archive2 >> randomNumberAsDouble;
					archive2.Close();
					cout << "read: " << randomNumber << "  " << randomNumberAsDouble << endl;
				}
			}
			else if ( ch == 'q' )
				break;

			Sleep( 0 );
		}

		
	}

	return nRetCode;
}
