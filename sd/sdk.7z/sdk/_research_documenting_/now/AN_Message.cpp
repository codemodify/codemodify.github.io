#include "AN_Message.h"

#pragma warning ( disable : 4244 )

CAN_Message::CAN_Message()
{
}

CAN_Message::CAN_Message( const CAN_Message& theObjectToCopy )
{
	CMemFile* file = (CMemFile*)(&theObjectToCopy);
	
	if( (NULL != file) && (file->GetLength() > 0) )
	{
		ULONGLONG length = file->GetLength();
		BYTE* buffer = new BYTE[ length ];

		file->SeekToBegin();
		file->Read( buffer, length );

		_memoryFile.Attach( buffer, length );
	}
}

CAN_Message::~CAN_Message()
{
	BYTE* buffer = _memoryFile.Detach();
	if( NULL != buffer )
	{
        delete buffer;
	}	
}

void CAN_Message::Empty()
{
    BYTE* buffer = _memoryFile.Detach();
	if( NULL != buffer )
	{
        free((void*)buffer);
	}
}

BOOL CAN_Message::IsEmpty()
{
    return ( 0 == _memoryFile.GetLength() );
}

CAN_Message::operator CMemFile*() 
{
	return &_memoryFile;
}

CAN_Message& CAN_Message::operator = ( const CAN_Message& theObjectToCopy )
{
	CMemFile* file = (CMemFile*)(&theObjectToCopy);
	
	if( NULL != file )
	{
		ULONGLONG length = file->GetLength();
		BYTE* buffer = new BYTE[ length ];

		file->SeekToBegin();
		file->Read( buffer, length );

		_memoryFile.Attach( file->Detach(), file->GetLength() );
	}

	return *this;
}

