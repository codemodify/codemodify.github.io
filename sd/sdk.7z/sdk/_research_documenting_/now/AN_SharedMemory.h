#pragma once

// headers
#include <string>
#include <afx.h>

/************************************************************************/
/*
/*		The class is designed to implement a global memory sharing mechanism.
/*		The shared memory can be used between different applications or threads.
/*		
/*		The class is not thread-safe.
/*		The class is reentrant.
/*
/*	
/*		Example:
/*
/*		#define MEM_SIZE (1024 * 1024)
/*		CAN_SharedMemory sharedMemory;
/*		sharedMemory.CreateSharedMemory( "share_memory_with_second_app_instance", MEM_SIZE  );
/*		LPVOID* data = sharedMemory.GetData();
/*		memset( data, 0, sharedMemory.GetAllocatedMemorySize() );
/*		sharedMemory.SetDataSize( 0 );
/*
/************************************************************************/
class CAN_SharedMemory
{
public:		// Constructors
    CAN_SharedMemory();
	~CAN_SharedMemory();



public:		// Class' interface	
	
	// Creates a globally shared region of memory
	BOOL	CreateSharedMemory( std::string memoryIdentifier, DWORD memorySize, BOOL readOnly = FALSE, LPSECURITY_ATTRIBUTES securityAttributes = NULL );

	// Checks if a shared memory identified by an identifier already exists
	static BOOL SharedMemoryExists( std::string memoryIdentifier );

    // Make available an existing shared memory
	BOOL	OpenExistingSharedMemory( std::string memoryIdentifier, DWORD memorySize = 0, BOOL readOnly = FALSE );

	// Gets the size of the memory currently in use by this object
	DWORD GetAllocatedMemorySize() const;

	// Gets the direct access to the data in memory
	LPVOID GetData() const;

	// Get the size for the current data stored in memory
    DWORD GetDataSize();

	// Sets the size of the internal stored data
	void SetDataSize( DWORD dataSize );

	// Fills with zero all the buffer
    void EmptyData();

	// Checks if shared memory contains any data
	BOOL IsEmpty();



private:	// Internal stuff

	// Cleans and sets internal data to null values
	void CleanInternalData();

	// Stores the handle of the memory being used
	HANDLE	_memoryHandle;

	// Stores the start address of the memory in use
	LPVOID	_memoryData;

	// Stores the memory size
	DWORD _allocatedMemorySize;

	// Stores the memory identifier in system
	std::string	_memoryIdentifier;

	// Stores if the memory is read-only or not
	BOOL	_readOnly;

};
