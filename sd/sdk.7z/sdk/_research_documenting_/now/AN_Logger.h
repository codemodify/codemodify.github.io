#pragma once

// Header files
#include <string>
#include <afxmt.h>

// local hears
#include "AN_SyncVariable.h"



/************************************************************************/
/*
/*		The functionality of this class implements a logging framework
/*		for applications to write logs about current actions
/*		The class is using the singleton pattern design.
/*		Thread safe. Reentrant.
/*
/*		Ex of usage:
/*		#define MAIN_APPLICATION
/*		#define THREAD_ONE
/*		Logger::getInstance()->addInfo( "started", MAIN_APPLICATION );
/*		Logger::getInstance()->addEnfo( "can't run", THREAD_ONE );
/*
/*
/************************************************************************/

class Logger
{
public:
	~Logger();

	// Gets the instance of the logger object
	static Logger* GetInstance();

	// Destroys the logging object
	static void DestroyInstance();

	// Sets an alternate log file, the default is "currentFolder"+"appName"+".log"
	void SetLogFile( std::string filePath = "" );

	// Follows a set of functions used to write specific log-messages to the log file
	void AddInfo( std::string logMessage, std::string sender="" );
	void AddInfo( char logMessage, std::string sender="" );
	void AddInfo( int logMessage, std::string sender="" );
	void AddInfo( unsigned long logMessage, std::string sender="" );

	void AddError( std::string logMessage,std:: string sender="" );
	void AddWarning( std::string logMessage, std::string sender="" );



private:

	// Disabling direct creation
	Logger();

	// The method is implementing the actual adding mechanism of message to the file
	void AddMessage( std::string logMessage, std::string sender="" );

	// The logger object used for all the writing operations
	static Logger* s_loggerObject;

	// The file to write logs to
	CAN_SyncVariable<CSemaphore, CFile> _logFile;
};
