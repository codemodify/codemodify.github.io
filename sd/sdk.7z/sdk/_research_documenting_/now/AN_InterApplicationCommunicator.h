#pragma once

// local headers
#include "AN_SyncVariable.h"
#include "AN_Message.h"

// headers
#include <string>
#include <list>

#include <afx.h>
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxmt.h>



/************************************************************************/
/*
/*		The class is designed to be able to communicate/share data between two different
/*		applications that have an instance of this object definition.
/*		The class is thread-safe.
/*		
/*		
/*		Example of usage:
/*		-=[application_1]=-
/*		CAN_InterApplicationCommunicator applicationCommunicator( "key_1", "key_2" );
/*		CAN_Message message;
/*		CArchive archive( message, CArchive::store );
/*		archive << 10.0;
/*		archove.Close();
/*		applicationCommunicator.send( message );
/*	
/*		-=[application_2]=-
/*		CAN_InterApplicationCommunicator applicationCommunicator( "key_2", "key_1" );
/*		CAN_Message message;
/*		applicationCommunicator.read( message );
/*		CArchive archive( message, CArchive::load );
/*		float a = 0;
/*		a << ar;	// a == 10.0
/*
/*
/************************************************************************/
class CAN_InterApplicationCommunicator
{

public:
	CAN_InterApplicationCommunicator( std::string localApplicationIdentifier, std::string remoteApplicationIdentifier );
	~CAN_InterApplicationCommunicator();

public:		// Class interface
	void SendMessage( CAN_Message& message );
	void ReadMessage( CAN_Message& message, BOOL removeMessage=false );	



private:	// Data used to identify the memory-map files
	std::string _localApplicationIdentifier;
	std::string _remoteApplicationIdentifier;



private:	
	// The pending list of messages to be sent
	typedef std::list<CAN_Message> MessageListToSend;
	CAN_SyncVariable<CSemaphore, MessageListToSend> _pendingMessagesToSend;

	// Stores the message we just received
	CAN_SyncVariable<CSemaphore,CAN_Message> _receivedMessage;



public:
	// The thread function which will send pending messages
	static UINT SenderThread( LPVOID pointerToThisObjectInstance );
	static UINT ReceiverThread( LPVOID pointerToThisObjectInstance );



private:	// Stops the 'senderThread'
	CAN_SyncVariable<CSemaphore,BOOL> _haveToStop;
	BOOL HaveToStop();
	void StopThreads();



private:
	// Cleans all the resources that we are using
	void CleanUp();

};
