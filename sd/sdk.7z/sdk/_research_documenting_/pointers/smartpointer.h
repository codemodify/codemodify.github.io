template< class Class > class SmartPointer
{

public:

	SmartPointer();
	virtual ~SmartPointer();



public:	// class' interface

	bool IsNull() const;
	unsigned long GetRefCount();
	virtual Set(T* pT);

	operator Class*() const;
	T* operator->() const;
	T& operator*() const { if(IsNull()) XRefcnt_ptr_excp::Throw(); return *_pT; }
	bool operator!() const { return IsNull(); }

	//the behaviour changes from strong to weak

protected:
	Class* _class;

};

template<class Class>
SmartPointer::SmartPointer():
	_class(0)
{}

template<class Class>
bool SmartPointer::IsNull() const
{
	return !_class;
}

template<class Class>
LONG SmartPointer::GetRefCount()
{
	return _pRefCnt->GetRefCount();
}

template<class Class>
SmartPointer::operator Class*() const
{
	return _class;
}

template<class Class>
Class* SmartPointer::operator->() const
{
	if( IsNull() )
		XRefcnt_ptr_excp::Throw(); 

	return _class;
}
