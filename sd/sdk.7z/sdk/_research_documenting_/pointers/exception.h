class Exception
{
	
	
protected:
	Exception( std::string errorMessage );
	virtual ~Exception();


public:
	static void Throw( std::string errorMessage = "" );


public:
	const char* GetErrorMessage();
};


Exception::Exception()
{}

Exception::~Exception()
{}

void Exception::Throw( std::string errorMessage )
{
	Exception exception(errorMessage);
	throw &exception;
}
