
/*********************************************************************
*
*       The base calss from where everything else derives.
*       This class is disabled from beeing instatieted directly.
*
*********************************************************************/
class TheObject()
{

protected:
        TheObject();
       ~TheObject();

};
