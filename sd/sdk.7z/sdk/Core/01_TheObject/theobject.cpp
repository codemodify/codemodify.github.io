
#include "theobject.h"

TheObject::TheObject()
{}

TheObject::~TheObject()
{}
