
#include "exception.h"

Exception::Exception( std::string errorMessage )
{
	_errorMessage.assign(errorMessage);
}

Exception::~Exception()
{}

void Exception::throwException( std::string errorMessage )
{
	Exception exception(errorMessage);
	throw &exception;
}

const char* Exception::getErrorMessage()
{
	return _errorMessage.c_str();
}
