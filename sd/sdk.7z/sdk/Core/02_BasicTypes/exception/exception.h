
/***********************************************************************
*
*		This class provides an easy interface for exception handling.
*
*		Thread safe. Reentrant.
*
***********************************************************************/
class Exception
{
protected:
	Exception( std::string errorMessage );
	virtual ~Exception();


public:
	static virtual void throwException( std::string errorMessage = "" );


public:
	const char* getErrorMessage();


private:
	std::string _errorMessage;

};
