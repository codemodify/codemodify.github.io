template< class T, class C>
class StrongPointer : public _PtrSmart<T>
{
	friend class _PtrSmart;

private:

	void _Clear()  //cleanup and set to null
	{
		if(_pRefCnt)
			_pRefCnt->ReleaseStrong();
		_pRefCnt = NULL;
		_pT = NULL;
	}

	//assign from "dumb pointer" 
	//(avoid to do this from non-strong objects, unless it is the very first assignment)
	void _Assign(T* pT)  
	{
		if(_pT == pT) return;	//return immediatly if reassign

		_Clear();	//cleanup (release and set to null)

		if(pT)
		{
			_pRefCnt = GetRefCountBase<T>(pT);
			if(!_pRefCnt) 
			{
				//may be the object is not "smart", 
				//	do a new refcounter (## less safe! ##)
				_pRefCnt = new RefCount<T>(pT);
			}
			_pRefCnt->IncStrong();
			_pT = pT;
		}
	}

	template<class U>
	void _Assign(U* pU)  //eterogeneus dumb assign
	{
		T* pT = smart_cast<T,U,C>(pU);
		if(_pT == pT) return;

		_Clear();

		if(pT)
		{
			_pRefCnt = GetRefCountBase<U>(pU);
			if(!_pRefCnt) 
			{
				//may be the object is not "smart", 
				//	do a new refcounter (## less safe! ##)
				_pRefCnt = new RefCount<U>(pU);
			}
			_pRefCnt->IncStrong();
			_pT = pT;
		}
	}

	void _Assign(const _PtrSmart<T>& cpsT) //from another smart pointer
	{
		bool bToNull = cpsT.IsNull();
		if(!bToNull && _pT == cpsT._pT) return;

		_Clear();
		if(!bToNull)
		{
			_pT = cpsT._pT;
			_pRefCnt = cpsT._pRefCnt;
			_pRefCnt->IncStrong();
		}
	}

	template<class U>
		void _Assign(const _PtrSmart<U>& cpsU)
	{
		bool bToNull = cpsU.IsNull();
		T* pT = NULL; 
		if(!bToNull)
			pT = smart_cast<T,U,C>(cpsU._pT);
		if(pT && _pT == pT) return;

		_Clear();

		if(pT)
		{
			//use the same counter, but refer _pT
			_pRefCnt = cpsU._pRefCnt;
			_pT = pT;
			_pRefCnt->IncStrong();
		}
	}
	
public:
	//public "user" functions
	
	//cunstructor, assignment and conversions
	PtrStrong() {;}
	~PtrStrong() {_Clear();};
	PtrStrong(const PtrStrong& cpsT) {_Assign(cpsT);}
	PtrStrong(const _PtrSmart<T>& cpsT) {_Assign(cpsT);}
	PtrStrong(const T* pT) {_Assign((T*)pT);}
	template<class U> PtrStrong(const U* pU) {_Assign<U>((U*)pU);}
	template<class U> PtrStrong(const _PtrSmart<U>& cpsU) {_Assign<U>(cpsU);}
	PtrStrong<T>& operator=(const PtrStrong& cpsT) {_Assign(cpsT); return *this;}
	PtrStrong<T>& operator=(const _PtrSmart<T>& cpsT) {_Assign(cpsT); return *this;}
	PtrStrong<T>& operator=(const T* pT) {_Assign((T*)pT); return *this;};
	template<class U> PtrStrong<T>& operator=(const U* pU) {_Assign<U>((U*)pU); return *this;}
	template<class U> PtrStrong<T>& operator=(const _PtrSmart<U>& cpsU) {_Assign<U>(cpsU); return *this;}

	T* New() {T* pT = new T; _Assign(pT); return pT;}
	template<class U> T* New(const U& u) {T* pT = new T(u); _Assign(pT); return pT;}
	template<class U, class V> T* New(const U& u, const V& v) {T* pT = new T(u,v); _Assign(pT); return pT;}
	template<class U, class V, class W> T* New(const U& u, const V& v, const W& w) {T* pT = new T(u,v,w); _Assign(pT); return pT;}
	void Null() {_Clear();};
	virtual Set(T* pT) { _Assign(pT); }
};