
#include <TheObject>

/*********************************************************************
*
*       This class defines a "bool" data type
*
*********************************************************************/

typedef true True;
typedef false False;

class Bool : public TheObject
{
public:
    Bool();
    ~Bool();

public:
    Bool& operator=( Bool& newValue );
    operator True()

protected:
    bool _value;

};
