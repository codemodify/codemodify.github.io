
#include "bool.h"

Bool::Bool():
        _value(false)
{
}

Bool::~Bool()
{
}

Bool& Bool::operator=( Bool& newValue )
{
        _value = newValue._value;
}
