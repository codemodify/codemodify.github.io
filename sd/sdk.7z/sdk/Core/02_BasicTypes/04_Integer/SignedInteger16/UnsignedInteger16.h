
#include "TheObject"

/*********************************************************************
*
*       This class defines a "int" data type
*
*********************************************************************/
class Integer : public TheObject
{
public:
        Integer();
       ~Integer();

public:
        Integer& operator=( Integer& newValue );

protected:
        int _value;
         
};
