
#include <TheObject>

/*********************************************************************
*
*       This class defines a "string" data type
*
*********************************************************************/
class String : public TheObject
{
public:
    String();
    ~String();


public: // interfaces to allow a peaceful work with a string
    
    Bool isEmpty();
    
    Bool isNumber();
    
    Bool isUTF8();
    Bool isUTF16();
    Bool isUTF32();
    
    Integer getLength();
    
    ByteArray toByteArray();
    Integer   toInteger();
    Float     toFloat();
    Complex   toComplex();
    
    Bool contains( String& value );
    String getIndexOf( String& value )
    
    void removeSubstring( String& valueToRemove );
    void replaceSubstring( String& valueToSearchFor, String& valueToReplaceWith );
    void insert( Integer position, String& valueToInsert );
    void addInFront( String& valueToInsert );
    void addAtEnd( String& valueToAppend );


public: // operations on the type
    String& operator =( String& newValue );

    String& operator +( String& value );
    String& operator +=( String& value );

    String& operator -( String& value );
    String& operator -=( String& value );


protected: // internal data
    char* _data;
    Integer _length;
         
};
