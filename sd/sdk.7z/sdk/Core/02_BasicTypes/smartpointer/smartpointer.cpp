
#include "smartpointer.h"

template<class Class>
SmartPointer::SmartPointer():
	_class(0)
{}

template<class Class>
bool SmartPointer::isNull() const
{
	return !_class;
}

template<class Class>
SmartPointer::operator Class*() const
{
	return _class;
}

template<class Class>
Class* SmartPointer::operator->() const
{
	return _class;
}

template<class Class>
Class& SmartPointer::operator*() const
{
	return *_class;
}

bool SmartPointer::operator!() const
{
	return isNull();
}
