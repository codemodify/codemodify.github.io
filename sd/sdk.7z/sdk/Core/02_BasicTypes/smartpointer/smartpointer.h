
/***********************************************************************
*
*		This class provides an easy interface for work with poinyters.
*
*		Thread safe. Reentrant.
*
***********************************************************************/
template< class Class > class SmartPointer
{

public:
	SmartPointer();
	virtual ~SmartPointer();


public:		// class' interface
	bool isNull() const;


public:		// overloading
	operator Class*() const;
	Class* operator->() const;
	Class& operator*() const;
	bool operator!() const;


protected:
	Class* _class;

};
