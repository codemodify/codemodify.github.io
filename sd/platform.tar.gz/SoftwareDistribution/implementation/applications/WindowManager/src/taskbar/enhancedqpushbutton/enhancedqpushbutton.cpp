
// local deaders
#include "enhancedqpushbutton.h"

EnhancedQPushButton::EnhancedQPushButton():
	QPushButton()
{}

