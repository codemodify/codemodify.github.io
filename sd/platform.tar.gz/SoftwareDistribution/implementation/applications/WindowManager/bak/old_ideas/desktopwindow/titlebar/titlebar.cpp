#include "titlebar.h"

TitleBar::TitleBar()
{
}

TitleBar::~TitleBar()
{
}
