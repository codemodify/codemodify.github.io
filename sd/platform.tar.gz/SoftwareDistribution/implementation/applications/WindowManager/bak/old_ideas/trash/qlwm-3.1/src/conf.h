#define CONFDIR "/usr/local/qlwm/files/"
#define DVERSION "3.1\n"
