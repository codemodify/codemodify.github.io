

// Qt's headers


class TakBarButton : public QPushButton
{

public:
	TakBarButton( QWidget* parent );
	~TakBarButton();


	void 


protected:
	void paintEvent( QPaintEvent* paintEvent );


};

