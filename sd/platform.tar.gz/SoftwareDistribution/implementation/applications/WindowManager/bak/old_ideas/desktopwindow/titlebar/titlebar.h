#ifndef TITLEBAR_H_
#define TITLEBAR_H_

class TitleBar : public QWidget
{
public:
	TitleBar();
	~TitleBar();
};

#endif
