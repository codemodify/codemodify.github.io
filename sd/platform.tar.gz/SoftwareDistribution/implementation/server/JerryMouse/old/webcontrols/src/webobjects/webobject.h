#ifndef WEBOBJECT_H
#define WEBOBJECT_H

class WebObject
{
public:
	WebObject();
	~WebObject();
};

#endif
