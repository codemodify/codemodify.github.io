#ifndef password_h
#define password_h

#include "../input.h"

namespace XHtmlElements
{
	/*****************************************************
	*
	*	Define the "input password" from XHTML
	*
	******************************************************/
	class Password : public HtmlObject
	{
	public:
		Password();
		~Password();
	
	};
};

#endif
