
#include "InternetServerPlatform.h"

int main( int argc, char** argv )
{
	InternetServerPlatform internetServerPlatform( argc, argv );
		
	return internetServerPlatform.run();
}
