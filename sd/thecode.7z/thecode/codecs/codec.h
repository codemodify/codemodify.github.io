#ifndef __codec_h__
#define __codec_h__

typedef unsigned int    Length;
typedef char            Byte;
typedef enum
{
    eOK = 0,
    eInitError,
    eTerminateError,
    eUnknownError,
    eSmallBuffer,
    eNotEnoughMemory
} CodecError;


/************************************************************************
*
*   Interface for stream oriented encoders.
*
************************************************************************/
class Encoder
{
    public:
        CodecError init() = 0;
        CodecError encode(  Byte* source,       Length sourceLength, 
                            Byte* destination,  Length destinationLength ) = 0;
        CodecError terminate() = 0;
};



/************************************************************************
*
*   Interface for stream oriented decoders.
*
************************************************************************/
class Decoder
{
    public:
        CodecError init() = 0;
        CodecError decode(  Byte* source,       Length sourceLength,
                            Byte* destination,  Length destinationLength ) = 0;
        CodecError terminate() = 0;
};

#endif // __codec_h__
