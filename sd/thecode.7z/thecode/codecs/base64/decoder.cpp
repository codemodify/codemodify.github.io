
// local headers
#include "decoder.h"

static char dectab[128] = {
    -1,-1,-1,-1,-1,-1,-1,-1,   /* -1: invalid */
    -1,-2,-2,-2,-2,-2,-1,-1,   /* -2: whitespace */
    -1,-1,-1,-1,-1,-1,-1,-1,   /* 0..63: base64 digit */
    -1,-1,-1,-1,-1,-1,-1,-1,
    -2,-1,-1,-1,-1,-1,-1,-1,
    -1,-1,-1,62,-1,-1,-1,63,
    52,53,54,55,56,57,58,59,
    60,61,-1,-1,-1,-1,-1,-1,
    -1, 0, 1, 2, 3, 4, 5, 6,
     7, 8, 9,10,11,12,13,14,
    15,16,17,18,19,20,21,22,
    23,24,25,-1,-1,-1,-1,-1,
    -1,26,27,28,29,30,31,32,
    33,34,35,36,37,38,39,40,
    41,42,43,44,45,46,47,48,
    49,50,51,-1,-1,-1,-1,-1
};

void Base64Decoder::prepare()
{
    base64_decode_init( &state );
}

int Base64Decoder::decode( const char* source, int sourceLength, char* destination, int destinationLength )
{
    return base64_decode_sub( &state, source, sourceLength, destination, destinationLength );
}

int Base64Decoder::finish()
{
    return base64_decode_fini( &state );
}

int Base64Decoder::decodeBuffer( const char* source, int sourceLength, char* destination,  int destinationLength )
{
    int decodedLength = 0;

    Base64Decoder decoder;
    decoder.prepare();

    decodedLength = decoder.decode( source, sourceLength, destination, destinationLength );
    if( decodedLength < 0 )
        return -1;

    if( decoder.finish() < 0 )
        return -1;

    return decodedLength;
}

void Base64Decoder::base64_decode_init( base64_dec_state_t *state )
{
    state->pad = 0;
    state->inpos = 0;
    state->n = 0;
}

int Base64Decoder::base64_decode_sub( base64_dec_state_t *state, const char *inbuf, int inbuflen, char *outbuf, int outbuflen )
{
    int inpos = 0;
    int outpos = 0;

    if (state->n || !state->pad)
	while (inpos < inbuflen) {
	    unsigned char c = (unsigned char)inbuf[inpos++];

	    /* Classify input bytes as padding, ignorable or codes */
	    if (c == '=') {
		if (state->n < 2)
		    return -1;

		state->pad++;
		state->grp[state->n++] = 0;
	    } else if ((c & 0x80) || dectab[(unsigned int)c] == -1) {
		return -1;
	    } else if (dectab[(unsigned int)c] == -2) 
		continue;
	    else {
		if (state->pad) {
		    return -1;
		}
		state->grp[state->n++] = dectab[(unsigned int)c];
	    }

	    /* When a group of 4 has been filled, convert to 3 output bytes */
	    if (state->n == 4) {
		if (state->pad > 2) {
		    return -1;	
		}
		if (outpos < outbuflen)
		    outbuf[outpos] = state->grp[0] << 2 | state->grp[1] >> 4;
		outpos++;
		if (state->pad < 2) {
		  if (outpos < outbuflen)
		    outbuf[outpos] = (state->grp[1] << 4 | state->grp[2] >> 2) 
			& 0xff;
		  outpos++;
		}
		if (state->pad < 1) {
		  if (outpos < outbuflen)
		    outbuf[outpos] = (state->grp[2] << 6 | state->grp[3]) 
			& 0xff;
		  outpos++;
		}
		state->n = 0;
		if (state->pad)
		    break;
	    }
	}

    /* Return -1 if there is non-whitespace after any padding */
    while (state->pad && inpos < inbuflen)
    {
	    char c = inbuf[inpos++];
	    if (dectab[(unsigned int)c] != -2)
    	    return -1;
    }

    return outpos;
}

int Base64Decoder::base64_decode_fini( base64_dec_state_t *state )
{
    /* Return -1 if there are undecodable characters remaining */
    if (state->n != 0)
    	return -1;

    return 0;
}
