#ifndef base64encoder_h
#define base64encoder_h

/***********************************************************************
*
*   Implements a "base64" encoder.
*   It is stream oriented. Keeps a state machine internally.
*
*   Usage:
*       Base64Encoder base64Encoder;
*       base64Encoder.InitStateMachine();
*       ...
*       // call encode as may times as you need on a stream
*       base64Encoder.Encode(...);
*       ...
*       base64Encoder.EndStateMachine();
*
***********************************************************************/
class Base64Encoder
{
    public:
        void    prepare();

        int     encode( const char* soruce, int sourceLength, 
                        char* destination,  int destinationLength );

        int     finish( char* destination, int destinationLength );


    public:
        // encodes a buffer into BASE64. the encoded data will be complete and finished.
        // returns the number of characters stored in "destination", including a trailing nul.
        // if the destination was too small, returns the number of characters that would have been stored.
        static int encodeBuffer(    const char* source, int sourceLength,
                                    char* destination,  int destinationLength );

        
    protected: // the internal engine to do the actual job
        typedef struct base64_enc_state
        {
            char grp[3];
            int  inpos;
        } base64_enc_state_t;

        // init the state machine by creating a valid encoder state with no history.
        void base64_encode_init( base64_enc_state_t *state );

        // encodes partial input into BASE64.
        // every 4 bytes of input will generate exactly 3 bytes of output,
        // if the input is not a multiple of 4 bytes, the state structure will be used to 
        // record the remainder to act as a prefix for later encoding calls.
        // returns the number of bytes that were written to the output buffer,
        // or, if the output buffer was too small, the number of bytes that would have been written 
        // if it were not too small. Returns -1 if there was an error.
        int base64_encode_sub( base64_enc_state_t *state, const char *inbuf, int inlen, char *outbuf, int outbuflen );

        // finishes encoding partial input into BASE64.
        // it will generate zero or four bytes of output.
        // returns the number of bytes that were (or would have been) written to the output buffer, 
        // or -1 if there was an error.
        int base64_encode_fini( base64_enc_state_t *state, char *outbuf, int outbuflen );

    protected:
        base64_enc_state_t state;
};

#endif
