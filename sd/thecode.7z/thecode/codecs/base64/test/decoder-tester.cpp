
// system headers
#include <stdio.h>
#include <string.h>

// local headers
#include "../decoder.h"

int main( int argc, char** argv )
{
    // preparation
    const char* appName = argv[0];
    const char* inputFileName = ".base64-encodedfile.data";
    const char* resultFileName = ".base64-encodedfile.data.result";

    int size = strlen(appName) + strlen(inputFileName);
    char* encodedFilePath = new char[ size ];
    if( 0 == encodedFilePath )
        return -1;
    memset( encodedFilePath, 0, size );
    strcat( encodedFilePath, appName    );
    strcat( encodedFilePath, inputFileName   );


    size = strlen(appName) + strlen(resultFileName);
    char* resultFilePath = new char[ size ];
    if( 0 == resultFilePath )
        return -1;
    memset( resultFilePath, 0, size );
    strcat( resultFilePath, appName         );
    strcat( resultFilePath, resultFileName  );


    FILE* inputFileHandle = fopen( encodedFilePath, "rb" );
    FILE* resultFileHandle = fopen( resultFilePath, "wb" );
    if( (0==inputFileHandle) || (0==resultFileHandle) )
        return -1;


    // do the decoding
    const int bufferSize = 4 * 1024;
    char inputBuffer[ bufferSize ] = { 0 };
    char outputBuffer[ bufferSize ] = { 0 };

    Base64Decoder base64Decoder;
    base64Decoder.prepare();

    while( !feof(inputFileHandle) )
    {
        size_t readSize = fread( inputBuffer, 1, bufferSize, inputFileHandle );

        // get the required size of the output buffer
        int decodedSize = base64Decoder.decode( inputBuffer, readSize, outputBuffer, bufferSize );

        fwrite( outputBuffer, decodedSize, 1, resultFileHandle );
    }

    base64Decoder.finish();

    fclose( inputFileHandle );
    fclose( resultFileHandle );

    delete [] encodedFilePath;
    delete [] resultFilePath;

    return 0;
}
