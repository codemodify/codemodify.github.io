
// system headers
#include <stdio.h>
#include <string.h>

// local headers
#include "../encoder.h"

int main( int argc, char** argv )
{
    // preparation
    const char* appName = argv[0];
    const char* inputFileName = ".datafile.data";
    const char* resultFileName = ".datafile.data.result";

    int size = strlen(appName) + strlen(inputFileName);
    char* encodedFilePath = new char[ size ];
    if( 0 == encodedFilePath )
        return -1;
    memset( encodedFilePath, 0, size );
    strcat( encodedFilePath, appName    );
    strcat( encodedFilePath, inputFileName   );


    size = strlen(appName) + strlen(resultFileName);
    char* resultFilePath = new char[ size ];
    if( 0 == resultFilePath )
        return -1;
    memset( resultFilePath, 0, size );
    strcat( resultFilePath, appName         );
    strcat( resultFilePath, resultFileName  );


    FILE* inputFileHandle = fopen( encodedFilePath, "rb" );
    FILE* resultFileHandle = fopen( resultFilePath, "wb" );
    if( (0==inputFileHandle) || (0==resultFileHandle) )
        return -1;


    // do the decoding
    const int bufferSize = 4 * 1024;
    char inputBuffer[ bufferSize ] = { 0 };
    char outputBuffer[ 2*bufferSize ] = { 0 };
    int encodedSize = 0;

    Base64Encoder base64Encoder;
    base64Encoder.prepare();

    while( !feof(inputFileHandle) )
    {
        size_t readSize = fread( inputBuffer, 1, bufferSize, inputFileHandle );

        // get the required size of the output buffer
        encodedSize = base64Encoder.encode( inputBuffer, readSize, outputBuffer, bufferSize );

        fwrite( outputBuffer, encodedSize, 1, resultFileHandle );
    }

    encodedSize = base64Encoder.finish( outputBuffer, bufferSize );
    fwrite( outputBuffer, encodedSize, 1, resultFileHandle );

    fclose( inputFileHandle );
    fclose( resultFileHandle );

    delete [] encodedFilePath;
    delete [] resultFilePath;

    return 0;
}
