
// local headers
#include "encoder.h"

static char enctab[] =  "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                        "abcdefghijklmnopqrstuvwxyz"
                        "0123456789+/";

void Base64Encoder::prepare()
{
    base64_encode_init( &state );
}

int Base64Encoder::encode( const char* soruce, int sourceLength, char* destination, int destinationLength )
{
    return base64_encode_sub( &state, soruce, sourceLength, destination, destinationLength );
}

int Base64Encoder::finish( char* destination, int destinationLength )
{
    return base64_encode_fini( &state, destination, destinationLength );
}

int Base64Encoder::encodeBuffer( const char* source, int sourceLength, char* destination,  int destinationLength )
{
    int encodedLength = 0;

    Base64Encoder encoder;
    encoder.prepare();
    encodedLength = encoder.encode( source, sourceLength, destination, destinationLength );
    encodedLength+= encoder.finish( destination, destinationLength );

    return encodedLength;
}

void Base64Encoder::base64_encode_init( base64_enc_state_t *state )
{
    state->inpos = 0;
}

int Base64Encoder::base64_encode_sub( base64_enc_state_t *state, const char *inbuf, int inbuflen, char *outbuf, int outbuflen )
{
    int inpos = 0;
    int outpos = 0;

    /* Encode as many whole input triples into 4 output chars as possible */
    while (inpos < inbuflen) {
	state->grp[(state->inpos + inpos) % 3] = inbuf[inpos]; inpos++;
	if ((state->inpos + inpos) % 3 == 0) {
	    if (outpos < outbuflen)
		outbuf[outpos] = enctab[(state->grp[0] & 0xfc) >> 2 & 0x3f];
	    outpos++;
	    if (outpos < outbuflen)
		outbuf[outpos] = enctab[((state->grp[0] & 0x03) << 4 |
				      (state->grp[1] & 0xf0) >> 4) & 0x3f];
	    outpos++;
	    if (outpos < outbuflen)
		outbuf[outpos] = enctab[((state->grp[1] & 0x0f) << 2 | 
				      (state->grp[2] & 0xc0) >> 6) & 0x3f];
	    outpos++;
	    if (outpos < outbuflen)
		outbuf[outpos] = enctab[state->grp[2] & 0x3f];
	    outpos++;
	}
    }
    state->inpos = state->inpos + inpos;
    return outpos;
}

int Base64Encoder::base64_encode_fini( base64_enc_state_t *state, char *outbuf, int outbuflen )
{
    int outpos = 0, i;

    /* Handle remaining characters that don't fit into a triple */
    if (state->inpos % 3 != 0) {
	for (i = state->inpos % 3; i < 3; i++)
	    state->grp[i] = 0;
	if (outpos < outbuflen)
	    outbuf[outpos] = enctab[(state->grp[0] & 0xfc) >> 2 & 0x3f];
	outpos++;
	if (outpos < outbuflen)
	    outbuf[outpos] = enctab[((state->grp[0] & 0x03) << 4 |
				  (state->grp[1] & 0xf0) >> 4) & 0x3f];
	outpos++;
	if (outpos < outbuflen)
	    outbuf[outpos] = (state->inpos % 3 > 1) 
		? enctab[((state->grp[1] &0x0f) << 2) & 0x3f]
		: '=';
	outpos++;
	if (outpos < outbuflen)
	    outbuf[outpos] = '=';
	outpos++;
    }

    return outpos;
}
