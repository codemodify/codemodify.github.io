#ifndef base64decoder_h
#define base64decoder_h

/***********************************************************************
*
*   Implements a "base64" decoder.
*   It is stream oriented. Keeps a state machine internally.
*
*   Usage:
*       Base64Decoder base64Decoder;
*       base64Decoder.initStateMachine();
*       ...
*       // call encode as may times as you need on a stream
*       base64Decoder.decode(...);
*       ...
*       base64Decoder.endStateMachine();
*
***********************************************************************/
class Base64Decoder
{
    public:
        void    prepare();

        int     decode( const char* source, int sourceLength, 
                        char* destination,  int destinationLength );

        int     finish();


    public:
        // Decodes characters in inbuf into outbuf.
        // Non-BASE64 characters in the inbuf are ignored.
        // Returns the number of characters stored in outbuf. 
        // If the outbuf was too small, returns the number of characters that would 
        // have been stored had it been big enough.
        // Returns -1 if there are spurious characters.
        static int decodeBuffer(    const char* source, int sourceLength,
                                    char* destination,  int destinationLength );


    protected: // the internal engine to do the actual job
        typedef struct base64_dec_state
        {
            char grp[4];
            int inpos;
            int pad;
            int n;
        } base64_dec_state_t;


        // init the state machine by creating a valid encoder state with no history.
        void base64_decode_init( base64_dec_state_t *state );

        // decodes partial input into BASE64.
        // every 4 bytes of input will generate exactly 3 bytes of output,
        // if the input is not a multiple of 4 bytes, the state structure will be used to 
        // record the remainder to act as a prefix for later encoding calls.
        // returns the number of bytes that were written to the output buffer,
        // or, if the output buffer was too small, the number of bytes that would have been written 
        // if it were not too small. Returns -1 if there was an error.
        int base64_decode_sub( base64_dec_state_t *state, const char *inbuf, int inlen, char *outbuf, int outbuflen );

        // finishes decoding partial BASE64 input into binary output.
        // failure occurs only when there is more BAS64 input expected.
        // once called, the state variable should not be used again without re-initializing.
        // returns 0 on success, or -1 if more BASE64 characters were expected.
        int base64_decode_fini( base64_dec_state_t *state );

    protected:
        base64_dec_state_t state;
};

#endif
