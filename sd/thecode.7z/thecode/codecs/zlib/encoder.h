#ifndef zlibencoder_h
#define zlibencoder_h


// local headers
#include "../codec.h"


// forwards
struct z_stream;


/************************************************************************
*
*   Implements a Zlib encoder.
*   Note: zlib format is different from the gzip or zip formats.
*
*   It is stream oriented.
*
*   Usage:
*       ZlibEncoder zlibEncoder;
*       zlibEncoder.setBufferSize( 128 * 1024 );
*       zlibEncoder.setCompressionLevel( 6 );
*       zlibEncoder.encode( plainData, plainDataLength, encodedBuffer, encodedBufferLength );
*
************************************************************************/
class ZLibEncoder : public Encoder
{
    public:
        CodecError init();
        CodecError encode(  Byte* source,       Length sourceLength, 
                            Byte* destination,  Length destinationLength );
        CodecError terminate();

    private:
        z_stream* _zlibStream;
};

#endif
