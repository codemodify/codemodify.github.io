
// local headers
#include "encoder.h"
#include "zlib/zlib.h"


CodecError ZLibEncoder::init()
{
    _zlibStream = new z_stream();
    memset( _zlibStream, 0, sizeof(z_stream) );

    int result = deflateInit( _zlibStream, level );
    if( result != Z_OK )
    {
        delete _zlibStream;
        _zlibStream = 0;

        return eInitError;
    }
}

CodecError ZLibEncoder::encode( Byte* source, Length sourceLength, Byte* destination,  Length destinationLength )
{
    
}

CodecError ZLibEncoder::terminate()
{
    if( 0 != _zlibStream )
        delegate _zlibStream;
}





int ZlibEncoder::compress( const char *input, const char *output, int level )
{
    err = Z_OK;
    avail_in = 0;
    avail_out = output_length;
    next_out = output_buffer;
    m_AbortFlag = 0;

    fin  = fopen( input, "rb" );
    fout = fopen( output, "wb" );
    length = filelength( fileno(fin) );

    deflateInit( this, level );

    for( ; ; )
    {
        if( m_AbortFlag )
            break;

        if( !load_input() )
            break;

        err = deflate( this, Z_NO_FLUSH );
        
        flush_output();
        
        if ( err != Z_OK )
            break;

        progress( percent() );
    }

    for( ; ; )
    {
        if( m_AbortFlag )
            break;

        err = deflate( this, Z_FINISH );
        if( !flush_output() )
            break;

        if( err != Z_OK )
            break;
    }

    progress( percent() );

    deflateEnd( this );

    if ( m_AbortFlag )
        status( "User Abort" );
    else if ( err != Z_OK && err != Z_STREAM_END )
        status( "Zlib Error" );
    else
    {
        status( "Success" );
        err = Z_OK;
    }

    fclose( fin );
    fclose( fout );
    
    fin = 0;
    fout = 0;
    
    if ( m_AbortFlag )
        return Z_USER_ABORT;
    else
        return err;
}

int ZlibEncoder::decompress( const char *input,
                            const char *output )
{
    err = Z_OK;
    avail_in = 0;
    avail_out = output_length;
    next_out = output_buffer;
    m_AbortFlag = 0;

    fin  = fopen( input, "rb" );
    fout = fopen( output, "wb" );
    length = filelength( fileno( fin ) );
    inflateInit( this );
    for ( ; ; )
    {
        if ( m_AbortFlag )
            break;
        if ( !load_input() )
            break;
        err = inflate( this, Z_NO_FLUSH );
        flush_output();
        if ( err != Z_OK )
            break;
        progress( percent() );
    }
    for ( ; ; )
    {
        if ( m_AbortFlag )
            break;
        err = inflate( this, Z_FINISH );
        if ( !flush_output() )
            break;
        if ( err != Z_OK )
            break;
    }
    progress( percent() );
    inflateEnd( this );
    if ( m_AbortFlag )
        status( "User Abort" );
    else if ( err != Z_OK && err != Z_STREAM_END )
        status( "Zlib Error" );
    else {
        status( "Success" );
        err = Z_OK;
    }
    if ( fin )
        fclose( fin );
    fin = 0;
    if ( fout )
        fclose( fout );
    fout = 0;
    if ( m_AbortFlag )
        return Z_USER_ABORT;
    else
        return err;
}

int ZlibEncoder::percent()
{
    if( length == 0 )
        return 100;

    else if( length > 10000000L )
        return ( total_in / ( length / 100 ) );

    else
        return ( total_in * 100 / length );
}

int ZlibEncoder::load_input()
{
    if ( avail_in == 0 )
    {
        next_in = input_buffer;
        avail_in = fread( input_buffer, 1, input_length, fin );
    }

    return avail_in;
}

int ZlibEncoder::flush_output()
{
    unsigned int count = output_length - avail_out;
    if( count )
    {
        if ( fwrite( output_buffer, 1, count, fout ) != count )
        {
            err = Z_ERRNO;
            return 0;
        }

        next_out = output_buffer;
        avail_out = output_length;
    }

    return count;
}
