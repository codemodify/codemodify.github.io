using System;

namespace OnlineDevelopmentPlatform
{
	namespace SourceControlManager
	{
		public enum FileState
		{
			normal, opened, locked, deleted, rename
		};
	}
}
