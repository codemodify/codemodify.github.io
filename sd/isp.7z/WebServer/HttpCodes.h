#ifndef __HttpCodes_H__
#define __HttpCodes_H__

#define HTTP_OK "HTTP/1.1 200 OK\r\nServer: InternetServerPlatform, WebServer Module\r\n\r\n"

#endif
