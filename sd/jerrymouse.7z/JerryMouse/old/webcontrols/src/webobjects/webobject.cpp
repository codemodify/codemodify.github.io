
#include "webobject.h"

WebObject::WebObject()
{}

WebObject::~WebObject()
{}
