#ifndef button_h
#define button_h

#include "../input.h"

namespace XHtmlElements
{
	/*****************************************************
	*
	*	Define the "input button" from XHTML
	*
	******************************************************/
	class Button : public Input
	{
	public:
		Button();
		~Button();
	
	};
};

#endif
