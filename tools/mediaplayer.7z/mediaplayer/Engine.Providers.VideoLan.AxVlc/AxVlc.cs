﻿using System;

namespace MediaPlayer.Engine.Providers.VideoLan
{
    public class AxVlc : Engine.AbstractEngine
    {
        private axvlcWrapper _vlcWrapper = new axvlcWrapper();

        #region Constructor
                public AxVlc() :
                    base()
                {}
        #endregion

        #region Play()
                public override void Play( String filePath )
                {
                    _vlcWrapper.Play( filePath );

                    base.Play( filePath );
                }
        #endregion

        #region Stop()
                public override void Stop()
                {
                    _vlcWrapper.Stop();

                    base.Stop();
                }
        #endregion

        #region Pause()
                public override void Pause()
                {
                    _vlcWrapper.Pause();

                    base.Pause();
                }
        #endregion
    }
}
