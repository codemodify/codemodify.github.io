﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MediaPlayer.Engine.Providers.VideoLan
{
    class axvlcWrapper
    {
        private AXVLC.VLCPlugin2Class _videoLan = new AXVLC.VLCPlugin2Class();

        #region Play()
                public void Play( String filePath )
                {
                    try
                    {
                        try
                        {
                            if( _videoLan.playlist.isPlaying )
                                _videoLan.playlist.stop();
                        }
                        catch( Exception )
                        {}

                        _videoLan.playlist.clear();
                        _videoLan.playlist.add( filePath, "1", "1" );
                        _videoLan.playlist.playItem( 0 );
                    }
                    catch( Exception )
                    {}
                }
        #endregion

        #region Stop()
                public void Stop()
                {
                    try
                    {
                        _videoLan.playlist.stop();
                    }
                    catch( Exception )
                    {}
                }
        #endregion

        #region Pause()
                public void Pause()
                {
                    try
                    {
                        _videoLan.pause();
                    }
                    catch( Exception )
                    {}
                }
        #endregion
    }
}
