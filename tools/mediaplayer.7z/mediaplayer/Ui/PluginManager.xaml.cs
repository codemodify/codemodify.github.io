﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace MediaPlayer
{
    /// <summary>
    /// Interaction logic for PluginManager.xaml
    /// </summary>
    public partial class PluginManager : Window
    {
        CollectionViewSource pluginList;
        private ObservableCollection<PluginItem> pluginsItems = new ObservableCollection<PluginItem>();

        public ObservableCollection<PluginItem> PluginsItems
        {
            get { return this.pluginsItems; }
            set { this.pluginsItems  = value; }
        }

        public PluginManager()
        {
            InitializeComponent();

            pluginList = (CollectionViewSource)(this.Resources["listingDataView"]);

           this.PluginList.Items.Add("jjjjjjjjjjjjj");

        }
    }
}
