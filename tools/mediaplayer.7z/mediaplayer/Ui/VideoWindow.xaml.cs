﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;

namespace MediaPlayer
{
    public partial class VideoWindow : Window
    {
        public VideoWindow()
        {
            InitializeComponent();
        }

        public IntPtr GetVideoOutputArea()
        {
            return windowsFormsHost1.Child.Handle;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void closButton_Click(object sender, RoutedEventArgs e)
        {
            Hide();
        }
    }
}
