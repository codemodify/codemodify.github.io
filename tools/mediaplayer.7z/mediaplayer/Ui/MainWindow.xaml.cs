﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.IO;
using Microsoft.Win32;

namespace MediaPlayer.Ui
{
    public partial class MainWindow : Window
    {
        Engine.IEngine                  _engine         = new Engine.Providers.VideoLan.LibVlc();
        VideoWindow                     _videoWindow    = new VideoWindow();
        Dictionary< String, String >    _playList       = new Dictionary< String, String >();

        public MainWindow()
        {
            InitializeComponent();
        }

        #region setFolderButton_Click()
        private void setFolderButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog  openFileDialog = new OpenFileDialog();
                            openFileDialog.CheckPathExists = true;
                            openFileDialog.ShowDialog();

            if( openFileDialog.FileName.Equals(String.Empty) )
                return;
            
            FileInfo fileInfo = new FileInfo( openFileDialog.FileName );
            
            String[] files =  Directory.GetFiles( fileInfo.DirectoryName );

            _fileListing.Items.Clear();
            _playList.Clear();

            foreach( String file in files )
            {
                fileInfo = new FileInfo( file );

                _playList.Add( fileInfo.Name, file );

                ListBoxItem item = new ListBoxItem();
                            item.MouseDoubleClick += fileListItemDoubleClicked;
                            item.Content = fileInfo.Name;

                _fileListing.Items.Add( item );
            }
        }
        #endregion

        #region playHelpler()
        private void playHelpler( String urlToPlay )
        {
            if( _engine.IsPlaying )
                _engine.Stop();

            _videoWindow.Show();
            _engine.SetVideoWindow( _videoWindow.GetVideoOutputArea() );
            _engine.Play( urlToPlay );
        }        
        #endregion

        #region fileListItemDoubleClicked()
        private void fileListItemDoubleClicked( object sender, MouseEventArgs args )
        {
            if( 0 == _fileListing.Items.Count )
                return;

            ListBoxItem item = sender as ListBoxItem;

            playHelpler( _playList[ item.Content.ToString() ] );
        }
        #endregion

        #region playButton_Click()
        private void playButton_Click(object sender, RoutedEventArgs e)
        {
            if( 0 == _fileListing.Items.Count )
                return;

            if( null == _fileListing.SelectedValue )
                _fileListing.SelectedIndex = 0;

            ListBoxItem item = _fileListing.SelectedItem as ListBoxItem;

            playHelpler( _playList[ item.Content.ToString() ] );
        }
        #endregion

        #region pauseButton_Click()
        private void pauseButton_Click(object sender, RoutedEventArgs e)
        {
            _engine.Pause();
        }
        #endregion

        #region nextButton_Click()
        private void nextButton_Click(object sender, RoutedEventArgs e)
        {
            _fileListing.SelectedIndex += 1;

            playButton_Click( sender, e );
        }
        #endregion

        #region stopButton_Click()
        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            _engine.Stop();
        }
        #endregion

        #region Window_MouseDown()
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if( e.LeftButton == MouseButtonState.Pressed )
                this.DragMove();
        }
        #endregion

        private void PluginManager_Click(object sender, RoutedEventArgs e)
        {
            PluginManager   pluginManager = new PluginManager();
                            pluginManager.Show();
        }
    }
}
