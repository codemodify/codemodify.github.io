﻿using System;
using System.Runtime.InteropServices;

namespace MediaPlayer.Engine.Providers.VideoLan.libvlcWrapper
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct libvlc_exception_t
    {
        public int b_raised;
        public int i_code;
        public string psz_message;
    }

    class Status : Exception
    {
        #region imports

        [DllImport("libvlc")]
        private static extern void libvlc_exception_init( ref  libvlc_exception_t p_exception );

        [DllImport("libvlc")]
        private static extern int libvlc_exception_raised( ref  libvlc_exception_t p_exception );

        [DllImport("libvlc")]
        private static extern string libvlc_exception_get_message( ref  libvlc_exception_t p_exception );

        #endregion

        internal libvlc_exception_t _vlcException;

        public Status() : base()
        {
            _vlcException = new libvlc_exception_t();

            libvlc_exception_init( ref _vlcException );
        }

        public bool HasErrors
        {
            get
            {
                return ( 0 != libvlc_exception_raised(ref _vlcException) );
            }
        }

        public override string Message
        {
            get
            {
                return libvlc_exception_get_message( ref _vlcException );
            }
        }
    }
}