﻿using System;

namespace MediaPlayer.Engine.Providers.VideoLan
{
    public class LibVlc : Engine.AbstractEngine, IDisposable
    {
        libvlcWrapper.Core      _coreInstance   = null;
        libvlcWrapper.Player    _playerInstance = null;

        #region Constructor
                public LibVlc() :
                    base()
                {
                    string[] args = new string[]
                    {
                        "-I", "dummy",
                        "--ignore-config",
                        String.Format( "--plugin-path={0}plugins", AppDomain.CurrentDomain.BaseDirectory ),
                        "--vout-filter=deinterlace",
                        "--vout-event=3",
                        "--deinterlace-mode=blend"
                    };

                    _coreInstance = new libvlcWrapper.Core( args );
                }

                public void Dispose()
                {
                    if( null != _playerInstance )
                        _playerInstance.Dispose();

                    _coreInstance.Dispose();
                }
        #endregion

        #region Play()
                public override void Play( String filePath )
                {
                    using( libvlcWrapper.Media media = new libvlcWrapper.Media(_coreInstance, filePath) )
                    {
                        _playerInstance = new libvlcWrapper.Player( media, _windowHandle );
                    }

                    _playerInstance.Play();

                    // call the base implementation
                    base.Play( filePath );
                }
        #endregion

        #region Stop()
                public override void Stop()
                {
                    if( null != _playerInstance )
                        _playerInstance.Stop();

                    // call the base implementation
                    base.Stop();
                }
        #endregion

        #region Pause()
                public override void Pause()
                {
                    if( null != _playerInstance )
                        _playerInstance.Pause();

                    // call the base implementation
                    base.Pause();
                }
        #endregion
    }
}
