﻿using System;
using System.Runtime.InteropServices;

namespace MediaPlayer.Engine.Providers.VideoLan.libvlcWrapper
{
    class Player : IDisposable
    {
        #region Imports

        [DllImport("libvlc")]
        public static extern IntPtr libvlc_media_player_new_from_media( IntPtr media, ref libvlc_exception_t ex );

        [DllImport("libvlc")]
        public static extern void libvlc_media_player_release( IntPtr player );

        [DllImport("libvlc")]
        public static extern void libvlc_media_player_set_drawable( IntPtr player, IntPtr drawable, ref libvlc_exception_t p_e );

        [DllImport("libvlc")]
        public static extern void libvlc_media_player_play( IntPtr player, ref libvlc_exception_t ex );

        [DllImport("libvlc")]
        public static extern void libvlc_media_player_pause( IntPtr player, ref libvlc_exception_t ex );

        [DllImport("libvlc")]
        public static extern void libvlc_media_player_stop( IntPtr player, ref libvlc_exception_t ex );

        #endregion

        internal    IntPtr  _instance;
        private     IntPtr  _drawable;

        public Player( Media media, IntPtr drawable )
        {
            Status status = null;

            // create a media player
            {
                status = new Status();
                _instance = libvlc_media_player_new_from_media( media._instance, ref status._vlcException );

                if( status.HasErrors )
                    throw new Exception( status.ToString() );
            }
            
            // set output window
            {
                status = new Status();
                libvlc_media_player_set_drawable( _instance, drawable, ref status._vlcException );

                if( status.HasErrors )
                    throw new Exception( status.ToString() );
            }
        }

        public void Dispose()
        {
            Stop();
            libvlc_media_player_release( _instance );
        }

        public void Play()
        {
            Status status = new Status();
            libvlc_media_player_play( _instance, ref status._vlcException );

            if( status.HasErrors )
                throw new Exception( status.ToString() );
        }

        public void Pause()
        {
            Status status = new Status();
            libvlc_media_player_pause( _instance, ref status._vlcException );

            if( status.HasErrors )
                throw new Exception( status.ToString() );
        }

        public void Stop()
        {
            Status status = new Status();
            libvlc_media_player_stop( _instance, ref status._vlcException );

            if( status.HasErrors )
                throw new Exception( status.ToString() );
        }
    }
}
