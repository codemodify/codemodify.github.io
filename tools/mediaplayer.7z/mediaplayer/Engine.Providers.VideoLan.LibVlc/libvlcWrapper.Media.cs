﻿using System;
using System.Runtime.InteropServices;

namespace MediaPlayer.Engine.Providers.VideoLan.libvlcWrapper
{
    class Media : IDisposable
    {
        #region Imports

        [DllImport("libvlc")]
        public static extern IntPtr libvlc_media_new( IntPtr p_instance, string psz_mrl, ref libvlc_exception_t p_e );

        [DllImport("libvlc")]
        public static extern void libvlc_media_release( IntPtr p_meta_desc );

        #endregion

        internal IntPtr _instance;

        public Media( Core core, string url )
        {
            Status status = new Status();

            _instance = libvlc_media_new( core._instance, url, ref status._vlcException );

            if( status.HasErrors )
                throw new Exception( status.ToString() );
        }

        internal Media( IntPtr instance )
        {
            this._instance = instance;
        }

        public void Dispose()
        {
            libvlc_media_release( _instance );
        }
    }
}
