﻿using System;
using System.Runtime.InteropServices;

namespace MediaPlayer.Engine.Providers.VideoLan.libvlcWrapper
{
    class Core : IDisposable
    {
        #region Imports
        [DllImport("libvlc")]
        public static extern IntPtr libvlc_new( int argc, string[] argv, ref libvlc_exception_t ex );

        [DllImport("libvlc")]
        public static extern void libvlc_release( IntPtr instance );
        #endregion

        internal IntPtr _instance;

        public Core( string[] args )
        {
            Status status = new Status();

            _instance = libvlc_new( args.Length, args, ref status._vlcException );
            
            if( status.HasErrors )
                throw new Exception( status.ToString() );
        }

        public void Dispose()
        {
            libvlc_release( _instance );
        }
    }
}
