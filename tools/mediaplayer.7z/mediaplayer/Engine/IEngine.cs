﻿using System;

namespace MediaPlayer.Engine
{
    public interface IEngine
    {
        // delegates
        event EventHandler OnPlayFinish;
        event EventHandler OnStop;
        event EventHandler OnPause;
        event EventHandler OnResume;

        // properties
        bool IsPlaying
        {
            get;
        }

        // actions
        void Play( String filePath );
        void Stop();
        void Pause();

        void SetVideoWindow( IntPtr windowHandle );        
    }
}
