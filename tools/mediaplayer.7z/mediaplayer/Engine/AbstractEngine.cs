﻿using System;

namespace MediaPlayer.Engine
{
    public abstract class AbstractEngine : IEngine
    {
        protected bool      _isPlaying;
        protected IntPtr    _windowHandle;

        public event EventHandler OnPlay;
        public event EventHandler OnPlayFinish;
        public event EventHandler OnStop;
        public event EventHandler OnPause;
        public event EventHandler OnResume;

        public bool IsPlaying
        {
            get{ return _isPlaying; }
        }

        #region Constructor()
                public AbstractEngine()
                {
                    _isPlaying      = false;
                    _windowHandle   = IntPtr.Zero;
                }
        #endregion

        #region Play()
                public virtual void Play( String filePath )
                {
                    if( null != OnPlay )
                        OnPlay( this, null );

                    _isPlaying = true;
                }
        #endregion

        #region Stop()
                public virtual void Stop()
                {
                    if( null != OnStop )
                        OnStop( this, null );

                    _isPlaying = false;
                }
        #endregion

        #region Pause()
                public virtual void Pause()
                {
                    if( _isPlaying )
                    {
                        if( null != OnPause )
                            OnPause( this, null );

                        _isPlaying = false;
                    }

                    else
                    {
                        if( null != OnResume )
                            OnResume( this, null );

                        _isPlaying = true;
                    }
                }
        #endregion

        #region SetVideoWindow()
                public virtual void SetVideoWindow( IntPtr windowHandle )
                {
                    _windowHandle = windowHandle;
                }
        #endregion
    }
}
