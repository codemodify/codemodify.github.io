
// qt headers
#include <QtGui/QHBoxLayout>
#include <QtGui/QVBoxLayout>
#include <QtGui/QPushButton>

// local headers
#include "sqldataviewer.h"

SqlDataViewer::SqlDataViewer() : 
	QWidget(),
	_query(""),
	_tableName(""),
	_filter("")
{
	// query model
	_queryModel = new QSqlQueryModel();

	// data viewer
	_tableView = new QTableView();
	_tableView->setModel( _queryModel );
	_tableView->setAlternatingRowColors( true );
	_tableView->setSelectionBehavior( QAbstractItemView::SelectRows );
	_tableView->setShowGrid( false );

	// buttons
	QPushButton* gotoBegin = new QPushButton( "|<< egin" );
	QPushButton* gotoPrevious = new QPushButton( "|< previous" );
	QPushButton* gotoNext = new QPushButton( "next  >|" );
	QPushButton* gotoEnd = new QPushButton( "end >>|" );
	QPushButton* refresh = new QPushButton( "refresh" );

	QHBoxLayout* layoutForButtons = new QHBoxLayout();
	layoutForButtons->addWidget( gotoBegin );
	layoutForButtons->addWidget( gotoPrevious );
	layoutForButtons->addWidget( gotoNext );
	layoutForButtons->addWidget( gotoEnd );
	layoutForButtons->addStretch();
	layoutForButtons->addWidget( refresh );

	// layout all the UI controls 
	QVBoxLayout* layoutForAll = new QVBoxLayout( this );
	layoutForAll->addWidget( _tableView );
	layoutForAll->addLayout( layoutForButtons );

	// prepare the click handlers for buttons
	connect( gotoBegin,       SIGNAL(clicked(bool)), this, SLOT(slot_gotoBegin())      );
	connect( gotoPrevious, SIGNAL(clicked(bool)), this, SLOT(slot_gotoPrevious()) );
	connect( gotoNext,         SIGNAL(clicked(bool)), this, SLOT(slot_gotoNext())         );
	connect( gotoEnd,          SIGNAL(clicked(bool)), this, SLOT(slot_gotoEnd())           );	
	connect( refresh,           SIGNAL(clicked(bool)), this, SLOT(slot_refresh())             );

	// sync the action between the UI controls with the model-data
	_dataWidgetMapper = new QDataWidgetMapper();
	_dataWidgetMapper->setModel( _queryModel );
	connect( _dataWidgetMapper, SIGNAL(currentIndexChanged(int)), this, SLOT(slot_dataIndexChanged(int)) );
	
	QItemSelectionModel* itemSelctionModel = _tableView->selectionModel();
	connect( itemSelctionModel, SIGNAL(currentRowChanged(const QModelIndex&,const QModelIndex&)), this, SLOT(slot_rowChanged(const QModelIndex&,const QModelIndex&)));
}

SqlDataViewer::~SqlDataViewer()
{
}

void SqlDataViewer::setTableName( QString tableName )
{
	_tableName = tableName;

	slot_refresh();
}

void SqlDataViewer::slot_gotoBegin()
{
	_dataWidgetMapper->toFirst();
}

void SqlDataViewer::slot_gotoPrevious()
{
	_dataWidgetMapper->toPrevious();
}

void SqlDataViewer::slot_gotoNext()
{
	_dataWidgetMapper->toNext();
}

void SqlDataViewer::slot_gotoEnd()
{
	_dataWidgetMapper->toLast();
}

void SqlDataViewer::slot_refresh()
{
	_query = QString("SELECT * FROM %1 %2").arg(_tableName).arg(_filter);

	_queryModel->setQuery( _query );
}

void SqlDataViewer::slot_dataIndexChanged( int index )
{
	_tableView->selectRow( index );
}

void SqlDataViewer::slot_rowChanged( const QModelIndex& current, const QModelIndex& previous )
{
	_dataWidgetMapper->setCurrentModelIndex( current );
}
