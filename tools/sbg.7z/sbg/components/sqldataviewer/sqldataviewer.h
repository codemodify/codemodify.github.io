#ifndef _SQLDATAVIEWER_H_
#define _SQLDATAVIEWER_H_

#include <QtGui/QWidget>
#include <QtGui/QTableView>
#include <QtGui/QDataWidgetMapper>
#include <QtSql/QSqlQueryModel>
#include <QtCore/QPointer>

class SqlDataViewer : public QWidget
{
	Q_OBJECT

public:
	SqlDataViewer();
	~SqlDataViewer();

	void setTableName( QString tableName );

private:
	QPointer<QTableView> _tableView;
	QPointer<QSqlQueryModel> _queryModel;
	QPointer<QDataWidgetMapper> _dataWidgetMapper;
	
private:
	QString _query;
	QString _tableName;
	QString _filter;

private slots:
	void slot_gotoBegin();
	void slot_gotoPrevious();
	void slot_gotoNext();
	void slot_gotoEnd();

	void slot_refresh();

	void slot_dataIndexChanged( int index );
	void slot_rowChanged( const QModelIndex& current, const QModelIndex& previous );

};

#endif
