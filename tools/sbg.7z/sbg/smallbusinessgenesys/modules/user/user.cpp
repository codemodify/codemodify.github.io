
// qt headers
#include <QtGui/QVBoxLayout>
#include <QtGui/QSplitter>

// local headers
#include "user.h"

// some defines
#define MODULE_ID "User"

Q_EXPORT_PLUGIN2( user, User )

User::User() :
	QWidget(),
	Module()
{
	// building the left side of the GUI
	_sqlDataViewer = new SqlDataViewer();
	_sqlDataViewer->setTableName( "Person" );

	// building the right side of the GUI
	_userDetails = new UserDetails( false );

	// adding all built widgets to the form
	QSplitter* splitter = new QSplitter();
	splitter->addWidget( _sqlDataViewer );
	splitter->addWidget( _userDetails );

	QVBoxLayout* layoutForAll = new QVBoxLayout( this );
	layoutForAll->addWidget( splitter );
}

User::~User()
{}

QString User::getDisplayName()
{
	return MODULE_ID;
}

QIcon User::getIcon()
{
	return QIcon();
}

/*
void User::slot_addUser()
{
	QPointer<UserDetails> userDetails = new UserDetails( true );

	userDetails->exec();
	
	slot_refresh();
}

void User::slot_deleteUser()
{
}
*/
