#ifndef USER_DETAILS_H
#define USER_DETAILS_H

// Qt headers
#include <QtGui/QDialog>
#include <QtGui/QLineEdit>
#include <QtGui/QTextEdit>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtCore/QString>
#include <QtCore/QPointer>


class UserDetails : public QDialog
{

	Q_OBJECT

public:
	UserDetails( bool isAddUserMode );
	~UserDetails();
	
	QString getDisplayName();

public: // returns the operation resutl that heppened on the form
	bool getOperationResult();

public: // set related stuff
	void setUserID( QString userID );
	void setName1( QString name1 );
	void setName2( QString name3 );
	void setName3( QString name3 );
	void setAddress( QString address );
	void setPhone( QString phone );
	void setPhoto( QByteArray photo );
	void setPassword( QString password );
	void setComment( QString comment );

public: // get related stuff
	QString getUserID();
	QString getName1();
	QString getName2();
	QString getName3();
	QString getAddress();
	QString getPhone();
	QByteArray getPhoto();
	QString getPassword();
	QString getComment();

private: // controls on the form that represent the user properties
	QPointer<QLineEdit> _name1;
	QPointer<QLineEdit> _name2;
	QPointer<QLineEdit> _name3;
	QPointer<QTextEdit> _address;
	QPointer<QLineEdit> _phone;
	QPointer<QLabel> _photo;
	QPointer<QLineEdit> _password;
	QPointer<QTextEdit> _comment;

private: // controls on the for that allow to change user properties
	QPointer<QPushButton> _buttonSaveAdd;
	QPointer<QPushButton> _buttonLoadPhoto;
private slots:
	void slot_loadPhoto();
	void slot_save();
	void slot_add();

private:
	QString _userID;
	bool _operationResult;

};

#endif
