
// qt headers
#include <QtSql/QSqlQuery>
#include <QtGui/QVBoxLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtCore/QUuid>
#include <QtGui/QFileDialog>
#include <QtGui/QLabel>
#include <QtGui/QPicture>
#include <QtGui/QApplication>

// local headers
#include "userdetails.h"

UserDetails::UserDetails( bool isAddUserMode ):
	QDialog(),
	_operationResult( false )
{
	setWindowTitle( getDisplayName() );

	QVBoxLayout* verticalLayout = new QVBoxLayout( this );
	
	QLabel* label;
	QVBoxLayout* gropupLayout;

	_name1 = new QLineEdit();
	label = new QLabel( "First Name" ); 
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _name1 );
	verticalLayout->addLayout( gropupLayout );

	_name2 = new QLineEdit();
	label = new QLabel( "Middle Name" );
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _name2 );
	verticalLayout->addLayout( gropupLayout );

	_name3 = new QLineEdit();
	label = new QLabel( "Last Name" );
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _name3 );
	verticalLayout->addLayout( gropupLayout );

	_address = new QTextEdit();
	label = new QLabel( "Address" );
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _address );
	verticalLayout->addLayout( gropupLayout );

	_phone = new QLineEdit();
	label = new QLabel( "Phone" );
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _phone );
	verticalLayout->addLayout( gropupLayout );

	_photo = new QLabel( "Photo" );
	QPushButton* loadPhoto = new QPushButton( "Load" );
	QHBoxLayout* horizontalGropupLayout = new QHBoxLayout();
	connect( loadPhoto, SIGNAL(clicked(bool)), this, SLOT(slot_loadPhoto()) );
	horizontalGropupLayout->addWidget( _photo );
	horizontalGropupLayout->addWidget( loadPhoto );
	verticalLayout->addLayout( horizontalGropupLayout );

	label = new QLabel( "Password" );
	_password = new QLineEdit();
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _password );
	verticalLayout->addLayout( gropupLayout );

	_comment = new QTextEdit();
	label = new QLabel( "Notes on user" );
	gropupLayout = new QVBoxLayout();
	gropupLayout->addWidget( label );
	gropupLayout->addWidget( _comment );
	verticalLayout->addLayout( gropupLayout );

	if( true == isAddUserMode ) // add
	{
		_buttonSaveAdd = new QPushButton( "Add" );
		connect( _buttonSaveAdd, SIGNAL(clicked(bool)), this, SLOT(slot_add()) );
	}
	else // save
	{
		_buttonSaveAdd = new QPushButton( "Save" );
		connect( _buttonSaveAdd, SIGNAL(clicked(bool)), this, SLOT(slot_save()) );
	}
	verticalLayout->addWidget( _buttonSaveAdd );
}

UserDetails::~UserDetails()
{}

QString UserDetails::getDisplayName()
{
	return "User Details";
}

void UserDetails::setUserID( QString userID )
{
	_userID = userID;
}

void UserDetails::setName1( QString name1 )
{
	_name1->setText( name1 );
}

void UserDetails::setName2( QString name2 )
{
	_name2->setText( name2 );
}

void UserDetails::setName3( QString name3 )
{
	_name3->setText( name3 );
}

void UserDetails::setAddress( QString address )
{
	_address->setPlainText( address );
}

void UserDetails::setPhone( QString phone )
{
	_phone->setText( phone );
}

void UserDetails::setPhoto( QByteArray photo )
{
	QPixmap pixmap;
	pixmap.loadFromData( photo );

	_photo->setPixmap( pixmap );
}

void UserDetails::setPassword( QString password )
{
	_password->setText( password );
}

void UserDetails::setComment( QString comment )
{
	_comment->setPlainText( comment );
}

QString UserDetails::getUserID()
{
	return _userID;
}

QString UserDetails::getName1()
{
	return _name1->text();
}

QString UserDetails::getName2()
{
	return _name2->text();
}

QString UserDetails::getName3()
{
	return _name2->text();
}

QString UserDetails::getAddress()
{
	return _address->toPlainText();
}

QString UserDetails::getPhone()
{
	return _phone->text();
}

QByteArray UserDetails::getPhoto()
{
	const QPicture* picture = _photo->picture();
	if( 0 == picture || picture->isNull() )
		return QByteArray();

	QByteArray byteArray( picture->data(), picture->size() );

	return byteArray;
}

QString UserDetails::getPassword()
{
	return _password->text();
}

QString UserDetails::getComment()
{
	return _comment->toPlainText();
}

void UserDetails::slot_loadPhoto()
{
	QString photoFile = QFileDialog::getOpenFileName( this, "Select a photo" );
	if( photoFile.isEmpty() )
		return;

	QPixmap pixmap(photoFile);
	_photo->setPixmap( pixmap );
}

void UserDetails::slot_add()
{
	setUserID( QUuid::createUuid().toString() );

	QSqlQuery sqlQuery;
	sqlQuery.prepare( "call personAdd( ?, ?, ?, ?, ?, ?, ?, ?, ? )" );
	sqlQuery.bindValue( 0, getUserID() );
	sqlQuery.bindValue( 1, getName1() );
	sqlQuery.bindValue( 2, getName2() );
	sqlQuery.bindValue( 3, getName3() );
	sqlQuery.bindValue( 4, getAddress() );
	sqlQuery.bindValue( 5, getPhone() );
	sqlQuery.bindValue( 6, getPhoto() );
	sqlQuery.bindValue( 7, getPassword() );
	sqlQuery.bindValue( 8, getComment() );
	_operationResult = sqlQuery.exec();

	if( !_operationResult )
	{
		QApplication::aboutQt();
		/*
		Logger::getInstance()->addError( "call of procedure personAdd()", getDisplayName() );
		
		Logger::getInstance()->addInfo( getUserID(), getDisplayName() );
		Logger::getInstance()->addInfo( getName1(), getDisplayName() ) ;
		Logger::getInstance()->addInfo( getName2(), getDisplayName() );
		Logger::getInstance()->addInfo( getName3(), getDisplayName() );
		Logger::getInstance()->addInfo( getAddress(), getDisplayName() );
		Logger::getInstance()->addInfo( getPhone(), getDisplayName() );
		Logger::getInstance()->addInfo( getPassword(), getDisplayName() );
		Logger::getInstance()->addInfo( getComment(), getDisplayName() );*/
	}
	
	close();
}

void UserDetails::slot_save()
{
	_operationResult = true;
	
	close();
}
