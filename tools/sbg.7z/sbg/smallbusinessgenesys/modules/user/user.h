#ifndef _USER_H_
#define _USER_H_

// qt headers
#include <QtCore/QPointer>

// local headers
#include "module.h"
#include "userdetails/userdetails.h"
#include "sqldataviewer/sqldataviewer.h"

class User : public QWidget, public Module
{
	Q_OBJECT
	Q_INTERFACES( Module )	

public:
	User();
	~User();

public: // must implement these from the plugin interface
	QString getDisplayName();
	QIcon getIcon();
	QWidget* getWindow(){ return this; }

private:
	QPointer<SqlDataViewer> _sqlDataViewer;	
	QPointer<UserDetails> _userDetails;

//private slots:
	//void slot_addUser();
	//void slot_deleteUser();

};

#endif
