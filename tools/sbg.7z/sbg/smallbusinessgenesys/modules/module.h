#ifndef _MODULE_H_
#define _MODULE_H_

// qt headers
#include <QtPlugin>
#include <QtGui/QIcon>
#include <QtGui/QWidget>
#include <QtCore/QString>


/****************************************************************************************
*
*	This class defines a interface for the modules for this application that will extend its functionality.
*
****************************************************************************************/
class Module
{
public:
	virtual ~Module(){};

public:
	virtual QString getDisplayName() = 0;
	virtual QIcon getIcon() = 0;
	virtual QWidget* getWindow() = 0;

};

Q_DECLARE_INTERFACE( Module, "mysd.plugins.Module/1.0" );

#endif
