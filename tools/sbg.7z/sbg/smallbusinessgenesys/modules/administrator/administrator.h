#ifndef _ADMINISTRATOR_H_
#define _ADMINISTRATOR_H_

// qt headers
#include <QtGui/QTabWidget>
#include <QtCore/QPointer>

// local headers
#include "module.h"

class Administrator : public QWidget, public Module
{
	Q_OBJECT
	Q_INTERFACES( Module )

public:
	Administrator();
	~Administrator();

public: // must implement these from the plugin interface
	QString getDisplayName();
	QIcon getIcon();
	QWidget* getWindow(){ return this; }

private:
	QPointer<QTabWidget> _tabWidget;

};

#endif
