
// qt headers
#include <QtGui/QVBoxLayout>

// local headers
#include "administrator.h"

// some defines
#define MODULE_ID "Administrator"

Q_EXPORT_PLUGIN2( administrator, Administrator )

Administrator::Administrator() :
	QWidget(),
	Module()
{
	setGeometry( 0, 0, 400, 300 );
	setWindowTitle( MODULE_ID );

	// adding the tab-widget
	_tabWidget = new QTabWidget();
	QVBoxLayout* verticalBoxLayout = new QVBoxLayout( this );
	verticalBoxLayout->addWidget( _tabWidget );

	// adding the module that manages users
	//User* user = new User();
	//_tabWidget->addTab( user, user->getDisplayName() );

}

Administrator::~Administrator()
{}

QString Administrator::getDisplayName()
{
	return MODULE_ID;
}

QIcon Administrator::getIcon()
{
	return QIcon();
}
