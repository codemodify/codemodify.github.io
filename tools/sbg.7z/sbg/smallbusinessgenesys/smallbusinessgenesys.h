#ifndef _SmallBusinessGenesys_h_
#define _SmallBusinessGenesys_h_

// qt headers
#include <QtGui/QApplication>
#include <QtCore/QPointer>
#include <QtCore/QMap>
#include <QtCore/QString>
#include <QtSql/QSqlDatabase>

// local headers
#include "mainwindow/mainwindow.h"

class SmallBusinessGenesys : public QApplication
{
	
	Q_OBJECT
	
public:
	SmallBusinessGenesys( int argc, char** argv );
	~SmallBusinessGenesys();

public:
	bool initialize();

private:
	int _dbPort;
	QString _dbHost;
	QString _dbName;
	QString _dbUser;
	QString _dbPassword;
	QSqlDatabase _dataBase;
	QMap<QString,QString> _modules;
	
	bool readSettings();
	bool connectToDB();
	bool loadModules();

private:
	QPointer<MainWindow> _mainWindow;
	void initializeGui();

};

#endif
