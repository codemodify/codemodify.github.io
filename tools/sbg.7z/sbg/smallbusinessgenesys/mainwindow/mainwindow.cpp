
// qt headers
#include <QtGui/QMenuBar>
#include <QtGui/QMenu>
#include <QtGui/QCloseEvent>
#include <QtGui/QAction>

// local headers
#include "mainwindow.h"
#include "smallbusinessgenesys/modules/module.h"
#include "components/logger/logger.h"

MainWindow::MainWindow( QString title ):
	QMainWindow()
{
	setWindowTitle( title );
	
	// menu
	setMenuBar( new QMenuBar() );

	QMenu* commonMenu = menuBar()->addMenu( title );
	commonMenu->addAction( "Help Me!", this, SLOT(slot_HelpMe()) );
	commonMenu->addAction( "Exit", this, SLOT(close()) );

	_modulesMenu = menuBar()->addMenu( "Modules" );

	// the MDI part of the GUI
	_workspace = new QWorkspace();
	setCentralWidget( _workspace );
}

MainWindow::~MainWindow()
{}

void MainWindow::closeEvent( QCloseEvent* event )
{
	_workspace->closeAllWindows();

	event->accept();
}

void MainWindow::slot_HelpMe()
{}

void MainWindow::updateGUI( Module* module )
{
	// we have a new module loaded, get some info about it and populate the menu
	QAction* action = new QAction( module->getIcon(), module->getDisplayName(), 0 );

	// store the pointer to the module	
	qulonglong pointerValue;
	memset( &pointerValue, 0, sizeof(qulonglong) );
	memcpy( &pointerValue, &module, sizeof(module) );

	QVariant  variantData( pointerValue );
	action->setData( variantData );

	// set a menu selection handler
	connect( action, SIGNAL(triggered(bool)), this, SLOT(slot_ModuleSelection()) );

	 _modulesMenu->addAction( action );
}

void MainWindow::slot_ModuleSelection()
{
	QObject* object = sender();
	QAction* action = qobject_cast<QAction*>( object );
	if( 0 == action )
		return;

	// getting the pointer to the module, the pointer was stored earlier
	QVariant  variantData = action->data();
	
	qulonglong pointerValue = variantData.toULongLong();
	Module* module;
	memcpy( &module, &pointerValue, sizeof(module) );
	
	QWidget* widget = module->getWindow();
	if( 0 == widget )
		return;

	_workspace->addWindow( widget );
	widget->showMaximized();
}
