#ifndef _MAINWINDOW_H_
#define _MAINWINDOW_H

// qt headers
#include <QtGui/QMainWindow>
#include <QtGui/QWorkspace>
#include <QtGui/QMenu>
#include <QtCore/QPointer>

class Module;

class MainWindow : public QMainWindow
{

	Q_OBJECT

public:
	MainWindow( QString title );
	~MainWindow();

public:
	void updateGUI( Module* module );

protected:
	void closeEvent( QCloseEvent* event );
	
private slots: // haldlers for the menu acions
	void slot_HelpMe();
	void slot_ModuleSelection();

private: // gui related
	QPointer<QWorkspace> _workspace;
	QPointer<QMenu> _modulesMenu;

};

#endif
