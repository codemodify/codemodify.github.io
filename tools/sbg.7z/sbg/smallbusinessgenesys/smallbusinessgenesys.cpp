
// qt headers
#include <QtXml/QDomDocument>
#include <QtCore/QFile>
#include <QtCore/QMapIterator>
#include <QtCore/QPluginLoader>
#include <QtCore/QDir>
#include <QtSql/QSqlError>
#include <QtGui/QIcon>
#include <QtGui/QMenuBar>


// local headers
#include "smallbusinessgenesys.h"
#include "components/logger/logger.h"
#include "modules/module.h"

// used by logger to identify the logs messages in log file
#define SMALL_BUSINESS_GENESYS "SmallBusinessGenesys"

SmallBusinessGenesys::SmallBusinessGenesys( int argc, char** argv ) :
	QApplication(argc,argv)
{
	Logger::createInstance();
	Logger::getInstance()->setLogFile();
	Logger::getInstance()->addInfo( QString("%1 is up and running").arg(SMALL_BUSINESS_GENESYS), SMALL_BUSINESS_GENESYS );
}

SmallBusinessGenesys::~SmallBusinessGenesys()
{
	_modules.clear();

	Logger::getInstance()->addInfo( QString("%1 is going down").arg(SMALL_BUSINESS_GENESYS), SMALL_BUSINESS_GENESYS );
	Logger::destroyInstance();
}

bool SmallBusinessGenesys::initialize()
{
	bool result = readSettings();
	if( false == result )
		return false;

	result = connectToDB();
	if( false == result )
		return false;
		
	initializeGui();

	result = loadModules();
	if( false == result )
		return false;
		
	_mainWindow->show();

	return true;
}

void SmallBusinessGenesys::initializeGui()
{
	// build the main window
	_mainWindow = new MainWindow( SMALL_BUSINESS_GENESYS );
}

bool SmallBusinessGenesys::readSettings()
{
	// loading the settings file into memory
	Logger::getInstance()->addInfo( "trying to load settins", SMALL_BUSINESS_GENESYS );

	QString settingsFilePath = QApplication::applicationFilePath() + ".settings";
	Logger::getInstance()->addInfo( QString("settings file to use: %1").arg(settingsFilePath), SMALL_BUSINESS_GENESYS );

	QFile settingsFile( settingsFilePath );
	if( false == settingsFile.open(QFile::ReadOnly) )
	{
		Logger::getInstance()->addError( "The settings can't be read bcasue file can not be found", SMALL_BUSINESS_GENESYS );
		return false;
	}

	QDomDocument domDocument;
	QString errorMessage;
	if( false == domDocument.setContent(&settingsFile,&errorMessage) )
	{
		Logger::getInstance()->addError( QString("The settings can't be read, reason: %1").arg(errorMessage), SMALL_BUSINESS_GENESYS );
		settingsFile.close();
		return false;
	}
	settingsFile.close();

	// at this point we ensure that the settings file was read into memory. Now we have to parse it and read data that we need
	Logger::getInstance()->addInfo( tr("The following settings were read:"), SMALL_BUSINESS_GENESYS );

	// getting the "root" node
	QDomNode rootNode = domDocument.documentElement();

	// getting the "db" node
	QDomNode dbNode = rootNode.firstChild();
	QDomNode node = dbNode.firstChild();
	while( false == node.isNull() )
	{
		QDomNamedNodeMap nodeAttributes = node.attributes();

		if( node.toElement().tagName() == "databaseName" )
			_dbName = nodeAttributes.namedItem("value").nodeValue();

		else if( node.toElement().tagName() == "databaseUserName" )
			_dbUser = nodeAttributes.namedItem("value").nodeValue();

		else if( node.toElement().tagName() == "databasePassword" )
			_dbPassword = nodeAttributes.namedItem("value").nodeValue();

		else if( node.toElement().tagName() == "databaseHost" )
			_dbHost = nodeAttributes.namedItem("value").nodeValue();

		else if( node.toElement().tagName() == "databasePort" )
			_dbPort = nodeAttributes.namedItem("value").nodeValue().toInt();

		node = node.nextSibling();
	}
	Logger::getInstance()->addInfo( QString("databaseName: %1").arg(_dbName), SMALL_BUSINESS_GENESYS );
	Logger::getInstance()->addInfo( QString("databaseUserName: %1").arg(_dbUser), SMALL_BUSINESS_GENESYS );
	Logger::getInstance()->addInfo( QString("databasePassword: %1").arg(_dbPassword), SMALL_BUSINESS_GENESYS );
	Logger::getInstance()->addInfo( QString("databaseHost: %1").arg(_dbHost), SMALL_BUSINESS_GENESYS );
	Logger::getInstance()->addInfo( QString("databasePort: %1").arg(_dbPort), SMALL_BUSINESS_GENESYS );

	return true;
}

bool SmallBusinessGenesys::connectToDB()
{
	Logger::getInstance()->addInfo( "trying to connect to DB" , SMALL_BUSINESS_GENESYS );

	_dataBase = QSqlDatabase::addDatabase( "QMYSQL" );
	_dataBase.setDatabaseName( _dbName );
	_dataBase.setUserName( _dbUser );
	_dataBase.setPassword( _dbPassword );
	_dataBase.setHostName( _dbHost );
	_dataBase.setPort( _dbPort );

	if( false == _dataBase.open() )
	{
		Logger::getInstance()->addError( "failed to connect to DB", SMALL_BUSINESS_GENESYS );
		Logger::getInstance()->addError( QString("Reason: %1").arg(_dataBase.lastError().text()), SMALL_BUSINESS_GENESYS );
		return false;
	}

	Logger::getInstance()->addInfo( "the DB connection was successful", SMALL_BUSINESS_GENESYS );

	return true;
}

bool SmallBusinessGenesys::loadModules()
{
	QString modulesPath = QApplication::applicationDirPath() + "/modules/";
	
	QDir dir( modulesPath );
	dir.setFilter( QDir::Files | QDir::NoDotAndDotDot );
	QStringList modules = dir.entryList();
	
	foreach( QString module, modules )
	{
		QString moduleFilePath = dir.absoluteFilePath(module);
		
		QPointer<QPluginLoader> pluginLoader = new QPluginLoader( moduleFilePath );
		if( false == pluginLoader->load() )
		{
			Logger::getInstance()->addError( QString("module %1 was not loaded, error: %2").arg(moduleFilePath).arg(pluginLoader->errorString()), SMALL_BUSINESS_GENESYS );
			return false;
		}
		
		Logger::getInstance()->addInfo( QString("module %1 was loaded").arg(moduleFilePath), SMALL_BUSINESS_GENESYS );
		
		QObject* object = pluginLoader->instance();
		Module* module = qobject_cast<Module*>( object );
		if( 0 == module )
		{
			Logger::getInstance()->addError( QString("module %1 was loaded but can't get a valid instance").arg(moduleFilePath), SMALL_BUSINESS_GENESYS );			
			return false;
		}

		_mainWindow->updateGUI( module );
	}
	
	return true;
}
