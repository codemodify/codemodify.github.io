
#include "smallbusinessgenesys/smallbusinessgenesys.h"

int main( int argc, char** argv )
{
	SmallBusinessGenesys smallBusinessGenesys( argc, argv );
	
	bool initializationResult = smallBusinessGenesys.initialize();
	if( false == initializationResult )
	{
		smallBusinessGenesys.quit();
		return -1;
	}

	return smallBusinessGenesys.exec();
}
