﻿
CommentBox = function(){};

// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----
// ---- Config
// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----
CommentBox.Config = function(){};
CommentBox.Config._prefix               = '';
CommentBox.Config._pageTitle            = 'Comment Box';
CommentBox.Config._pageContentID        = 'CommentBoxID';
CommentBox.Config._pageContent          = '<div> This is a test </div>';
CommentBox.Config._pageContentWidth     = '600';
CommentBox.Config._pageContentHeight    = '700';

// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----
// ---- Helpers
// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----
CommentBox.Helpers = function(){};
CommentBox.Helpers.includeJsFile = function( file )
{
    var script = document.createElement( 'script' );
        script.src   = CommentBox.Config._prefix === '' ? file : CommentBox.Config._prefix + '/' + file;
        script.type  = 'text/javascript';
        script.defer = true;

    document.getElementsByTagName( 'head' ).item( 0 ).appendChild( script );
}

CommentBox.Helpers.includeCssFile = function( file )
{
    var css = document.createElement( 'link' );
        css.rel  = 'stylesheet';
        css.href = CommentBox.Config._prefix + '/' + file;
        css.type = 'text/css';

    document.getElementsByTagName( 'head' ).item( 0 ).appendChild( css );
}

// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----
// ---- CommentBox API
// ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ----
CommentBox.Init = function()
{
    CommentBox.Config._pageContent = document.createElement( 'object' );
    CommentBox.Config._pageContent.setAttribute( "type", 'text/html' );
    CommentBox.Config._pageContent.setAttribute( 'data', CommentBox.Config._prefix + '/' + 'commentbox.html' );
    CommentBox.Config._pageContent.setAttribute( 'id'  , CommentBox.Config._pageContentID );
    CommentBox.Config._pageContent.width  = '100%'; //CommentBox.Config._pageContentWidth  + 'px';
    CommentBox.Config._pageContent.height = '99%'; //CommentBox.Config._pageContentHeight + 'px';

    CommentBox.Helpers.includeJsFile ( 'tools/commentbox/modalbox/prototype.js' );
    CommentBox.Helpers.includeJsFile ( 'tools/commentbox/modalbox/effects.js'   );
    CommentBox.Helpers.includeJsFile ( 'tools/commentbox/modalbox/builder.js'   );
    CommentBox.Helpers.includeJsFile ( 'tools/commentbox/modalbox/modalbox.js'  );
    CommentBox.Helpers.includeCssFile( 'tools/commentbox/modalbox/modalbox.css' );
}

CommentBox.Show = function()
{
    Modalbox.show
    (
        CommentBox.Config._pageContent,
        {
            title:  CommentBox.Config._pageTitle,
            width:  CommentBox.Config._pageContentWidth,
            height: CommentBox.Config._pageContentHeight
        }
    );
}
