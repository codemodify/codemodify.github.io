This information and license notice covers the images in this directory.

/////////////////////////////////////////////////////////

Title: PICOL, Pictorial Commnuication Language
Designer: Melih Bilgil
URL: http://www.picol.org
E-Mail: dropaline@picol.org

Date: 07-03-2009
Desc.: Pre-release of the PICOL Icons (16x16 Pixel)

/////////////////////////////////////////////////////////

This work is licensed under a Creative Commons Attribution-Share Alike 3.0 Unported License. http://creativecommons.org/licenses/by-sa/3.0/

You are free:
- to Share — to copy, distribute and transmit the work
- to Remix — to adapt the work

Under the following conditions:
Attribution. 
Include a link to picol.org or blog.picol.org in your credits or any fitting place.

Share Alike. 
If you alter, transform, or build upon this work, you may distribute the resulting work only under the same, similar or a compatible license.

/////////////////////////////////////////////////////////

Feel free to send me a mail dropaline@picol.org with a link or a screenshot of your project, if you´ve used the PICOL signs.

Have fun with it. I hope you like the icons.

/////////////////////////////////////////////////////////
All available icons can be found on 
http://blog.picol.org/downloads/icons