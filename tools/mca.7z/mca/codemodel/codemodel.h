#ifndef CODE_MODEL_H
#define CODE_MODEL_H

// Qt's headers
#include <QtCore/QAbstractItemModel>
#include <QtXml/QDomDocument>

class CodeModel : public QAbstractItemModel
{

	Q_OBJECT

public:
	CodeModel();
	~CodeModel();
	void setData( QString xmlFile );

// Item Data Handling ####################################
public:
	// Read-Only Access
	Qt::ItemFlags flags( const QModelIndex& index ) const;
	QVariant data( const QModelIndex& index, int role = Qt::DisplayRole ) const;
	QVariant headerData( int section, Qt::Orientation orientation, int role = Qt::DisplayRole ) const;
	int rowCount( const QModelIndex& parent = QModelIndex() ) const;
	int columnCount( const QModelIndex& parent = QModelIndex() ) const;

	// Editable Items
	bool setData( const QModelIndex& index, const QVariant& value, int role = Qt::EditRole );
	bool setHeaderData( int section, Qt::Orientation orientation, const QVariant& value, int role = Qt::EditRole );

	// Resizable Models
	bool insertRows( int row, int count, const QModelIndex& parent = QModelIndex() );
	bool removeRows( int row, int count, const QModelIndex& parent = QModelIndex() );
	bool insertColumns( int column, int count, const QModelIndex& parent = QModelIndex() );
	bool removeColumns( int column, int count, const QModelIndex& parent = QModelIndex() );


// Navigation and Model Index Creation ###################
public:
	// Parents and Children
	QModelIndex index( int row, int column, const QModelIndex& parent = QModelIndex() ) const;
	QModelIndex parent( const QModelIndex& index ) const;


// The model's source data, it is stored as a DOM representation loaded from a XML file
private:
	QDomDocument _domDocument;
	QDomNode _solutionNode;
	QDomNode _projectsNode;

	QString getNodeAttribute( QDomNode node, QString attribute );

};

#endif
