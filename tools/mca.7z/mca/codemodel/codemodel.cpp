
// local headers
#include "codemodel.h"

CodeModel::CodeModel():
	QAbstractItemModel()
{
}

CodeModel::~CodeModel()
{
}

// Item Data Handling #################################################################################################
// Read-Only Access
Qt::ItemFlags CodeModel::flags( const QModelIndex& index ) const
{
	if( false == index.isValid() )
		Qt::ItemIsEnabled;

	return Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsEditable;
}

QVariant CodeModel::data( const QModelIndex& index, int role ) const
{
	if( false == index.isValid() )
		return QVariant();

	if( role != Qt::DisplayRole )
		return QVariant();

	QDomNode node = static_cast<QDomNode>(index.internalPointer());

	return node.attribbutes().namedItem("name").nodeValue();
}

QVariant CodeModel::headerData( int section, Qt::Orientation orientation, int role = Qt::DisplayRole ) const
{
	if( (orientation==Qt::Horizontal) && (role==Qt::DisplayRole) )
		return _solutionNode.attribbutes().namedItem("name").nodeValue();

	return QVariant();
}

int CodeModel::rowCount( const QModelIndex& parent ) const
{
	QDomNode parentNode;

	if( false == parent.isValid() )
		parentNode = _solutionNode;
	else
		parentNode = static_cast<QDomNode>(parent.internalPointer());

	// getting the number of children nodes
	int count = 0;
	QDomNode node = parentNode.firstChild();
	while( false == node.isNull() )
	{
		count++;

		node = node.nextSibling();
	}

	return count;
}

int CodeModel::columnCount( const QModelIndex& parent = QModelIndex() ) const
{
	return 1;
}

// Editable Items
bool CodeModel::setData( const QModelIndex& index, const QVariant& value, int role )
{
	return QAbstractItemModel::setData( index, value, role );
}

bool CodeModel::setHeaderData( int section, Qt::Orientation orientation, const QVariant& value, int role )
{
	return QAbstractItemModel::setHeaderData( section, orientation, value, role );
}

// Resizable Models
bool CodeModel::insertRows( int row, int count, const QModelIndex& parent )
{
	return QAbstractItemModel::insertRows( row, count, parent );
}

bool CodeModel::removeRows( int row, int count, const QModelIndex& parent )
{
	return QAbstractItemModel::removeRows( row, count, parent );
}

bool CodeModel::insertColumns( int column, int count, const QModelIndex& parent )
{
	return QAbstractItemModel::insertColumns( column, count, parent );
}

bool CodeModel::removeColumns( int column, int count, const QModelIndex& parent )
{
	return QAbstractItemModel::removeColumns( column, count, parent );
}


// Navigation and Model Index Creation ###########################################################################################
QModelIndex CodeModel::index( int row, int column, const QModelIndex& parent ) const
{
	// the node that is requested to be parent and identified by the 'parent' index
	QDomNode parentNode;

	if( false == parent.isValid() )
		parentNode = _solutionNode;
	else
		parentNode = static_cast<QDomNode>(parent.internalPointer());

	// trying to seek the required row
	QDomNode node = parentNode.firstChild();
	int currentRowNumber = -1;
	while( false == node.isNull() )
	{
		if( ++currentRowNumber == row )
			break;

		node = node.nextSibling();
	}

	// if we found requested child return an index then
	QDomNode childNode = node; 
	if( false == childNode.isNull() )
		return createIndex( row, column, childNode );
	else
		return QModelIndex();
	
}

QModelIndex CodeModel::parent( const QModelIndex& index ) const
{
	if( false == index.isValid() )
		return QModelIndex();

	QDomNode childNode = static_cast<QDomNode>(index.internalPointer());
	QDomNode parentNode = childNode.parentNode();

	if( parentNode == _solutionNode )
		return QModelIndex();

	// getting the 'row' for the node taken as a parent
	int row = 0;
	QDomNode node = parentNode.parentNode().firstChild();
	while( parentNode != node )
	{
		count++;
		node = node.nextSibling();
	}

	return createIndex( row, 0, parentNode );
}

