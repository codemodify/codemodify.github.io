﻿using System.Windows;

namespace WebNinja
{
    public partial class App : Application
    {
    }
}
