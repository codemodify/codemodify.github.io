#ifndef common_functionalities_h
#define common_functionalities_h

#define Text( theText ) _L(theText)
#define Number( theNumber ) theNumber

#define int__main GLDEF_C TInt E32Main

#endif
