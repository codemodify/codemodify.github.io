
// system headers
#include <aknviewappui.h>
#include <pathinfo.h>

// local headers
#include "resources/mmsc.hrh"						// for command handling
#include "sources/sdk-mini/Widget/Widget.h"			// to add arbitrary widgets
#include "sources/sdk-mini/Widget/Slider/Slider.h"	// to add sliders

#include "ImageView.h"

ImageView::ImageView( TInt resourceId ):
	View( resourceId, ImageViewID ),
	_cameraEngine( 0 ),
	_currentSlider( 0 ),
	_delegateKeysToWidgets( False ),
	_receivedTimes( 2 )
{}

ImageView::~ImageView()
{}

void ImageView::HandleCommandL( TInt aCommand )
{
    switch( aCommand )
    {
	    case    EAknSoftkeyExit:    AppUi()->HandleCommandL(EEikCmdExit);       break;
	    case eImageViewCommand1:	_cameraEngine->TakeShot();		            break; // shot
	    
	    case eImageViewCommand2:	DoZoom();									break; // zoom
	    
	    case eImageViewCommand3:	DoDigitalZoom();				            break; // digital zoom
	    
	    case eImageViewCommand6:	DoContrastManual();				            break;
	    case eImageViewCommand8:	_cameraEngine->SetParams_Brightness( CCamera::EBrightnessAuto );	break; // brightness
	    case eImageViewCommand9:	DoBrightnessManual();			            						break;
	    
	    case eImageViewCommand11:	_cameraEngine->SetParams_Flash( CCamera::EFlashNone );				break; // flash
	    case eImageViewCommand12:	_cameraEngine->SetParams_Flash( CCamera::EFlashAuto );				break;
	    case eImageViewCommand13:	_cameraEngine->SetParams_Flash( CCamera::EFlashForced );			break;
	    case eImageViewCommand14:	_cameraEngine->SetParams_Flash( CCamera::EFlashFillIn );			break;
	    case eImageViewCommand15:	_cameraEngine->SetParams_Flash( CCamera::EFlashRedEyeReduce );		break;
	    case eImageViewCommand16:	_cameraEngine->SetParams_Flash( CCamera::EFlashSlowFrontSync );		break;
	    case eImageViewCommand17:	_cameraEngine->SetParams_Flash( CCamera::EFlashSlowRearSync );		break;
	    case eImageViewCommand18:	DoFlashManual();				            						break;
	    
	    case eImageViewCommand20:	_cameraEngine->SetParams_Exposure( CCamera::EExposureAuto );			break; // exposure
	    case eImageViewCommand21:	_cameraEngine->SetParams_Exposure( CCamera::EExposureNight );			break;
	    case eImageViewCommand22:	_cameraEngine->SetParams_Exposure( CCamera::EExposureBacklight );		break;
	    case eImageViewCommand23:	_cameraEngine->SetParams_Exposure( CCamera::EExposureCenter );			break;
	    case eImageViewCommand24:	_cameraEngine->SetParams_Exposure( CCamera::EExposureSport );			break;
	    case eImageViewCommand25:	_cameraEngine->SetParams_Exposure( CCamera::EExposureVeryLong );		break;
	    case eImageViewCommand26:	_cameraEngine->SetParams_Exposure( CCamera::EExposureSnow );			break;
	    case eImageViewCommand27:	_cameraEngine->SetParams_Exposure( CCamera::EExposureBeach );			break;
	    case eImageViewCommand28:	_cameraEngine->SetParams_Exposure( CCamera::EExposureProgram );			break;
	    case eImageViewCommand29:	_cameraEngine->SetParams_Exposure( CCamera::EExposureAperturePriority );break;
	    case eImageViewCommand30:	_cameraEngine->SetParams_Exposure( CCamera::EExposureShutterPriority );	break;
	    case eImageViewCommand31:	DoExposureManual();				            							break;
	    case eImageViewCommand32:	_cameraEngine->SetParams_Exposure( CCamera::EExposureSuperNight );		break;
	    case eImageViewCommand33:	_cameraEngine->SetParams_Exposure( CCamera::EExposureInfra );			break;
	    
	    case eImageViewCommand35:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBAuto );				break; // awb
	    case eImageViewCommand36:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBDaylight );			break;
	    case eImageViewCommand37:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBCloudy );			break;
	    case eImageViewCommand38:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBTungsten );			break;
	    case eImageViewCommand39:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBFluorescent );		break;
	    case eImageViewCommand40:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBFlash );				break;
	    case eImageViewCommand41:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBSnow );				break;
	    case eImageViewCommand42:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBBeach );				break;
	    case eImageViewCommand43:	DoAwbManual();					            							break;
	    case eImageViewCommand44:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBShade );				break;
	    case eImageViewCommand45:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBAutoSkin );			break;
	    case eImageViewCommand46:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBHorizon );			break;
	    case eImageViewCommand47:	_cameraEngine->SetParams_WhiteBalance( CCamera::EWBDaylightUnderWater );break;
	    
	    case eImageViewCommand49:	_cameraEngine->SetParams_Portrait();									break; // orientation
	    case eImageViewCommand50:	_cameraEngine->SetParams_Landscape();									break;
	    				 default:	AppUi()->HandleCommandL( aCommand );									break;
    }
}

void ImageView::DoActivateL(	const TVwsViewId& UNUSED(aPrevViewId), 
								TUid UNUSED(aCustomMessageId),
								const TDesC8& UNUSED(aCustomMessage)	)
{
	// init the content of the image view and set it
	Widget* imageViewContent = new Widget();
	this->SetViewContent( imageViewContent );
	
	_cameraEngine = new CameraEngine();
//	BindEvent( _cameraEngine, CFbsBitmap&, this, ImageView::ViewFinderImageReady );	// images from viewfinders
//	_cameraEngine->_imageShot = this;
//	_cameraEngine->_imageShotDelegate = CameraEngine::ImageShot::Delegate( &ImageView::ShotImageReady );
//	BindEvent( _cameraEngine, CFbsBitmap*, this, ImageView::ShotImageReady );		// images after picture taking
//	_cameraEngine->SetParams_ImageSize( imageViewContent->Size() );
	_cameraEngine->StartViewFinder( GetViewContent() );
}

void ImageView::DoDeActivate()
{
	delete _cameraEngine;
	_cameraEngine = 0;
	
	View::DoDeactivate();
}

void ImageView::ViewFinderImageReady( CFbsBitmap& bitmap )
{
	CCoeControl* controlToDrawOn = GetViewContent();
	if( !controlToDrawOn )
		return;

	// Calculate position for finder bitmaps (centered on component)
	// iFinderPosition is the top-left coordinate for bitmap
	TSize finderSize = controlToDrawOn->Size();
	TRect rect = controlToDrawOn->Rect();
	
	TPoint iFinderPosition;
	iFinderPosition = rect.iTl;
	iFinderPosition.iX += ( rect.Size().iWidth - finderSize.iWidth   ) / 2;
	iFinderPosition.iY += ( rect.Size().iHeight - finderSize.iHeight ) / 2;

  	// Get graphics context
    CWindowGc& graphicsContext = controlToDrawOn->SystemGc();
    graphicsContext.Activate( *controlToDrawOn->DrawableWindow() );
    graphicsContext.BitBlt( iFinderPosition, &bitmap );
    graphicsContext.Deactivate();

	// rotate the bitmap
//    CFbsBitmap* iBitmap = new(ELeave) CFbsBitmap();
//    iBitmap->Create( TSize(0,0), EColor256 );
//        
//    CImageHandler* iImageHandler = new (ELeave) CImageHandler( *iBitmap, iEikonEnv->FsSession(), *this );
//    iImageHandler->ConstructL();

//    // draw the bitmap
//	TRect rect = controlToDrawOn->Rect();
//
//	TPoint point;
//	point.SetXY( rect.iTl.iX, rect.iTl.iY );
//
//    CWindowGc& graphicsContext = controlToDrawOn->SystemGc();
//    graphicsContext.Activate( *controlToDrawOn->DrawableWindow() );
//    graphicsContext.BitBlt( point, &bitmap );
//    graphicsContext.Deactivate();
}

void ImageView::ShotImageReady( CFbsBitmap* bitmap )
{
	static Int counter = 0;
	counter++;

	String counterAsString;
	IntToString( counter, counterAsString );

	// save the image
	TFileName fileName = PathInfo::PhoneMemoryRootPath();
	fileName.Append( PathInfo::ImagesPath() );
	fileName.Append( counterAsString );
	fileName.Append( TEXT(".jpg") );

	String theFileName;
	theFileName.Append( fileName );
	_cameraEngine->SaveImage( bitmap->Handle(), theFileName );
}

void ImageView::DoZoom()
{
	_currentSlider = new Slider();
	
	Int zoomCurrent = 0;
	_cameraEngine->GetParams_ZoomFactor( zoomCurrent );

	Int zoomMin = 0;
	_cameraEngine->GetParams_ZoomFactorMin( zoomMin );

	Int zoomMax = 0;
	_cameraEngine->GetParams_ZoomFactorMax( zoomMax );
	
	_currentSlider->SetMinValue( zoomMin );
	_currentSlider->SetMaxValue( zoomMax );
	_currentSlider->SetValue( zoomCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    
	
	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );
	
	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::ZoomChanged );	
}

void ImageView::ZoomChanged( const Int& newValue )
{
	_cameraEngine->SetParams_ZoomFactor( newValue );
}

void ImageView::DoDigitalZoom()
{
	_currentSlider = new Slider();
	
	Int digitalZoomCurrent = 0;
	_cameraEngine->GetParams_DigitalZoomFactor( digitalZoomCurrent );

	Int digitalZoomMin = 0;
	_cameraEngine->GetParams_DigitalZoomFactorMin( digitalZoomMin );

	Int digitalZoomMax = 0;
	_cameraEngine->GetParams_DigitalZoomFactorMax( digitalZoomMax );
	
	_currentSlider->SetMinValue( digitalZoomMin );
	_currentSlider->SetMaxValue( digitalZoomMax );
	_currentSlider->SetValue( digitalZoomCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    
	
	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );
	
	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::DigitalZoomChanged );
}

void ImageView::DigitalZoomChanged( const Int& newValue )
{
	_cameraEngine->SetParams_DigitalZoomFactor( newValue );
}

void ImageView::DoContrastManual()
{
	_currentSlider = new Slider();

	Int contrastCurrent = 0;
	_cameraEngine->GetParams_Contrast( contrastCurrent );

	Int contrastMin = 0;
	_cameraEngine->GetParams_ContrastMin( contrastMin );

	Int contrastMax = 0;
	_cameraEngine->GetParams_ContrastMax( contrastMax );

	_currentSlider->SetMinValue( contrastMin );
	_currentSlider->SetMaxValue( contrastMax );
	_currentSlider->SetValue( contrastCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    

	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );

	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::ContrastChanged );
}

void ImageView::ContrastChanged( const Int& newValue )
{
	_cameraEngine->SetParams_Contrast( newValue );
}

void ImageView::DoBrightnessManual()
{
	_currentSlider = new Slider();

	Int brightnessCurrent = 0;
	_cameraEngine->GetParams_Brightness( brightnessCurrent );

	Int brightnessMin = 0;
	_cameraEngine->GetParams_BrightnessMin( brightnessMin );

	Int brightnessMax = 0;
	_cameraEngine->GetParams_BrightnessMax( brightnessMax );

	_currentSlider->SetMinValue( brightnessMin );
	_currentSlider->SetMaxValue( brightnessMax );
	_currentSlider->SetValue( brightnessCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    

	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );

	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::BrightnessChanged );
}

void ImageView::BrightnessChanged( const Int& newValue )
{
	_cameraEngine->SetParams_Brightness( newValue );
}

void ImageView::DoFlashManual()
{
	_currentSlider = new Slider();

	Int flashCurrent = 0;
	_cameraEngine->GetParams_Flash( flashCurrent );

	Int flashMin = 0;
	_cameraEngine->GetParams_FlashMin( flashMin );

	Int flashMax = 0;
	_cameraEngine->GetParams_FlashMax( flashMax );

	_currentSlider->SetMinValue( flashMin );
	_currentSlider->SetMaxValue( flashMax );
	_currentSlider->SetValue( flashCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    

	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );

	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::FlashChanged );
}

void ImageView::FlashChanged( const Int& newValue )
{
	_cameraEngine->SetParams_Flash( (CCamera::TFlash)newValue );
}

void ImageView::DoExposureManual()
{
	_currentSlider = new Slider();

	Int exposureCurrent = 0;
	_cameraEngine->GetParams_Exposure( exposureCurrent );

	Int exposureMin = 0;
	_cameraEngine->GetParams_ExposureMin( exposureMin );

	Int exposureMax = 0;
	_cameraEngine->GetParams_ExposureMax( exposureMax );

	_currentSlider->SetMinValue( exposureMin );
	_currentSlider->SetMaxValue( exposureMax );
	_currentSlider->SetValue( exposureCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    

	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );

	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::ExposureChanged );
}

void ImageView::ExposureChanged( const Int& newValue )
{
	_cameraEngine->SetParams_Exposure( (CCamera::TExposure) newValue );
}

void ImageView::DoAwbManual()
{
	_currentSlider = new Slider();

	Int awbCurrent = 0;
	_cameraEngine->GetParams_WhiteBalance( awbCurrent );

	Int awbMin = 0;
	_cameraEngine->GetParams_WhiteBalanceMin( awbMin );

	Int awbMax = 0;
	_cameraEngine->GetParams_WhiteBalanceMax( awbMax );

	_currentSlider->SetMinValue( awbMin );
	_currentSlider->SetMaxValue( awbMax );
	_currentSlider->SetValue( awbCurrent );

	this->GetViewContent()->AddChildWidget( _currentSlider );
	this->GetViewContent()->FocusWidget( _currentSlider );	    

	// subcribe the new control for our key events
	BindEvent( this, TKeyEvent&, _currentSlider, Slider::KeyPress );

	// subscribe to the control's value changes
	BindEvent( _currentSlider, const Int&, this, ImageView::AwbChanged );
}

void ImageView::AwbChanged( const Int& newValue )
{
	_cameraEngine->SetParams_WhiteBalance( (CCamera::TWhiteBalance)newValue );
}

void ImageView::KeyPress( TKeyEvent& keyEvent )
{
	Widget* viewContent = GetViewContent();
	if( !viewContent )
		return;

	IsThisMiddleKey( keyEvent );
    if( _delegateKeysToWidgets )
    {
    	InformSubscribers( keyEvent );
    	return;
    }
	
    switch( keyEvent.iCode )
	{
        case EKeyUpArrow:
        	GetViewContent()->FocusNextWidget();
        	break;

        case EKeyDownArrow:
        	GetViewContent()->FocusPreviousWidget();
        	break;

        default:
            break;
    }
}

Bool ImageView::IsThisMiddleKey( TKeyEvent& keyEvent )
{
	const Int hackedScanCode = 167;
	
	if(	(keyEvent.iScanCode == hackedScanCode) && !keyEvent.iCode )
	{
		_receivedTimes--;
		
		_receivedTimes = !_receivedTimes ? 2 : _receivedTimes;
		
		if( _receivedTimes == 1 )
			_delegateKeysToWidgets = !_delegateKeysToWidgets;
	}
	
	return _delegateKeysToWidgets;
}
