#ifndef __ImageView_H__
#define __ImageView_H__

#include "sources/sdk-mini/types.h"
#include "sources/sdk-mini/View/View.h"
#include "sources/sdk-mini/CameraEngine/CameraEngine.h"

const TUid ImageViewID = {1};
const int ImageViewIDAsInt = 1;

class Slider;

class ImageView :	public View,
//					public Subscriber< CFbsBitmap& >,			// subscribe for bitmaps from viewfinder
//					public Subscriber< const CFbsBitmap* >,		// subscribe for bitmaps after taking pictures
					public CameraEngine::ImageShot,				// subscribe for bitmaps after taking pictures
					public Subscriber< TKeyEvent& >,			// subscribe for key events from UI
					public Subscriber< const Int& >,			// subscribe value changes in slider
					public SubscribersInformer< TKeyEvent& >	// emit the keyevents to children
{
    public:
    	ImageView( TInt resourceId );
        ~ImageView();

    // From CAknView
    public:
        void HandleCommandL( TInt aCommand );

    private:
        void DoActivateL(	const TVwsViewId& aPrevViewId, TUid aCustomMessageId,
        					const TDesC8& aCustomMessage );
        void DoDeActivate();

    // methods to implement view's functionality
	public:
		void DoShot();
		void ViewFinderImageReady( CFbsBitmap& bitmap );
		void ShotImageReady( CFbsBitmap* bitmap );
		
		void DoZoom();
		void ZoomChanged( const Int& newValue );
		
		void DoDigitalZoom();
		void DigitalZoomChanged( const Int& newValue );
		
		void DoContrastManual();
		void ContrastChanged( const Int& newValue );
		
		void DoBrightnessManual();
		void BrightnessChanged( const Int& newValue );
		
		void DoFlashManual();
		void FlashChanged( const Int& newValue );
		
		void DoExposureManual();
		void ExposureChanged( const Int& newValue );
		
		void DoAwbManual();
		void AwbChanged( const Int& newValue );

		void KeyPress( TKeyEvent& keyEvent );


    private:
    	CameraEngine*	_cameraEngine;
    	Slider*			_currentSlider;


	// verrry deep hide this fix for the trashy way to get key codes in Symbian.
	// the problem is that we recieve the event two times consecutively.
	// we need to ignore one.
	private:
	private:
	private:
	private:
		Int _receivedTimes;
		Bool IsThisMiddleKey( TKeyEvent& keyEvent );
		Bool _delegateKeysToWidgets;

};

#endif
