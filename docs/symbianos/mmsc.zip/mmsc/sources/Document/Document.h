#ifndef __Document_H__
#define __Document_H__

// system headers
#include <akndoc.h>

// forwards
class CEikApplication;

class Document : public CAknDocument
{
	public:
		Document( CEikApplication& application );
        virtual ~Document();

    // required by the framework
    private:
    	CEikAppUi* CreateAppUiL();

};

#endif

















































/**********************************************************
*
*	Note on why it is not used the designlessigness 
* 	and uglyness of the "NewL()" stuff:
*
*	- because if it leaves then you leave anyway
* 	  and you can't do a thing about it
* 
*	- because we do not want to do the job of system
* 	  in every our program by managing some kind of
* 	  stack definitions... The system is supposed to
* 	  be preemtive multitasking who does not rely on the
*	  user-space application's system-object manipulation,
*	  right ? Otherwise there is no point in all the published
* 	  books on symbian with obscured and distortioned information,
* 	  and all the scam may fall down one day. 
*
* 	- because you're at the Doc creation stage only,
* 	  and if the base of the program just crashed
*	  you do not have reasons to recover from something,
* 	  there is no such thing as "your program in the system".
* 
*	- why trap it ? just to show a stupid message
*	  that you just crashed ? Write a log instead
*	  and this way your program gets lighter as a 
*     final product when you debug it using logs.
* 	  Any way you can't do much about crashing here, here is why 
* 	  and here is why you debug it using logs:
* 	  o the panic messages are useless - as all the stuff else in the system - the level of qulity is achieved only because there is spent 5 times more time in a debut-state of the mind for a product. 
* 	  o the live-bugs-world of resources system is an unique piece of 'art' that leaves questions at every corner.
* 	  o there is no so much cofee around to go through the debug cycle again.
* 
* 	- it is lighter on money for your business to start considering
* 	  alternatives as linux, qnx, bsd, windows mobile, iPhone. 
* 	  The later 2 have superrior and unmatched integration and development cycle.
* 
*	- The "Symbian Portability" is a myth from old ages of dragons.
* 	  This system hardly runs on the same hardware with slightly different
* 	  release versions. The second hardware is buggy and useless emulator wich runs on windows only.
* 	  So to develop something reaaly breath taking you need at least:
* 	  - windows licence - 400 euro,
* 	  - a symbian licence - ( how is the membership for the religious sect of the DDK ? )
* 	  - carbide licence - 4000 euro ?
* 
* 	  Sumup: at minimum 5k euro for a developer to do what ? to strugle to draw a cube after you
* 	  overcome some state-of-the-art uglyness of a framework that pretends to implement MVC.
*
**********************************************************/
