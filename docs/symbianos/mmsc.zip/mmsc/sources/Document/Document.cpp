
// local headers
#include "sources/UserInterface/UserInterface.h"
#include "Document.h"

Document::Document( CEikApplication& application ) :
	CAknDocument( application )
{}

Document::~Document()
{}

CEikAppUi* Document::CreateAppUiL()
{
    return new (ELeave) UserInterface();
}
