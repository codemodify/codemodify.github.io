#ifndef __Application_H__
#define __Application_H__

// system headers
#include <aknapp.h>

class Application : public CAknApplication
{
	public:
		static EXPORT_C CApaApplication* Run();
	
	// required by the framework 
    private:
        CApaDocument* CreateDocumentL();
        TUid AppDllUid() const;

    private:
		static const TUid s_applicationId;

};

#endif
