
// local headers
#include    "Application.h"
#include    "sources/Document/Document.h"

const TUid Application::s_applicationId = { 0xE1EF0018 };

TUid Application::AppDllUid() const
{
    return s_applicationId;
}

CApaDocument* Application::CreateDocumentL()
{
    return new Document( *this );
}

EXPORT_C CApaApplication* Application::Run()
{
    return new Application();
}
