#ifndef __SystemView_H__
#define __SystemView_H__

#include <akntabgrp.h>	// For handling tabs
#include "sources/sdk-mini/View/View.h"

const TUid SystemViewID = {0};
const int SystemViewIDAsInt = 0;

class SystemView : public View
{
    public:
    	SystemView( TInt resourceId, CAknTabGroup* aTabGroup );
        ~SystemView();

	// From CAknView
    public:
        void HandleCommandL( TInt aCommand );

    private:
        void DoActivateL( const TVwsViewId& aPrevViewId,TUid aCustomMessageId, const TDesC8& aCustomMessage );


    private:
        CAknTabGroup* iTabGroup;

};

#endif
