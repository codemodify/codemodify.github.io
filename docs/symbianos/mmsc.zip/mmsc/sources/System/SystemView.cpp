
// system headers
#include  <aknviewappui.h>
#include  <PathInfo.h>
#include  <aknmessagequerydialog.h>

// local headers
#include "resources/mmsc.hrh"	// for command handling
#include "sources/sdk-mini/Widget/Widget.h" // to add arbitrary widgets
#include "sources/sdk-mini/CameraEngine/CameraEngine.h" // to work with camera
#include "sources/Image/ImageView.h"
#include "sources/Video/VideoView.h"
#include "SystemView.h"


SystemView::SystemView( TInt resourceId, CAknTabGroup* aTabGroup ):
	View( resourceId, SystemViewID )
{
    iTabGroup = aTabGroup;
}

SystemView::~SystemView()
{}

void SystemView::HandleCommandL(TInt aCommand)
{   
    switch( aCommand )
    {
        case EAknSoftkeyExit:
            AppUi()->HandleCommandL( EEikCmdExit );
            break;

        // get camera details, and what it supports
        case eSystemViewCommand1:
    	{
        	CameraEngine* cameraEngine = new CameraEngine();
        	if( !cameraEngine->IsCameraDetected() )
        	{
        		CEikonEnv::Static()->InfoMsg( _L("no camera detected") );
        		delete cameraEngine;
        		break;
        	}
        	
        	String string;
        	cameraEngine->GetCameraInfoAsString( string );
        	
    		// FIXME: fix the ugly API here to popup a dialog message
			CAknMessageQueryDialog* dialog = CAknMessageQueryDialog::NewL( string  );
			dialog->PrepareLC( R_AVKON_MESSAGE_QUERY_DIALOG );
			
			HBufC* hdr= HBufC::NewLC( 50 ); hdr->Des().Append( _L("MM-Solutions")); 
			dialog->QueryHeading()->SetTextL( hdr->Des() );
			CleanupStack::PopAndDestroy(); // hdr

			dialog->RunLD();
			// FIXME: fix the ugly API here to popup a dialog message
    	}
    	break;
            
        // go to image capture
        case eSystemViewCommand2:
            iTabGroup->SetActiveTabByIndex( ImageViewIDAsInt );
            AppUi()->ActivateLocalViewL( ImageViewID );
            break;
        
        // go to video recording 
        case eSystemViewCommand3:
            iTabGroup->SetActiveTabByIndex( VideoViewIDAsInt );
            AppUi()->ActivateLocalViewL( VideoViewID );
            break;

        // start media library
        case eSystemViewCommand4:
        	{
        	const TInt mediaGalleryId = 0x101f8599;
        	const TInt mediaGalleryListViewId = 0x00000001;
        	const TInt mediaGalleryCmdMoveFocusTo = 0x00000001;
        	
    	    // gets viewId to activate Media Gallery view
    	    TVwsViewId id = TVwsViewId( TUid::Uid(mediaGalleryId), TUid::Uid(mediaGalleryListViewId) );
    	
    	    // the images path from the system 
    		TFileName path = PathInfo::PhoneMemoryRootPath();
    		path.Append( PathInfo::ImagesPath() );

    		HBufC* imagePath = HBufC::NewL( path.Length() );
    		imagePath->Des().Copy( path );

    		const TDesC& temp = *imagePath;

    	    HBufC8* buf = HBufC8::NewLC( temp.Length() );
    	    buf->Des().Copy( temp );

    	    // activate the media gallery
    	    ActivateViewL( id, TUid::Uid(mediaGalleryCmdMoveFocusTo), *buf );
    	    CleanupStack::PopAndDestroy( buf );
        	}
            break;

        default:
            AppUi()->HandleCommandL( aCommand );
            break;
    }
}

void SystemView::DoActivateL( const TVwsViewId& /*viewId*/,TUid /*messageId*/, const TDesC8& /*message*/ )
{
	Widget* systemViewContent = new Widget();
	this->SetViewContent( systemViewContent );
}
