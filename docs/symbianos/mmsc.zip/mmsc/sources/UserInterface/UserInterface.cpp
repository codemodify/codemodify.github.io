
#include "UserInterface.h"

#include "sources/System/SystemView.h"
#include "sources/Image/ImageView.h"
#include "sources/Video/VideoView.h"

#include <mmsc.rsg>
#include "resources/mmsc.hrh"
#include "MSVSTD.HRH"
#include <avkon.hrh>

void UserInterface::ConstructL()
    {
    //Initialises this app UI with standard values.
    //The application�s standard resource file will be read unless
    //the ENoAppResourceFile or ENonStandardResourceFile flags are passed.
    BaseConstructL(0x08 | EAknEnableSkin); // Use ELayoutAwareAppFlag (0x08) to make the application support scalable UI on FP3 devices.


    // Show tabs for main views from resources
    CEikStatusPane* sp = StatusPane();

    // Fetch pointer to the default navi pane control
    iNaviPane = (CAknNavigationControlContainer*)sp->ControlL( TUid::Uid(EEikStatusPaneUidNavi) );

    // Tabgroup has been read from resource and it was pushed to the navi pane.
    // Get pointer to the navigation decorator with the ResourceDecorator() function.
    // Application owns the decorator and it has responsibility to delete the object.
    iDecoratedTabGroup = iNaviPane->ResourceDecorator();
    if (iDecoratedTabGroup)
        {
        iTabGroup = (CAknTabGroup*) iDecoratedTabGroup->DecoratedControl();
        }

    
    SystemView* view1 = new SystemView( RES_SYSTEMVIEW, iTabGroup );
    AddViewL( view1 );        // transfer ownership to CAknViewAppUi
    iViewId1 = view1->Id();   // view id to get view from CAknViewAppUi    


    ImageView* view2 = new ImageView( RES_IMAGEVIEW );
    AddViewL( view2 );
    iViewId2 = view2->Id();
	SetSubscriber( view2, Subscriber<TKeyEvent&>::Delegate(&ImageView::KeyPress) );

    
    VideoView* view3 = new VideoView( RES_VIDEOVIEW );
    AddViewL( view3 );      // transfer ownership to CAknViewAppUi
    iViewId3 = view3->Id(); // view id to get view from CAknViewAppUi

    SetDefaultViewL( *view1 );
    
    // Make this class observe changes in foreground events
    iEikonEnv->AddForegroundObserverL( *this );
    }

UserInterface::~UserInterface()
    {
    delete iDecoratedTabGroup;
    }

void UserInterface::DynInitMenuPaneL(
    TInt /*aResourceId*/,CEikMenuPane* /*aMenuPane*/)
    {
    }

void UserInterface::HandleForegroundEventL(TBool aForeground)
    {
    if (aForeground==TRUE)
    iEikonEnv->InfoMsg(_L("Foreground true"));
    else
    iEikonEnv->InfoMsg(_L("Foreground false"));

    }

TKeyResponse UserInterface::HandleKeyEventL( const TKeyEvent& aKeyEvent,TEventCode /*aType*/ )
{
    if ( iTabGroup == NULL )
        return EKeyWasNotConsumed;
 
    TInt active = iTabGroup->ActiveTabIndex();
    TInt count = iTabGroup->TabCount();

    switch( aKeyEvent.iCode )
    {
        case EKeyLeftArrow:
            if( active > 0 )
        	{
                active--;
	            iTabGroup->SetActiveTabByIndex( active );
	            ActivateLocalViewL( TUid::Uid(active) );
        	}
            break;

        case EKeyRightArrow:
            if( (active + 1) < count )
        	{
                active++;
                iTabGroup->SetActiveTabByIndex( active );
                ActivateLocalViewL( TUid::Uid(active) );
        	}
            break;
            
        default:
            break;
    }
    
    // braodcast the event
    InformSubscribers( (TKeyEvent&)aKeyEvent );

    return EKeyWasConsumed;
}

void UserInterface::HandleCommandL(TInt aCommand)
    {
    switch ( aCommand )
        {
        case EEikCmdExit:
            {
            Exit();
            break;
            }
        // You can add your all application applying commands here.
        // You would handle here menu commands that are valid for all views.
        }
    }

void UserInterface::HandleResourceChangeL( TInt aType )
    {
    CAknAppUi::HandleResourceChangeL( aType );

    // ADDED FOR SCALABLE UI SUPPORT
    // *****************************
    if ( aType==KEikDynamicLayoutVariantSwitch )
        {
		((SystemView*) View( iViewId1) )->HandleClientRectChange(  );
		((ImageView*) View( iViewId2) )->HandleClientRectChange(  );
		((VideoView*) View( iViewId3) )->HandleClientRectChange(  );
		}

    }


void UserInterface::HandleGainingForeground()
{
	CEikStatusPane* sp = StatusPane();
	if( !sp )
		return;
	
	CAknNavigationControlContainer* iNaviPane = (CAknNavigationControlContainer*)sp->ControlL( TUid::Uid(EEikStatusPaneUidNavi) );
	if( !iNaviPane )
		return;
	
	CAknNavigationDecorator* iDecoratedTabGroup = iNaviPane->ResourceDecorator();
	if( !iDecoratedTabGroup )
		return;
	
	CAknTabGroup* iTabGroup = (CAknTabGroup*) iDecoratedTabGroup->DecoratedControl();
	if( !iTabGroup )
		return;
	
	TInt active = iTabGroup->ActiveTabIndex();
    iTabGroup->SetActiveTabByIndex( active );
    ActivateLocalViewL( TUid::Uid(active) );
}

void UserInterface::HandleLosingForeground()
{
//	DoDeactivate();
}
