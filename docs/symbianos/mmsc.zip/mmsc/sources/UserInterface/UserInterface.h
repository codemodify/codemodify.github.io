#ifndef __UserInterface_H__
#define __UserInterface_H__

// system headers
#include <eikapp.h>
#include <eikdoc.h>
#include <e32std.h>
#include <coeccntx.h>
#include <aknviewappui.h>       // View AppUi adds View handling to AppUi
#include <akntabgrp.h>          // For handling tabs
#include <aknnavide.h>

// minis sdk headers
#include <sdk-mini/types.h>

// forwards
class SystemView;
class ImageView;
class VideoView;

class UserInterface :	public CAknViewAppUi,
						public MCoeForegroundObserver,
						public SubscribersInformer<TKeyEvent&>
{
    public:
        void ConstructL();
        ~UserInterface();
        
    // From CAknViewAppUi
    private:
    	void DynInitMenuPaneL(TInt aResourceId,CEikMenuPane* aMenuPane);
        void HandleCommandL(TInt aCommand);
        virtual TKeyResponse HandleKeyEventL( const TKeyEvent& aKeyEvent,TEventCode aType );
        void HandleForegroundEventL( TBool aForeground );
	    virtual void HandleResourceChangeL( TInt aType );
	    
	// from MCoeForegroundObserver
    private:
        void HandleGainingForeground();
        void HandleLosingForeground();

    private:
        CAknNavigationControlContainer* iNaviPane;
        CAknTabGroup*                   iTabGroup;
        CAknNavigationDecorator*        iDecoratedTabGroup;
		TUid 							iViewId1;
		TUid 							iViewId2;
		TUid 							iViewId3;
    };

#endif
