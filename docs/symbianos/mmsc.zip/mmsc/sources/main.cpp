
// system headers
#include <eikstart.h>

// local headers
#include "Application/Application.h"

// entry point for a symbian app
GLDEF_C TInt E32Main()
{
	return EikStart::RunApplication( Application::Run );
}
