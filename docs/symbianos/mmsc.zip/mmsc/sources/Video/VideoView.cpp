
// system headers
#include  <aknviewappui.h>
//#include  <avkon.hrh>
//#include  <aknquerydialog.h>
//#include  <mmsc.rsg>

// local headers
#include "resources/mmsc.hrh" // for command handling
#include "sources/sdk-mini/Widget/Widget.h" // to add arbitrary widgets
#include "VideoView.h" 


VideoView::VideoView( TInt resourceId ):
	View( resourceId, VideoViewID )
{}

VideoView::~VideoView()
{}

void VideoView::HandleCommandL(TInt aCommand)
{
    switch ( aCommand )
    {
        case EAknSoftkeyOk:
            break;

        case eVideoViewCommand1:
	        {
	        	int a = 0;
	        }
            break;

        default:
            AppUi()->HandleCommandL( aCommand );
            break;
    }
}

void VideoView::DoActivateL( const TVwsViewId& /*aPrevViewId*/,TUid aCustomMessageId, const TDesC8& aCustomMessage)
{
	// init the content of the image view and set it
	Widget* videoViewContent = new Widget();
	this->SetViewContent( videoViewContent );
}
