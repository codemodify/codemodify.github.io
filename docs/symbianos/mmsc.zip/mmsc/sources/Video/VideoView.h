#ifndef __VideoView_H__
#define __VideoView_H__

#include "sources/sdk-mini/View/View.h"

const TUid VideoViewID = {2};
const int VideoViewIDAsInt = 2;

class VideoView : public View
{
	public:
		VideoView(  TInt resourceId );
        ~VideoView();

    public:
        void HandleCommandL( TInt aCommand );
     
    private:
        void DoActivateL( const TVwsViewId& aPrevViewId,TUid aCustomMessageId, const TDesC8& aCustomMessage );

};

#endif

