﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace CustomApplicationPages
{
    class CustomApplicationPages : SPFeatureReceiver
    {
        public override void FeatureInstalled( SPFeatureReceiverProperties properties )
        {}

        public override void FeatureUninstalling( SPFeatureReceiverProperties properties )
        {}

        public override void FeatureActivated( SPFeatureReceiverProperties properties )
        {
            SPWeb  web = (SPWeb) properties.Feature.Parent;
                                        web.Properties[ "OriginalTitle" ] = web.Title;
                                        web.Properties.Update();

                                        web.Title = "CustomApplicationPages Activated";
                                        web.Update();
        }

        public override void FeatureDeactivating( SPFeatureReceiverProperties properties )
        {
            SPWeb  web = (Microsoft.SharePoint.SPWeb) properties.Feature.Parent;
                                        web.Title = web.Properties[ "OriginalTitle" ];
                                        web.Update();
        }
    }
}
