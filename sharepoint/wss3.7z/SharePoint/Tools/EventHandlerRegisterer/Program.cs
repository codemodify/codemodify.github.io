﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace EventHandlerRegisterer
{
    class EventHandlerRegisterer
    {
        static void Main( string[] args )
        {
            const string c_url               = args[ 0 ];
            const string c_assemblySignature = args[ 1 ];
            const string c_assemblyClassName = args[ 2 ];

            // get the site collection
            SPSite siteCollection = new SPSite( c_url );

            // get the site
            SPWeb site = siteCollection.OpenWeb();

            // add the list event handler
            web.Lists["LaListeCible"].EventReceivers.Add( SPEventReceiverType.<Type d'évènement>, Signature de l'assemblage, Nom de la classe );

            string AssemblySignature="DemoAssembly, Version=1.0.0.0, Culture=neutral, PublicKeyToken=74cdd0bb8f510c15";
            string ClassName="DemoClass";
            Web.Lists[ "Shared Documents" ].EventReceivers.Add( SPEventReceiverType.ItemAdding, AssemblySignature, ClassName );
            Web.Lists[ "Shared Documents" ].EventReceivers.Add( SPEventReceiverType.ItemAdded, AssemblySignature, ClassName );
        }
    }
}
