using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Workflow.Activities;
using System.Workflow.ComponentModel;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;

namespace LitwareWorkflows {
  public sealed partial class LitwareApproval : SharePointSequentialWorkflowActivity {

    #region "Workflow Designer Members (do not modify)"

    public LitwareApproval() {
      InitializeComponent();
    }

    #endregion"

    #region "Workflow Fields"

    // workflow fields 
    public Guid workflowId = default(Guid);
    public SPWorkflowActivationProperties workflowProperties;
    public string ItemName = default(string);
    public string WorkflowOutcome = default(string);
    public string WorkflowComments = default(string);

    // initiation form data
    public string Approver = default(string);
    public string ApprovalScope = default(string);
    public string ApproverInstructions = default(string);

    // history list fields
    public String HistoryDescription = default(System.String);
    public String HistoryOutcome = default(System.String);
    public int userID = -1;
    public string ExecutingUser = default(string);

    // task fields
    public Guid taskId = default(Guid);
    public SPWorkflowTaskProperties taskProperties = new SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties taskBeforeProperties = new SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties taskAfterProperties = new SPWorkflowTaskProperties();
    public Guid TaskStatusFieldId = new Guid("c15b34c3-ce7d-490a-b133-3f4de8801b76");
    public string TaskStatus = default(string);
    public bool TaskNotComplete = true;
    public String taskOutcome = default(System.String);

    // modifcation data
    public String modifcationContextData = default(System.String);
    public string ModificationData = default(string);
    
    #endregion

    #region "Workflow Event Handlers"

    private void onWorkflowActivated1_Invoked(object sender, ExternalDataEventArgs e) {
      // initialize general workflow properties
      workflowId = workflowProperties.WorkflowId;
      userID = workflowProperties.OriginatorUser.ID;
      // initialize name of item or document
      if (workflowProperties.Item.File != null) {
        ItemName = workflowProperties.Item.File.Name;
      }
      else {
        ItemName = workflowProperties.Item.Title;
      }
      // deserialize initiation data;
      string InitiationData = workflowProperties.InitiationData;
      XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
      XmlTextReader reader = new XmlTextReader(new StringReader(InitiationData));
      LitwareApprovalWorkflowData FormData = (LitwareApprovalWorkflowData)serializer.Deserialize(reader);
      // assign form data values to workflow fields
      Approver = FormData.Approver;
      ApprovalScope = FormData.ApprovalScope;
      ApproverInstructions = FormData.Instructions;
    }

    private void logActivated_MethodInvoking(object sender, EventArgs e) {
      HistoryDescription = "Workflow created on " + ItemName;
      HistoryOutcome = "Workflow activated";
      userID = workflowProperties.OriginatorUser.ID;
    }

    private void createTask1_MethodInvoking(object sender, EventArgs e) {
      // generate ID for task
      taskId = Guid.NewGuid();
      // assign initial values for task creation
      taskProperties.Title = "Approval required for " + ItemName;
      taskProperties.Description = ApproverInstructions;
      taskProperties.AssignedTo = Approver;
      taskProperties.PercentComplete = 0;
      taskProperties.StartDate = DateTime.Today;
      taskProperties.DueDate = DateTime.Today.AddDays(2);
      taskProperties.ExtendedProperties["WorkflowOutcome"] = "";
      // make sure user is recognized within SiteUsers
      EnsureUserIsRecognized(Approver);
    }

    private void onTaskCreated1_Invoked(object sender, ExternalDataEventArgs e) {
      // nothing needed here
    }

    private void logTaskCreated_MethodInvoking(object sender, EventArgs e) {
      HistoryDescription = "Approval task assinged to " + Approver;
      TaskStatus = taskAfterProperties.ExtendedProperties[TaskStatusFieldId].ToString();
      HistoryOutcome = "Task status: " + TaskStatus;
    }

    private void onTaskChanged1_Invoked(object sender, ExternalDataEventArgs e) {
      // chek task status and fall through loop is marked complete
      if(taskAfterProperties.ExtendedProperties["TaskStatus"]!=null) {
        TaskStatus = taskAfterProperties.ExtendedProperties["TaskStatus"].ToString();
        if (TaskStatus.Equals("Completed")) {
          // update variable to break out of while loop
          TaskNotComplete = false;
          // update WorkflowOutcome feild
          if (taskAfterProperties.ExtendedProperties["LitwareWorkflowOutcome"] != null) {
            WorkflowOutcome = taskAfterProperties.ExtendedProperties["LitwareWorkflowOutcome"].ToString();
          }
          if (taskAfterProperties.ExtendedProperties["LitwareComments"] != null) {
            this.WorkflowComments = taskAfterProperties.ExtendedProperties["LitwareComments"].ToString();
          }          
        }
        // debug message
        HistoryOutcome = this.DumpHashtable(taskAfterProperties.ExtendedProperties);
      }      
      // update userID field to reflect user who updated task
      userID = GetUserIdFromName(workflowProperties.Web, ExecutingUser);
    }

    private void logTaskChanged_MethodInvoking(object sender, EventArgs e) {
      HistoryDescription = "Approval task updated";
      TaskStatus = taskAfterProperties.ExtendedProperties["TaskStatus"].ToString();
      HistoryOutcome = "Task status: " + TaskStatus;
    }

    private void completeTask1_MethodInvoking(object sender, EventArgs e) {
      taskOutcome = WorkflowOutcome;
    }

    private void logCompleted_MethodInvoking(object sender, EventArgs e) {
      HistoryDescription = "Comments: " + WorkflowComments;
      HistoryOutcome = ItemName + " was " + WorkflowOutcome;
    }

    #endregion

    #region "Workflow Modification Handlers"

    private void enableWorkflowModification1_MethodInvoking(object sender, EventArgs e) {
      LitwareApprovalWorkflowData FormData = new LitwareApprovalWorkflowData();
      FormData.Approver = this.Approver;
      FormData.ApprovalScope = this.ApprovalScope;
      FormData.Instructions = this.ApproverInstructions;
      FormData.Comments = "";

      using (MemoryStream stream = new MemoryStream()) {
        XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
        serializer.Serialize(stream, FormData);
        stream.Position = 0;
        byte[] bytes = new byte[stream.Length];
        stream.Read(bytes, 0, bytes.Length);
        modifcationContextData = Encoding.UTF8.GetString(bytes);
      }
    }

    private void onWorkflowModified1_Invoked(object sender, ExternalDataEventArgs e) {
      string ContextData = this.modifcationContextData;
      XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
      XmlTextReader reader = new XmlTextReader(new StringReader(ContextData));
      LitwareApprovalWorkflowData FormData = (LitwareApprovalWorkflowData)serializer.Deserialize(reader);
      // assign form data values to workflow fields
      Approver = FormData.Approver;
      ApprovalScope = FormData.ApprovalScope;
      ApproverInstructions = FormData.Instructions;
    }

    private void logModified_MethodInvoking(object sender, EventArgs e) {

    }

    #endregion

    #region "Workflow Cancel Handler"

    private void logCancellation_MethodInvoking(object sender, EventArgs e) {
       HistoryDescription = "Workflow cancelled";
      HistoryOutcome = "This is all";
    }

    #endregion

    #region "Workflow Error Handlers"

    private void logError_MethodInvoking(object sender, EventArgs e) {
      HistoryDescription = faultHandlerActivity1.Fault.Message;
      HistoryOutcome = faultHandlerActivity1.Fault.StackTrace;
    }

    private void errorLogger_ExecuteCode(object sender, EventArgs e) {
      // TO DO - add code to log to Windows event log
    }

    #endregion

    #region "Helper Methods"

    private void EnsureUserIsRecognized(string user) {
      if (GetUserIdFromName(workflowProperties.Web, user) == -1) {
        workflowProperties.Web.SiteUsers.Add(user, "", "", "");
      }
    }

    private int GetUserIdFromName(SPWeb site, string UserName) {
      SPPrincipalInfo PrincipalInfo;
      PrincipalInfo = SPUtility.ResolvePrincipal(site,
                                                 UserName,
                                                 SPPrincipalType.All,
                                                 SPPrincipalSource.All,
                                                 null,
                                                 false);
      if (PrincipalInfo == null) {
        return -1;
      }
      else {
        return PrincipalInfo.PrincipalId;
      }
    }

    private string DumpHashtable(Hashtable table) {
      string temp = string.Empty;
      foreach (DictionaryEntry entry in table) {
        if(!entry.Key.ToString().Contains("-")) {
          temp += entry.Key.ToString() + "=" + entry.Value + " | ";
        }
      }
      return temp;
    }

    #endregion    

  }

}
