using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;

namespace LitwareWorkflows {
  public class LitwareApprovalTaskEditForm : LayoutsPageBase {

    protected string ListId;
    protected SPList TaskList;
    protected SPListItem TaskItem;
    protected Guid WorkflowInstanceId;
    protected SPWorkflow WorkflowInstance;
    protected SPList ItemList;
    protected SPListItem Item;
    protected SPWorkflowTask Task;

    protected string TaskData;
    protected string TaskName;
    protected SPWorkflowAssociation WorkflowAssociation;

    protected HyperLink lnkItem;
    protected Label lblListName;
    protected Label lblSiteUrl;
    protected InputFormTextBox txtInstructions;
    protected InputFormTextBox txtComments;
    protected Button btnApprove;
    protected Button btnReject;
    protected Button btnCancel;

    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected override void OnLoad(EventArgs ea) {

      ListId = Request.QueryString["List"];
      TaskList = Web.Lists[new Guid(ListId)];
      TaskItem = TaskList.GetItemById(Convert.ToInt32(Request.Params["ID"]));
      WorkflowInstanceId = new Guid((string)TaskItem["WorkflowInstanceID"]);
      WorkflowInstance = new SPWorkflow(Web, WorkflowInstanceId);
      Task = WorkflowInstance.Tasks[0];
      ItemList = WorkflowInstance.ParentList;
      Item = ItemList.GetItemById(WorkflowInstance.ItemId);

      WorkflowAssociation = ItemList.WorkflowAssociations[WorkflowInstance.AssociationId];

      TaskName = TaskItem["Title"].ToString();

      string UrlToItem = Web.Site.MakeFullUrl(ItemList.RootFolder.Url +
                                              @"\DispForm.aspx?ID=" +
                                              Item.ID.ToString());
      string ItemName;
      if (Item.File != null) {
        ItemName = Item.File.Name;
      }
      else {
        ItemName = Item.Title;
      }

      lnkItem.Text = ItemName;
      lnkItem.NavigateUrl = UrlToItem;
      lblListName.Text = ItemList.Title;
      lblSiteUrl.Text = Web.Url;

      PageTitle = "Approve or Reject Item";
      PageTitleInArea = "Approve or Reject " + ItemName;
      PageDescription = "Please respond by either approving or rejecting " + ItemName;

    }

    private void FetchTaskInfo() {
      if (TaskItem["Description"] != null && TaskItem["Description"].ToString() != string.Empty) {
        txtInstructions.Text = TaskItem["Description"].ToString();
      }
      else {
        txtInstructions.Text = "No instructions were provided for this task.";
      }
    }

    public void cmdApprove_OnClick(object sender, EventArgs e) {
      Hashtable taskHash = new Hashtable();
      taskHash["TaskStatus"] = "Completed";
      taskHash["LitwareWorkflowOutcome"] = "Approved";
      taskHash["LitwareComments"] = txtComments.Text;
      SPWorkflowTask.AlterTask(TaskItem, taskHash, true);
      SPUtility.Redirect(ItemList.DefaultViewUrl, SPRedirectFlags.UseSource, HttpContext.Current);
    }

    public void cmdReject_OnClick(object sender, EventArgs e) {
      Hashtable taskHash = new Hashtable();     
      taskHash["TaskStatus"] = "Completed";
      taskHash["LitwareWorkflowOutcome"] = "Rejected";
      taskHash["LitwareComments"] = txtComments.Text;
      SPWorkflowTask.AlterTask(TaskItem, taskHash, true);
      SPUtility.Redirect(ItemList.DefaultViewUrl, SPRedirectFlags.UseSource, HttpContext.Current);
    }

    public void cmdCancel_OnClick(object sender, EventArgs e) {
      SPUtility.Redirect(ItemList.DefaultViewUrl, SPRedirectFlags.UseSource, HttpContext.Current);
    }

    protected override void OnPreRender(EventArgs e) {
      FetchTaskInfo();
    }

  }
}
