using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace LitwareWorkflows {
  partial class LitwareApproval {
    #region Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    [System.Diagnostics.DebuggerNonUserCode]
    private void InitializeComponent() {
      this.CanModifyActivities = true;
      System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind12 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind11 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind13 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind14 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind15 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind16 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind17 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind18 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind19 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind20 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
      System.Workflow.ComponentModel.ActivityBind activitybind21 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken3 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind22 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind23 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind24 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind25 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind26 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind27 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind28 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind29 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind30 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind31 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind32 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind33 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken4 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind34 = new System.Workflow.ComponentModel.ActivityBind();
      this.logTaskChanged = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onTaskChanged1 = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
      this.logModified = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onWorkflowModified1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowModified();
      this.sequenceActivity2 = new System.Workflow.Activities.SequenceActivity();
      this.terminateActivity1 = new System.Workflow.ComponentModel.TerminateActivity();
      this.logError = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.errorLogger = new System.Workflow.Activities.CodeActivity();
      this.eventDrivenActivity1 = new System.Workflow.Activities.EventDrivenActivity();
      this.logCompleted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.completeTask1 = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
      this.whileActivity1 = new System.Workflow.Activities.WhileActivity();
      this.enableWorkflowModification1 = new Microsoft.SharePoint.WorkflowActions.EnableWorkflowModification();
      this.logCancellation = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.faultHandlerActivity1 = new System.Workflow.ComponentModel.FaultHandlerActivity();
      this.eventHandlersActivity1 = new System.Workflow.Activities.EventHandlersActivity();
      this.sequenceActivity1 = new System.Workflow.Activities.SequenceActivity();
      this.cancellationHandlerActivity1 = new System.Workflow.ComponentModel.CancellationHandlerActivity();
      this.faultHandlersActivity1 = new System.Workflow.ComponentModel.FaultHandlersActivity();
      this.eventHandlingScopeActivity1 = new System.Workflow.Activities.EventHandlingScopeActivity();
      this.logTaskCreated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onTaskCreated1 = new Microsoft.SharePoint.WorkflowActions.OnTaskCreated();
      this.createTask1 = new Microsoft.SharePoint.WorkflowActions.CreateTask();
      this.logActivated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onWorkflowActivated1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
      // 
      // logTaskChanged
      // 
      this.logTaskChanged.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logTaskChanged.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind1.Name = "LitwareApproval";
      activitybind1.Path = "HistoryDescription";
      activitybind2.Name = "LitwareApproval";
      activitybind2.Path = "HistoryOutcome";
      this.logTaskChanged.Name = "logTaskChanged";
      this.logTaskChanged.OtherData = "";
      activitybind3.Name = "LitwareApproval";
      activitybind3.Path = "userID";
      this.logTaskChanged.MethodInvoking += new System.EventHandler(this.logTaskChanged_MethodInvoking);
      this.logTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
      this.logTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
      this.logTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
      // 
      // onTaskChanged1
      // 
      activitybind4.Name = "LitwareApproval";
      activitybind4.Path = "taskAfterProperties";
      activitybind5.Name = "LitwareApproval";
      activitybind5.Path = "taskBeforeProperties";
      correlationtoken1.Name = "taskToken";
      correlationtoken1.OwnerActivityName = "LitwareApproval";
      this.onTaskChanged1.CorrelationToken = correlationtoken1;
      activitybind6.Name = "LitwareApproval";
      activitybind6.Path = "ExecutingUser";
      this.onTaskChanged1.Name = "onTaskChanged1";
      activitybind7.Name = "LitwareApproval";
      activitybind7.Path = "taskId";
      this.onTaskChanged1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onTaskChanged1_Invoked);
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.BeforePropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.ExecutorProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
      // 
      // logModified
      // 
      this.logModified.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logModified.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind8.Name = "LitwareApproval";
      activitybind8.Path = "HistoryDescription";
      activitybind9.Name = "LitwareApproval";
      activitybind9.Path = "HistoryOutcome";
      this.logModified.Name = "logModified";
      this.logModified.OtherData = "";
      activitybind10.Name = "LitwareApproval";
      activitybind10.Path = "userID";
      this.logModified.MethodInvoking += new System.EventHandler(this.logModified_MethodInvoking);
      this.logModified.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
      this.logModified.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
      this.logModified.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
      activitybind12.Name = "LitwareApproval";
      activitybind12.Path = "ExecutingUser";
      // 
      // onWorkflowModified1
      // 
      activitybind11.Name = "LitwareApproval";
      activitybind11.Path = "modifcationContextData";
      correlationtoken2.Name = "modificationToken";
      correlationtoken2.OwnerActivityName = "eventHandlingScopeActivity1";
      this.onWorkflowModified1.CorrelationToken = correlationtoken2;
      this.onWorkflowModified1.ModificationId = new System.Guid("c7a53c4e-ab25-450f-a595-ae2b380d7c3e");
      this.onWorkflowModified1.Name = "onWorkflowModified1";
      this.onWorkflowModified1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onWorkflowModified1_Invoked);
      this.onWorkflowModified1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowModified.UserProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind12)));
      this.onWorkflowModified1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowModified.ContextDataProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind11)));
      // 
      // sequenceActivity2
      // 
      this.sequenceActivity2.Activities.Add(this.onTaskChanged1);
      this.sequenceActivity2.Activities.Add(this.logTaskChanged);
      this.sequenceActivity2.Name = "sequenceActivity2";
      // 
      // terminateActivity1
      // 
      this.terminateActivity1.Error = "This worklfow instance has experienced an untimiely death!";
      this.terminateActivity1.Name = "terminateActivity1";
      // 
      // logError
      // 
      this.logError.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logError.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowError;
      activitybind13.Name = "LitwareApproval";
      activitybind13.Path = "HistoryDescription";
      activitybind14.Name = "LitwareApproval";
      activitybind14.Path = "HistoryOutcome";
      this.logError.Name = "logError";
      this.logError.OtherData = "";
      activitybind15.Name = "LitwareApproval";
      activitybind15.Path = "userID";
      this.logError.MethodInvoking += new System.EventHandler(this.logError_MethodInvoking);
      this.logError.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind13)));
      this.logError.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind14)));
      this.logError.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind15)));
      // 
      // errorLogger
      // 
      this.errorLogger.Name = "errorLogger";
      this.errorLogger.ExecuteCode += new System.EventHandler(this.errorLogger_ExecuteCode);
      // 
      // eventDrivenActivity1
      // 
      this.eventDrivenActivity1.Activities.Add(this.onWorkflowModified1);
      this.eventDrivenActivity1.Activities.Add(this.logModified);
      this.eventDrivenActivity1.Name = "eventDrivenActivity1";
      // 
      // logCompleted
      // 
      this.logCompleted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logCompleted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind16.Name = "LitwareApproval";
      activitybind16.Path = "HistoryDescription";
      activitybind17.Name = "LitwareApproval";
      activitybind17.Path = "HistoryOutcome";
      this.logCompleted.Name = "logCompleted";
      this.logCompleted.OtherData = "";
      activitybind18.Name = "LitwareApproval";
      activitybind18.Path = "userID";
      this.logCompleted.MethodInvoking += new System.EventHandler(this.logCompleted_MethodInvoking);
      this.logCompleted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind18)));
      this.logCompleted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind16)));
      this.logCompleted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind17)));
      // 
      // completeTask1
      // 
      this.completeTask1.CorrelationToken = correlationtoken1;
      this.completeTask1.Name = "completeTask1";
      activitybind19.Name = "LitwareApproval";
      activitybind19.Path = "taskId";
      activitybind20.Name = "LitwareApproval";
      activitybind20.Path = "taskOutcome";
      this.completeTask1.MethodInvoking += new System.EventHandler(this.completeTask1_MethodInvoking);
      this.completeTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind19)));
      this.completeTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind20)));
      // 
      // whileActivity1
      // 
      this.whileActivity1.Activities.Add(this.sequenceActivity2);
      ruleconditionreference1.ConditionName = "Task Not Complete";
      this.whileActivity1.Condition = ruleconditionreference1;
      this.whileActivity1.Name = "whileActivity1";
      // 
      // enableWorkflowModification1
      // 
      activitybind21.Name = "LitwareApproval";
      activitybind21.Path = "modifcationContextData";
      correlationtoken3.Name = "modificationToken";
      correlationtoken3.OwnerActivityName = "eventHandlingScopeActivity1";
      this.enableWorkflowModification1.CorrelationToken = correlationtoken3;
      this.enableWorkflowModification1.ModificationId = new System.Guid("c7a53c4e-ab25-450f-a595-ae2b380d7c3e");
      this.enableWorkflowModification1.Name = "enableWorkflowModification1";
      this.enableWorkflowModification1.MethodInvoking += new System.EventHandler(this.enableWorkflowModification1_MethodInvoking);
      this.enableWorkflowModification1.SetBinding(Microsoft.SharePoint.WorkflowActions.EnableWorkflowModification.ContextDataProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind21)));
      // 
      // logCancellation
      // 
      this.logCancellation.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logCancellation.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind22.Name = "LitwareApproval";
      activitybind22.Path = "HistoryDescription";
      activitybind23.Name = "LitwareApproval";
      activitybind23.Path = "HistoryOutcome";
      this.logCancellation.Name = "logCancellation";
      this.logCancellation.OtherData = "";
      this.logCancellation.UserId = -1;
      this.logCancellation.MethodInvoking += new System.EventHandler(this.logCancellation_MethodInvoking);
      this.logCancellation.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind22)));
      this.logCancellation.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind23)));
      // 
      // faultHandlerActivity1
      // 
      this.faultHandlerActivity1.Activities.Add(this.errorLogger);
      this.faultHandlerActivity1.Activities.Add(this.logError);
      this.faultHandlerActivity1.Activities.Add(this.terminateActivity1);
      this.faultHandlerActivity1.FaultType = typeof(System.Exception);
      this.faultHandlerActivity1.Name = "faultHandlerActivity1";
      // 
      // eventHandlersActivity1
      // 
      this.eventHandlersActivity1.Activities.Add(this.eventDrivenActivity1);
      this.eventHandlersActivity1.Name = "eventHandlersActivity1";
      // 
      // sequenceActivity1
      // 
      this.sequenceActivity1.Activities.Add(this.enableWorkflowModification1);
      this.sequenceActivity1.Activities.Add(this.whileActivity1);
      this.sequenceActivity1.Activities.Add(this.completeTask1);
      this.sequenceActivity1.Activities.Add(this.logCompleted);
      this.sequenceActivity1.Name = "sequenceActivity1";
      // 
      // cancellationHandlerActivity1
      // 
      this.cancellationHandlerActivity1.Activities.Add(this.logCancellation);
      this.cancellationHandlerActivity1.Name = "cancellationHandlerActivity1";
      // 
      // faultHandlersActivity1
      // 
      this.faultHandlersActivity1.Activities.Add(this.faultHandlerActivity1);
      this.faultHandlersActivity1.Name = "faultHandlersActivity1";
      // 
      // eventHandlingScopeActivity1
      // 
      this.eventHandlingScopeActivity1.Activities.Add(this.sequenceActivity1);
      this.eventHandlingScopeActivity1.Activities.Add(this.eventHandlersActivity1);
      this.eventHandlingScopeActivity1.Name = "eventHandlingScopeActivity1";
      // 
      // logTaskCreated
      // 
      this.logTaskCreated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logTaskCreated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.TaskCreated;
      activitybind24.Name = "LitwareApproval";
      activitybind24.Path = "HistoryDescription";
      activitybind25.Name = "LitwareApproval";
      activitybind25.Path = "HistoryOutcome";
      this.logTaskCreated.Name = "logTaskCreated";
      this.logTaskCreated.OtherData = "";
      activitybind26.Name = "LitwareApproval";
      activitybind26.Path = "userID";
      this.logTaskCreated.MethodInvoking += new System.EventHandler(this.logTaskCreated_MethodInvoking);
      this.logTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind26)));
      this.logTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind24)));
      this.logTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind25)));
      // 
      // onTaskCreated1
      // 
      activitybind27.Name = "LitwareApproval";
      activitybind27.Path = "taskAfterProperties";
      this.onTaskCreated1.CorrelationToken = correlationtoken1;
      this.onTaskCreated1.Executor = null;
      this.onTaskCreated1.Name = "onTaskCreated1";
      activitybind28.Name = "LitwareApproval";
      activitybind28.Path = "taskId";
      this.onTaskCreated1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onTaskCreated1_Invoked);
      this.onTaskCreated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskCreated.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind28)));
      this.onTaskCreated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskCreated.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind27)));
      // 
      // createTask1
      // 
      this.createTask1.CorrelationToken = correlationtoken1;
      this.createTask1.ListItemId = -1;
      this.createTask1.Name = "createTask1";
      this.createTask1.SpecialPermissions = null;
      activitybind29.Name = "LitwareApproval";
      activitybind29.Path = "taskId";
      activitybind30.Name = "LitwareApproval";
      activitybind30.Path = "taskProperties";
      this.createTask1.MethodInvoking += new System.EventHandler(this.createTask1_MethodInvoking);
      this.createTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind29)));
      this.createTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind30)));
      // 
      // logActivated
      // 
      this.logActivated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logActivated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowStarted;
      activitybind31.Name = "LitwareApproval";
      activitybind31.Path = "HistoryDescription";
      activitybind32.Name = "LitwareApproval";
      activitybind32.Path = "HistoryOutcome";
      this.logActivated.Name = "logActivated";
      this.logActivated.OtherData = "";
      activitybind33.Name = "LitwareApproval";
      activitybind33.Path = "userID";
      this.logActivated.MethodInvoking += new System.EventHandler(this.logActivated_MethodInvoking);
      this.logActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind31)));
      this.logActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind32)));
      this.logActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind33)));
      // 
      // onWorkflowActivated1
      // 
      correlationtoken4.Name = "workflowToken";
      correlationtoken4.OwnerActivityName = "LitwareApproval";
      this.onWorkflowActivated1.CorrelationToken = correlationtoken4;
      this.onWorkflowActivated1.EventName = "OnWorkflowActivated";
      this.onWorkflowActivated1.Name = "onWorkflowActivated1";
      activitybind34.Name = "LitwareApproval";
      activitybind34.Path = "workflowProperties";
      this.onWorkflowActivated1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onWorkflowActivated1_Invoked);
      this.onWorkflowActivated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind34)));
      // 
      // LitwareApproval
      // 
      this.Activities.Add(this.onWorkflowActivated1);
      this.Activities.Add(this.logActivated);
      this.Activities.Add(this.createTask1);
      this.Activities.Add(this.onTaskCreated1);
      this.Activities.Add(this.logTaskCreated);
      this.Activities.Add(this.eventHandlingScopeActivity1);
      this.Activities.Add(this.faultHandlersActivity1);
      this.Activities.Add(this.cancellationHandlerActivity1);
      this.Name = "LitwareApproval";
      this.CanModifyActivities = false;

    }

    #endregion

    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logCancellation;
    private Microsoft.SharePoint.WorkflowActions.EnableWorkflowModification enableWorkflowModification1;
    private Microsoft.SharePoint.WorkflowActions.CompleteTask completeTask1;
    private TerminateActivity terminateActivity1;
    private CancellationHandlerActivity cancellationHandlerActivity1;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logModified;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logError;
    private FaultHandlerActivity faultHandlerActivity1;
    private FaultHandlersActivity faultHandlersActivity1;
    private CodeActivity errorLogger;
    private SequenceActivity sequenceActivity1;
    private EventHandlingScopeActivity eventHandlingScopeActivity1;
    private Microsoft.SharePoint.WorkflowActions.OnWorkflowModified onWorkflowModified1;
    private EventDrivenActivity eventDrivenActivity1;
    private EventHandlersActivity eventHandlersActivity1;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logTaskChanged;
    private Microsoft.SharePoint.WorkflowActions.OnTaskChanged onTaskChanged1;
    private SequenceActivity sequenceActivity2;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logCompleted;
    private WhileActivity whileActivity1;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logTaskCreated;
    private Microsoft.SharePoint.WorkflowActions.OnTaskCreated onTaskCreated1;
    private Microsoft.SharePoint.WorkflowActions.CreateTask createTask1;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logActivated;
    private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated1;








































































  }
}
