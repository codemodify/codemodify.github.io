using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;

namespace LitwareWorkflows {

  internal enum AssociationTypeEnum {
    List,
    ContentType,
    ContentTypeOnList
  }

  public class LitwareApprovalAssociationForm : LayoutsPageBase {


    // controls
    protected PeopleEditor pickerApprover;
    protected RadioButton radInternalApproval;
    protected RadioButton radExternalApproval;
    protected InputFormTextBox txtInstructions;


    // form-level variables
    protected string WorkflowAssociationName;
    protected Guid WorkflowTemplateId;
    protected SPWorkflowTemplate WorkflowTemplate;
    bool WorkflowAssociationExists;
    bool UpdateContentTypesOnLists;

    AssociationTypeEnum AssociationType;
    protected Guid ListId;
    protected SPList List;
    protected SPContentTypeId CTypeId;
    protected SPContentType CType;


    protected SPWorkflowAssociation WorkflowAssociation;
    protected Guid WorkflowAssociationId;

    
    
    bool NewTaskListRequired = false;
    string NewTaskListName;
    bool NewHistoryListRequired = false;
    string NewHistoryListName;
    SPList TaskList;
    SPList HistoryList;
    protected string QueryString;
    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected override void OnLoad(EventArgs e) {

      // retrieve form-level parameters      
      string paramWorkflowName = Request.Params["WorkflowName"];
      string paramWorkflowDefinition = Request.Params["WorkflowDefinition"];
      string paramList = Request.Params["List"];
      string paramCType = Request.Params["ctype"];
      string paramUpdateLists = Request.Params["UpdateLists"];
      string paramTaskList = Request.Params["TaskList"];
      string paramHistoryList = Request.Params["HistoryList"];
      string paramAllowManual = Request.Params["AllowManual"];
      string paramAutoStartCreate = Request.Params["AutoStartCreate"];
      string paramAutoStartChange = Request.Params["AutoStartChange"];
      string paramManualPermManageListRequired = Request.Params["ManualPermManageListRequired"];
      string paramGuidAssoc = Request.Params["GuidAssoc"];

      // set page-level variables
      WorkflowAssociationName = paramWorkflowName;
      WorkflowTemplateId = new Guid(paramWorkflowDefinition);
      WorkflowTemplate = Web.WorkflowTemplates[WorkflowTemplateId];
      if(!string.IsNullOrEmpty(paramGuidAssoc))  {
        WorkflowAssociationExists = true;
        WorkflowAssociationId = new Guid(paramGuidAssoc);
      }
      
      UpdateContentTypesOnLists = (paramUpdateLists == "TRUE");

      if (!string.IsNullOrEmpty(paramList)) {
        ListId = new Guid(paramList);
        List = Web.Lists[ListId];
      }

      if (string.IsNullOrEmpty(paramCType)) {
        AssociationType = AssociationTypeEnum.List;
        if (WorkflowAssociationExists) {
          WorkflowAssociation = List.WorkflowAssociations[WorkflowAssociationId];          
        }
      }
      else {
        // there is content type
        if (List == null) {
          AssociationType = AssociationTypeEnum.ContentType;
          CTypeId = new SPContentTypeId(paramCType);
          CType = Web.AvailableContentTypes[CTypeId];
          if (WorkflowAssociationExists) {
            WorkflowAssociation = CType.WorkflowAssociations[WorkflowAssociationId];
          }
        }
        else {
          AssociationType = AssociationTypeEnum.ContentTypeOnList;
          CType = List.ContentTypes[new SPContentTypeId(paramCType)];
          if (WorkflowAssociationExists) {
            WorkflowAssociation = CType.WorkflowAssociations[WorkflowAssociationId];
          }

        }
      }

      if (paramTaskList[0] == 'z') {
        NewTaskListRequired = true;
        NewTaskListName = paramTaskList.Substring(1);
      }
      else {
        if (AssociationType == AssociationTypeEnum.ContentType) {
          TaskList = Web.Lists[paramTaskList];
        }
        else {
          TaskList = Web.Lists[new Guid(paramTaskList)];
        }
      }

      if (paramHistoryList[0] == 'z') {
        NewHistoryListRequired = true;
        NewHistoryListName = paramHistoryList.Substring(1);
      }
      else {
        if (AssociationType == AssociationTypeEnum.ContentType) {
          HistoryList = Web.Lists[paramHistoryList];
        }
        else {
          HistoryList = Web.Lists[new Guid(paramHistoryList)];
        }
      }

      // update variables with page title/description
      if (WorkflowAssociationExists) {
        PageTitle = "Update Workflow Association";
        PageTitleInArea = "Update Workflow Association '" + WorkflowAssociationName + "'";
        PageDescription = "Click OK to update the workflow associated named " + WorkflowAssociationName;
      }
      else {
        PageTitle = "Create Workflow Association";
        PageTitleInArea = "Create Litware Workflow Association '" + WorkflowAssociationName + "'";
        PageDescription = "Click OK to create a new Litware workflow association named " + WorkflowAssociationName;
      }


    }

    protected void PopulateFormDataFromString(string AssociationData) {
      XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
      XmlTextReader reader = new XmlTextReader(new StringReader(AssociationData));
      LitwareApprovalWorkflowData FormData = (LitwareApprovalWorkflowData)serializer.Deserialize(reader);

      pickerApprover.CommaSeparatedAccounts = FormData.Approver;

      if (FormData.ApprovalScope.Equals("Internal")) {
        radInternalApproval.Checked = true;
      }
      else {
        radExternalApproval.Checked = true;
      }
      txtInstructions.Text = FormData.Instructions;
    }

    protected string SerializeFormDataToString() {

      LitwareApprovalWorkflowData FormData = new LitwareApprovalWorkflowData();

      PickerEntity ApproverEntity = (PickerEntity)pickerApprover.Entities[0];
      FormData.Approver = ApproverEntity.Key;

      if (radInternalApproval.Checked) {
        FormData.ApprovalScope = "Internal";
      }
      else {
        FormData.ApprovalScope = "External";
      }
      FormData.Instructions = txtInstructions.Text;
      FormData.Comments = "";

      using (MemoryStream stream = new MemoryStream()) {
        XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
        serializer.Serialize(stream, FormData);
        stream.Position = 0;
        byte[] bytes = new byte[stream.Length];
        stream.Read(bytes, 0, bytes.Length);
        return Encoding.UTF8.GetString(bytes);
      }
    }
   
    protected void UpdateAssociation(SPWorkflowAssociation wfa, SPList TaskList, SPList HistoryList) {
      wfa.Name = WorkflowAssociationName;
      wfa.AutoStartCreate = (Request.Params["AutoStartCreate"] == "ON");
      wfa.AutoStartChange = (Request.Params["AutoStartChange"] == "ON");
      wfa.AllowManual = (Request.Params["AllowManual"] == "ON");
      wfa.AssociationData = SerializeFormDataToString();
      if (wfa.TaskListTitle != TaskList.Title) {
        wfa.SetTaskList(TaskList);
      }
      if (wfa.HistoryListTitle != HistoryList.Title) {
        wfa.SetHistoryList(HistoryList);
      }
    }

    public void cmdCancel_OnClick(object sender, EventArgs e) {
      string RedirectUrl = "";
      switch (AssociationType) {
        case AssociationTypeEnum.List:
          RedirectUrl = "WrkSetng.aspx?List=" + Request.Params["List"];
          break;
        case AssociationTypeEnum.ContentType:
          RedirectUrl = "WrkSetng.aspx?ctype=" + Request.Params["ctype"]; ;
          break;
        case AssociationTypeEnum.ContentTypeOnList:
          RedirectUrl = "WrkSetng.aspx?List=" + Request.Params["List"] + "&ctype=" + Request.Params["ctype"];
          break;
      }
      SPUtility.Redirect(RedirectUrl, SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);
    }

    public void cmdSubmit_OnClick(object sender, EventArgs e) {

      string RedirectUrl = "";

      if (NewTaskListRequired) {
        Guid TaskListId = Web.Lists.Add(NewTaskListName, "Workflow Tasks", SPListTemplateType.Tasks);
        TaskList = Web.Lists[TaskListId];
      }

      if (NewHistoryListRequired) {
        Guid HistoryListId = Web.Lists.Add(NewHistoryListName, "Workflow History", SPListTemplateType.WorkflowHistory);
        HistoryList = Web.Lists[HistoryListId];
      }


      switch (AssociationType) {

        // deal with case where workflow association on list
        case AssociationTypeEnum.List:
          if (WorkflowAssociationExists) {
            //WorkflowAssociation = List.WorkflowAssociations[WorkflowAssociationId];
            UpdateAssociation(WorkflowAssociation, TaskList, HistoryList);
            List.UpdateWorkflowAssociation(WorkflowAssociation);
          }
          else {
            WorkflowAssociation =
              SPWorkflowAssociation.CreateListAssociation(WorkflowTemplate,
                                                          WorkflowAssociationName,
                                                          TaskList,
                                                          HistoryList);

            UpdateAssociation(WorkflowAssociation, TaskList, HistoryList);
            List.AddWorkflowAssociation(WorkflowAssociation);
          }
          RedirectUrl = "WrkSetng.aspx?List=" + ListId.ToString();
          break;

        // deal with case where workflow association is on content type
        case AssociationTypeEnum.ContentType:
          if (WorkflowAssociationExists) {
            WorkflowAssociation = CType.WorkflowAssociations[WorkflowAssociationId];
            UpdateAssociation(WorkflowAssociation, TaskList, HistoryList);
            CType.UpdateWorkflowAssociation(WorkflowAssociation);
            if (UpdateContentTypesOnLists) {
              CType.UpdateWorkflowAssociationsOnChildren(true, true, true);
            }
          }
          else {
            WorkflowAssociation =
              SPWorkflowAssociation.CreateSiteContentTypeAssociation(WorkflowTemplate,
                                                                     WorkflowAssociationName,
                                                                     TaskList.Title,
                                                                     HistoryList.Title);

            UpdateAssociation(WorkflowAssociation, TaskList, HistoryList);
            CType.AddWorkflowAssociation(WorkflowAssociation);
            if (UpdateContentTypesOnLists) {
              CType.UpdateWorkflowAssociationsOnChildren(true, true, true);
            }

          }

          RedirectUrl = "WrkSetng.aspx?ctype=" + CTypeId.ToString();


          break;

        // deal with case where workflow association is on content type on list
        case AssociationTypeEnum.ContentTypeOnList:

          if (WorkflowAssociationExists) {
            WorkflowAssociation = CType.WorkflowAssociations[WorkflowAssociationId];
            UpdateAssociation(WorkflowAssociation, TaskList, HistoryList);
            CType.UpdateWorkflowAssociation(WorkflowAssociation);
          }
          else {
            WorkflowAssociation =
              SPWorkflowAssociation.CreateListContentTypeAssociation(WorkflowTemplate,
                                                                     WorkflowAssociationName,
                                                                     TaskList,
                                                                     HistoryList);


            UpdateAssociation(WorkflowAssociation, TaskList, HistoryList);
            CType.AddWorkflowAssociation(WorkflowAssociation);

          }

          RedirectUrl = "WrkSetng.aspx?List=" + ListId.ToString() + "&ctype=" + CTypeId.ToString();
          break;
      }

      SPUtility.Redirect(RedirectUrl, SPRedirectFlags.RelativeToLayoutsPage, HttpContext.Current);

    }

    protected override void OnPreRender(EventArgs e) {
      if (WorkflowAssociationExists) {
        PopulateFormDataFromString(WorkflowAssociation.AssociationData);
      }
    }


  }
}
