using System;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;

namespace HelloWorkflow {
  public sealed partial class Workflow1 : SharePointSequentialWorkflowActivity {

    #region "Code for workflow designer"

    public Workflow1() {
      InitializeComponent();
    }

    #endregion

    #region "Workflow Fields"

    // workflow-level fields
    public Guid workflowId = default(System.Guid);
    public SPWorkflowActivationProperties workflowProperties = new SPWorkflowActivationProperties();
    
    // feilds used for logging to history list
    public String HistoryDescription = default(string);
    public String HistoryOutcome = default(string);
    public int userID = -1;
    public string ExecutingUser = default(string);

    // task-level fields
    public Guid taskId = default(System.Guid);
    public SPWorkflowTaskProperties taskProperties = new Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties taskAfterProperties = new SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties taskBeforeProperties = new SPWorkflowTaskProperties();
    public bool TaskNotCompleted = true;
    public string TaskStatus;
    public Guid TaskStatusFieldId = new Guid("c15b34c3-ce7d-490a-b133-3f4de8801b76");

    #endregion

    #region "Workflow Event Handlers"

    private void onWorkflowActivated1_Invoked(object sender, ExternalDataEventArgs e) {
      workflowId = this.workflowProperties.WorkflowId;
      userID = workflowProperties.OriginatorUser.ID;
    }

    private void logActivated_MethodInvoking(object sender, EventArgs e) {

      SPListItem item = workflowProperties.Item;
      // determine whether workflow is running on a standard item or a document
      if (item.File == null) {
        HistoryDescription = "Workflow started on item " + item.Title;
      }
      else {
        HistoryDescription = "Workflow started on document " + item.File.Name;
      }
      HistoryOutcome = "Workflow activation complete";
    }

    private void createTask1_MethodInvoking(object sender, EventArgs e) {

      taskId = Guid.NewGuid();

      string ItemName;
      if (workflowProperties.Item.File != null) {
        ItemName = workflowProperties.Item.File.Name;
      }
      else {
        ItemName = workflowProperties.Item.Title;
      }

      // hard-code user for Hello World demo
      string UserAccountName = @"LITWAREINC\BrianC";
      EnsureUserIsRecognized(UserAccountName);

      taskProperties.Title = "Task for " + ItemName;
      taskProperties.Description = "Please review and approve " + ItemName;
      taskProperties.AssignedTo = UserAccountName;
      taskProperties.PercentComplete = 0;
      taskProperties.StartDate = DateTime.Today;
      taskProperties.DueDate = DateTime.Today.AddDays(2);
    }

    private void onTaskCreated1_Invoked(object sender, ExternalDataEventArgs e) {
      HistoryDescription = "Task created and assigned to " + taskAfterProperties.AssignedTo;
      TaskStatus = taskAfterProperties.ExtendedProperties[TaskStatusFieldId].ToString();
      HistoryOutcome = "Task status: " + TaskStatus;
    }

private void onTaskChanged1_Invoked(object sender, ExternalDataEventArgs e) {

  TaskStatus = taskAfterProperties.ExtendedProperties[TaskStatusFieldId].ToString();
  if (TaskStatus.Equals("Completed")) {
    // update variable to break out of while loop
    TaskNotCompleted = false;
  }
  // generate info for history list entry
  HistoryDescription = "Task updated by " + ExecutingUser;
  HistoryOutcome = "Task status: " + TaskStatus;
  // determine which user updated the task
  userID = GetUserIdFromName(workflowProperties.Web, ExecutingUser);
}

    private void logCompleted_MethodInvoking(object sender, EventArgs e) {
      HistoryDescription = "Workflow lifecycle is over";
      HistoryOutcome = "Eveything is done";
    }


    #endregion

    #region "Helper Methods"

    private void EnsureUserIsRecognized(string user) {
      if (GetUserIdFromName(workflowProperties.Web, user) == -1) {
        workflowProperties.Web.SiteUsers.Add(user, "", "", "");
      }
    }

    private int GetUserIdFromName(SPWeb site, string UserName) {
      SPPrincipalInfo PrincipalInfo;
      PrincipalInfo = SPUtility.ResolvePrincipal(site,
                                                 UserName,
                                                 SPPrincipalType.All,
                                                 SPPrincipalSource.All,
                                                 null,
                                                 false);
      if (PrincipalInfo == null) {
        return -1;
      }
      else {
        return PrincipalInfo.PrincipalId;
      }
    }

    #endregion

  }

}
