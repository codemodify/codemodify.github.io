using System;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Xml.Serialization;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WorkflowActions;

namespace HelloWorkflow {
  public sealed partial class Workflow1 {
    #region Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.CanModifyActivities = true;
      System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
      System.Workflow.ComponentModel.ActivityBind activitybind11 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind12 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind13 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind14 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind15 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind16 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind17 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind18 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind19 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind20 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind22 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind21 = new System.Workflow.ComponentModel.ActivityBind();
      this.logTaskChnaged = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onTaskChanged1 = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
      this.sequenceActivity1 = new System.Workflow.Activities.SequenceActivity();
      this.logCompleted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.whileActivity1 = new System.Workflow.Activities.WhileActivity();
      this.logTaskCreated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onTaskCreated1 = new Microsoft.SharePoint.WorkflowActions.OnTaskCreated();
      this.createTask1 = new Microsoft.SharePoint.WorkflowActions.CreateTask();
      this.logActivated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onWorkflowActivated1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
      // 
      // logTaskChnaged
      // 
      this.logTaskChnaged.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logTaskChnaged.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.TaskModified;
      activitybind1.Name = "Workflow1";
      activitybind1.Path = "HistoryDescription";
      activitybind2.Name = "Workflow1";
      activitybind2.Path = "HistoryOutcome";
      this.logTaskChnaged.Name = "logTaskChnaged";
      this.logTaskChnaged.OtherData = "";
      activitybind3.Name = "Workflow1";
      activitybind3.Path = "userID";
      this.logTaskChnaged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
      this.logTaskChnaged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
      this.logTaskChnaged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
      // 
      // onTaskChanged1
      // 
      activitybind4.Name = "Workflow1";
      activitybind4.Path = "taskAfterProperties";
      activitybind5.Name = "Workflow1";
      activitybind5.Path = "taskBeforeProperties";
      correlationtoken1.Name = "taskToken";
      correlationtoken1.OwnerActivityName = "Workflow1";
      this.onTaskChanged1.CorrelationToken = correlationtoken1;
      activitybind6.Name = "Workflow1";
      activitybind6.Path = "ExecutingUser";
      this.onTaskChanged1.Name = "onTaskChanged1";
      activitybind7.Name = "Workflow1";
      activitybind7.Path = "taskId";
      this.onTaskChanged1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onTaskChanged1_Invoked);
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.BeforePropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
      this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.ExecutorProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
      // 
      // sequenceActivity1
      // 
      this.sequenceActivity1.Activities.Add(this.onTaskChanged1);
      this.sequenceActivity1.Activities.Add(this.logTaskChnaged);
      this.sequenceActivity1.Name = "sequenceActivity1";
      // 
      // logCompleted
      // 
      this.logCompleted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logCompleted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowCompleted;
      activitybind8.Name = "Workflow1";
      activitybind8.Path = "HistoryDescription";
      activitybind9.Name = "Workflow1";
      activitybind9.Path = "HistoryOutcome";
      this.logCompleted.Name = "logCompleted";
      this.logCompleted.OtherData = "";
      activitybind10.Name = "Workflow1";
      activitybind10.Path = "userID";
      this.logCompleted.MethodInvoking += new System.EventHandler(this.logCompleted_MethodInvoking);
      this.logCompleted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
      this.logCompleted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
      this.logCompleted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
      // 
      // whileActivity1
      // 
      this.whileActivity1.Activities.Add(this.sequenceActivity1);
      ruleconditionreference1.ConditionName = "Task Not Completed";
      this.whileActivity1.Condition = ruleconditionreference1;
      this.whileActivity1.Name = "whileActivity1";
      // 
      // logTaskCreated
      // 
      this.logTaskCreated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logTaskCreated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.TaskCreated;
      activitybind11.Name = "Workflow1";
      activitybind11.Path = "HistoryDescription";
      activitybind12.Name = "Workflow1";
      activitybind12.Path = "HistoryOutcome";
      this.logTaskCreated.Name = "logTaskCreated";
      this.logTaskCreated.OtherData = "";
      activitybind13.Name = "Workflow1";
      activitybind13.Path = "userID";
      this.logTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind13)));
      this.logTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind11)));
      this.logTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind12)));
      // 
      // onTaskCreated1
      // 
      activitybind14.Name = "Workflow1";
      activitybind14.Path = "taskAfterProperties";
      this.onTaskCreated1.CorrelationToken = correlationtoken1;
      this.onTaskCreated1.Executor = null;
      this.onTaskCreated1.Name = "onTaskCreated1";
      activitybind15.Name = "Workflow1";
      activitybind15.Path = "taskId";
      this.onTaskCreated1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onTaskCreated1_Invoked);
      this.onTaskCreated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskCreated.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind15)));
      this.onTaskCreated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskCreated.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind14)));
      // 
      // createTask1
      // 
      this.createTask1.CorrelationToken = correlationtoken1;
      this.createTask1.ListItemId = -1;
      this.createTask1.Name = "createTask1";
      this.createTask1.SpecialPermissions = null;
      activitybind16.Name = "Workflow1";
      activitybind16.Path = "taskId";
      activitybind17.Name = "Workflow1";
      activitybind17.Path = "taskProperties";
      this.createTask1.MethodInvoking += new System.EventHandler(this.createTask1_MethodInvoking);
      this.createTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind16)));
      this.createTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind17)));
      // 
      // logActivated
      // 
      this.logActivated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logActivated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowStarted;
      activitybind18.Name = "Workflow1";
      activitybind18.Path = "HistoryDescription";
      activitybind19.Name = "Workflow1";
      activitybind19.Path = "HistoryOutcome";
      this.logActivated.Name = "logActivated";
      this.logActivated.OtherData = "";
      activitybind20.Name = "Workflow1";
      activitybind20.Path = "userID";
      this.logActivated.MethodInvoking += new System.EventHandler(this.logActivated_MethodInvoking);
      this.logActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind18)));
      this.logActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind19)));
      this.logActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.UserIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind20)));
      activitybind22.Name = "Workflow1";
      activitybind22.Path = "workflowId";
      // 
      // onWorkflowActivated1
      // 
      correlationtoken2.Name = "workflowToken";
      correlationtoken2.OwnerActivityName = "Workflow1";
      this.onWorkflowActivated1.CorrelationToken = correlationtoken2;
      this.onWorkflowActivated1.EventName = "OnWorkflowActivated";
      this.onWorkflowActivated1.Name = "onWorkflowActivated1";
      activitybind21.Name = "Workflow1";
      activitybind21.Path = "workflowProperties";
      this.onWorkflowActivated1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onWorkflowActivated1_Invoked);
      this.onWorkflowActivated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind22)));
      this.onWorkflowActivated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind21)));
      // 
      // Workflow1
      // 
      this.Activities.Add(this.onWorkflowActivated1);
      this.Activities.Add(this.logActivated);
      this.Activities.Add(this.createTask1);
      this.Activities.Add(this.onTaskCreated1);
      this.Activities.Add(this.logTaskCreated);
      this.Activities.Add(this.whileActivity1);
      this.Activities.Add(this.logCompleted);
      this.Name = "Workflow1";
      this.CanModifyActivities = false;

    }

    #endregion

    private OnTaskChanged onTaskChanged1;
    private LogToHistoryListActivity logTaskChnaged;
    private LogToHistoryListActivity logCompleted;
    private LogToHistoryListActivity logTaskCreated;
    private SequenceActivity sequenceActivity1;
    private WhileActivity whileActivity1;
    private OnTaskCreated onTaskCreated1;
    private CreateTask createTask1;
    private LogToHistoryListActivity logActivated;
    private OnWorkflowActivated onWorkflowActivated1;






































  }
}
