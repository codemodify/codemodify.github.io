﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write( "Hello World <br/><br/>" );

        const string c_list = "Tasks";

        SPWeb                   webSite         = SPControl.GetContextWeb( Context );
        SPListCollection        listCollection  = webSite.Lists;
        SPList                  list            = listCollection[ c_list ];
        SPListItemCollection    listItems       = list.Items;

        if( 0 != listItems.Count )
        {
            SPListItem          listItem        = listItems[ 0 ];

            Response.Write( "The " + c_list + " ID is: " + list.ID );
            Response.Write( "First item name: " + listItem.Name );
        }
    }
}
