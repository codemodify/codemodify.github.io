﻿using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;

using System.Data;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace WSSWebParts
{
    [Guid("1a95f9e4-9d6e-48e2-bc64-41373cff46cc")]
    public class SiteListWP : System.Web.UI.WebControls.WebParts.WebPart
    {
        protected GridView myGridView = new GridView();

        public SiteListWP()
        {}

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            this.Controls.Add( myGridView );
        }

        protected override void OnLoad( EventArgs e )
        {
            DataTable   dt = new DataTable();
                        dt.Columns.Add( "List Name" );
                        dt.Columns.Add( "Description" );
                        dt.Columns.Add( "Item count", typeof( int ) );
                        dt.Columns.Add( "BaseTemplate" );

            foreach( SPList list in SPContext.Current.Web.Lists )
            {
                DataRow row = dt.NewRow();
                        row[ 0 ] = list.Title;
                        row[ 1 ] = list.Description;
                        row[ 2 ] = list.ItemCount;
                        row[ 3 ] = list.BaseTemplate.ToString();

                dt.Rows.Add( row );
            }

            this.myGridView.DataSource = dt;
            this.myGridView.DataBind();
        } 
    }
}
