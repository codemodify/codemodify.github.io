﻿using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace WebPartFeature
{
    [Guid( "d86830bd-88e8-4834-86e5-16a9d4d3a690" )]
    public class WebPartFeature : System.Web.UI.WebControls.WebParts.WebPart
    {
        public WebPartFeature()
        {
            int breakHere = 0;
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            // TODO: add custom rendering code here.
            // Label label = new Label();
            // label.Text = "Hello World";
            // this.Controls.Add(label);
        }
    }
}
