﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SPWeb web = SPControl.GetContextWeb( Context );
        web.AllowUnsafeUpdates = true;
        SPUserCollection users = web.Users;
        SPUser user = users[ 0 ];
        SPAlertCollection alerts = user.Alerts;
        SPListCollection lists = web.Lists;
        foreach( SPList list in lists )
        {
            Guid guid = alerts.Add( list, Microsoft.SharePoint.SPEventType.All,
            Microsoft.SharePoint.SPAlertFrequency.Immediate );

            SPAlert alert = alerts[ guid ];

            //Can be Custom, List, Item 
            Response.Write( alert.AlertType.ToString() + "<BR>" );

            //The guid of the list if AlertType is List 
            Response.Write( alert.ListID.ToString() + "<BR>" );

            //What event the alert is set to monitor for 
            Response.Write( alert.EventType.ToString() + "<BR>" );
        }

        Response.Write( "Alerts Created!" );
    }
}
