﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {}

    protected void Create_Click( object sender, EventArgs e )
    {
        SPAdminWS.Admin admin = new SPAdminWS.Admin();
                        admin.Timeout     = 20000;
                        admin.Credentials = System.Net.CredentialCache.DefaultCredentials;
                        try
                        {
                            admin.CreateSite( "http://mon_serveur/sites/aaaa",
                                                "MyNewSiteTitle", "MyNewSiteDescription", 1033, "STS",
                                                "training\\administrator", "Administrator",
                                                "Administrator@local.com", "", "" );
                        }
                        catch( Exception ex )
                        {
                            int a = 0;
                        }
    }

    protected void Delete_Click( object sender, EventArgs e )
    {
        SPAdminWS.Admin admin = new SPAdminWS.Admin();
                        admin.Timeout     = 10000;
                        admin.Credentials = System.Net.CredentialCache.DefaultCredentials;
                        admin.DeleteSite( "http://mon_serveur/sites/aaaa " ); 
    }
}
