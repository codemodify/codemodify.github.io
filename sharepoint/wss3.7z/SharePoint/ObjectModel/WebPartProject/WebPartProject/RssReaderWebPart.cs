﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web.Profile;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using System.ComponentModel;
using System.Collections.Specialized;

namespace WebPartProject
{
    public class RssReaderWebPart : System.Web.UI.WebControls.WebParts.WebPart
    {
        Table table;
        private string rssUrl;

        [Personalizable(true)]
        [WebBrowsable()]
        public virtual string RssUrl
        {
            get { return rssUrl; }
            set { rssUrl = value; }
        }

        protected virtual void AddContainer()
        {
            table = new Table();
            table.CellSpacing = 5;

            Controls.Add(table);
        }

        protected virtual void AddItemToContainer(XmlReader reader)
        {
            string link = string.Empty; ;
            string title = string.Empty;
            string description = string.Empty;

            while( reader.Read() )
            {
                if (reader.NodeType == XmlNodeType.Element)
                {
                    if (reader.Name == "link")
                    link = reader.ReadElementContentAsString();

                    else if (reader.Name == "title")
                    title = reader.ReadElementContentAsString();

                    else if (reader.Name == "description")
                    description = reader.ReadElementContentAsString();
                }
            }

            TableRow row = new TableRow();
            table.Rows.Add(row);

            TableCell cell = new TableCell();
            row.Cells.Add(cell);

            HyperLink   hyperLink = new HyperLink();
                        hyperLink.NavigateUrl = link;
                        hyperLink.Text = title;
                        hyperLink.Font.Bold = true;
            cell.Controls.Add(hyperLink);

            LiteralControl lc = new LiteralControl(" < br/ > ");
            cell.Controls.Add(lc);
            
            Label   label = new Label();
                    label.Text = description;

            cell.Controls.Add(label);
        }

        protected override void CreateChildControls()
        {
            Controls.Clear();
            if (string.IsNullOrEmpty(rssUrl))
            {
                ChildControlsCreated = true;
                return;
            }

            using (XmlReader reader = XmlReader.Create(rssUrl))
            {
                AddContainer();
                reader.MoveToContent();
                reader.ReadToDescendant("channel");
                reader.ReadToDescendant("item");
                do
                {
                    using (XmlReader itemReader = reader.ReadSubtree())
                    {
                        AddItemToContainer(itemReader);
                    }
                } while (reader.ReadToNextSibling("item"));
            }

            ChildControlsCreated = true;
        }
    }
}
