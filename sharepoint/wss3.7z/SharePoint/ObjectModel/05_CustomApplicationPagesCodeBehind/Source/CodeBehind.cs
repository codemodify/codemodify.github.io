﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPagesCodeBehind
{
    public class CodeBehind : LayoutsPageBase
    {
        protected Label lblSiteTitle;
        protected Label lblSiteID;

        protected override void OnLoad( EventArgs e )
        {
            SPWeb site = this.Web;

            lblSiteTitle.Text   = site.Title;
            lblSiteID.Text      = site.ID.ToString().ToUpper();
        }

    }
}
