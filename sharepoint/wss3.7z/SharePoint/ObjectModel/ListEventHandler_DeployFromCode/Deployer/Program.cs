﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace Deployer
{
    class Program
    {
        static void Main( string[] args )
        {
            SPSite siteCollection = new SPSite( "http://mon_serveur" );

            SPWeb site = siteCollection.OpenWeb();

            SPList tasksList = site.Lists[ "Tasks" ];

            SPEventReceiverDefinition   eventReceiverDefinition = tasksList.EventReceivers.Add();
                                        eventReceiverDefinition.Class           = "SharePointEventHandlers.ListItemEventHandler";
                                        eventReceiverDefinition.Assembly        = "ListItemEventHandler,Version=1.0.0.0,Culture=neutral,PublicKeyToken=849a467983b41e43";
                                        eventReceiverDefinition.SequenceNumber  = 5000;
                                        eventReceiverDefinition.Type            = SPEventReceiverType.ItemUpdated;
                                        eventReceiverDefinition.Update();
        }
    }
}
