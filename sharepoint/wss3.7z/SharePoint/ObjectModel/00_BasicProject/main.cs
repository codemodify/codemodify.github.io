﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SomethingWtihSharepoint
{
    class Program
    {
        const string c_siteUrl = "http://mon_serveur/aaaa";
        const string c_listName = "bugs";
        const string c_viewName = "All Issues";

        static void Main( string[] args )
        {
            Microsoft.SharePoint.SPSite     site    = new Microsoft.SharePoint.SPSite(c_siteUrl);
            Microsoft.SharePoint.SPWeb      web     = site.OpenWeb();
            Microsoft.SharePoint.SPList     list    = web.Lists[c_listName];
            Microsoft.SharePoint.SPQuery    query   = new Microsoft.SharePoint.SPQuery( list.Views[c_viewName] );

            log( query.ViewXml );


            int breakHere = 0;
        }

        static void log( string data )
        {
            Console.WriteLine( "\n" + data + "\n" );

            System.Diagnostics.Debug.WriteLine("\n" + data + "\n");
        }
    }
}
