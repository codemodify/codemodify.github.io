﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace SharePointEventHandlers
{
    public class ListItemEventReceiver : SPItemEventReceiver
    {
        public override void ItemAdded( SPItemEventProperties properties )
        {
            properties.Cancel = true;
            properties.ErrorMessage = "not allowed";
        }
    }
}
