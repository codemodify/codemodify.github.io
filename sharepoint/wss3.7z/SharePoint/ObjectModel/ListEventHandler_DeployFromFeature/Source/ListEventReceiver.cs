﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace SharePointEventHandlers
{
    public class ListEventReceiver : SPListEventReceiver
    {
        public override void FieldAdding( SPListEventProperties properties ) // before 
        {
            // this has effect
            properties.Cancel = true;
            properties.ErrorMessage = "not allowed";
        }

        public override void FieldAdded( SPListEventProperties properties ) // after
        {
            // this has NO effect
            properties.Cancel = true;
            properties.ErrorMessage = "not allowed";
        }

    }
}
