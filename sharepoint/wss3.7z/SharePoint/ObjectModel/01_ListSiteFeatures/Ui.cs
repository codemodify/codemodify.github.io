﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ListSiteFeatures
{
    public partial class Ui : Form
    {
        public Ui()
        {
            InitializeComponent();
        }

        private string getFeatureEnabled( Microsoft.SharePoint.Administration.SPFeatureDefinition featureDefinition, ref Microsoft.SharePoint.SPSite spSite )
        {
            foreach( Microsoft.SharePoint.SPFeature spFeature in spSite.Features )
            {
                if( spFeature.Definition.Id == featureDefinition.Id )
                    return "Yes";
            }

            return "No";
        }

        private void _getFeaturesButton_Click( object sender, EventArgs e )
        {
            _featureList.Clear();

            Microsoft.SharePoint.SPSite spSite = new Microsoft.SharePoint.SPSite( _siteUrl.Text );

            //string connectionString = @"localhost\OfficeServers;initial catalog=SharePoint_Config_66140120-a9bf-4191-86b6-ec21810ca019;IntegratedSecurity=SSPI;";
            //Microsoft.SharePoint.Administration.SPFarm spFarm = Microsoft.SharePoint.Administration.SPFarm.Open( connectionString );
            Microsoft.SharePoint.Administration.SPFarm spFarm = Microsoft.SharePoint.Administration.SPFarm.Local;

            _status.Text = "Features found: " + spFarm.FeatureDefinitions.Count.ToString();

            foreach( Microsoft.SharePoint.Administration.SPFeatureDefinition featureDefinition in spFarm.FeatureDefinitions )
            {
                string[]    text    = new string[ 2 ];
                            text[0] = featureDefinition.DisplayName;
                            text[1] = getFeatureEnabled( featureDefinition, ref spSite );

                ListViewItem    listViewItem = new ListViewItem( text ); 
                                listViewItem.ForeColor  = featureDefinition.Hidden ? Color.Gray : Color.Black;
                                listViewItem.Tag        = featureDefinition.Id;

                _featureList.Items.Add( listViewItem );
            }
        }
    }
}
