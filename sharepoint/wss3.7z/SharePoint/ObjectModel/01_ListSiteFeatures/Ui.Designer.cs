﻿namespace ListSiteFeatures
{
    partial class Ui
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && (components != null) )
            {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this._siteUrl = new System.Windows.Forms.TextBox();
            this._getFeaturesButton = new System.Windows.Forms.Button();
            this._featureList = new System.Windows.Forms.ListView();
            this._status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point( 9, 9 );
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size( 53, 13 );
            this.label1.TabIndex = 0;
            this.label1.Text = "Site URL:";
            // 
            // _siteUrl
            // 
            this._siteUrl.Location = new System.Drawing.Point( 68, 9 );
            this._siteUrl.Name = "_siteUrl";
            this._siteUrl.Size = new System.Drawing.Size( 248, 20 );
            this._siteUrl.TabIndex = 1;
            // 
            // _getFeaturesButton
            // 
            this._getFeaturesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._getFeaturesButton.Location = new System.Drawing.Point( 322, 9 );
            this._getFeaturesButton.Name = "_getFeaturesButton";
            this._getFeaturesButton.Size = new System.Drawing.Size( 106, 23 );
            this._getFeaturesButton.TabIndex = 2;
            this._getFeaturesButton.Text = "Get Features";
            this._getFeaturesButton.UseVisualStyleBackColor = true;
            this._getFeaturesButton.Click += new System.EventHandler( this._getFeaturesButton_Click );
            // 
            // _featureList
            // 
            this._featureList.LabelEdit = true;
            this._featureList.Location = new System.Drawing.Point( 12, 64 );
            this._featureList.Name = "_featureList";
            this._featureList.Size = new System.Drawing.Size( 416, 197 );
            this._featureList.TabIndex = 3;
            this._featureList.UseCompatibleStateImageBehavior = false;
            this._featureList.View = System.Windows.Forms.View.List;
            // 
            // _status
            // 
            this._status.AutoSize = true;
            this._status.Location = new System.Drawing.Point( 12, 39 );
            this._status.Name = "_status";
            this._status.Size = new System.Drawing.Size( 0, 13 );
            this._status.TabIndex = 4;
            // 
            // Ui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size( 441, 273 );
            this.Controls.Add( this._status );
            this.Controls.Add( this._featureList );
            this.Controls.Add( this._getFeaturesButton );
            this.Controls.Add( this._siteUrl );
            this.Controls.Add( this.label1 );
            this.Name = "Ui";
            this.Text = "Ui";
            this.ResumeLayout( false );
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox _siteUrl;
        private System.Windows.Forms.Button _getFeaturesButton;
        private System.Windows.Forms.ListView _featureList;
        private System.Windows.Forms.Label _status;
    }
}