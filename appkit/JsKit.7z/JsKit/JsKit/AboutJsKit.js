
function aboutJsKit()
{
    var theSlogan = 
        "Create software by feeling it. \n"                                             +
        "\n"                                                                            +
        "Don't rush for copyrights and market-share and sales numbers. \n"              +
        "In case it ends up being something, you will get the bone you was aiming. \n"  +
        "\n"                                                                            +
        "In fact you'll get what is yours any way."

    alert( theSlogan );
}
