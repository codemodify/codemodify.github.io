
JsKit.Core.Byte = function()
{
    this._value = null;
}

JsKit.Core.Byte.prototype.getValue = function()         { return    this._value;            }
JsKit.Core.Byte.prototype.setValue = function( value )  {           this._value = value;    }
