 
defineNamespace( "JsKit.Core" );


includeJsFile( "JsKit/Core/Byte.js" );
//includeJsFile( "JsKit/Core/Int.js" );
//includeJsFile( "JsKit/Core/Float.js" );
includeJsFile( "JsKit/Core/String.js" );

//includeJsFile( "JsKit/Core/Map.js" );
includeJsFile( "JsKit/Core/List.js" );

includeJsFile( "JsKit/Core/DateTime.js" );

//includeJsFile( "JsKit/Core/Timer.js" );

includeJsFile( "JsKit/Core/Thread.js" );

includeJsFile( "JsKit/Core/Application.js" );
