
defineNamespace( "JsKit.Utility" );

includeJsFile( "JsKit/Utility/FileInclusion.js" );
