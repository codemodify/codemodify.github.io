
defineNamespace( "JsKit.Dom" );


includeJsFile( "JsKit/Dom/Node.js" );

includeJsFile( "JsKit/Dom/Static-Methods.js" );
