
defineNamespace( "JsKit.Settings" );


