
defineNamespace( "JsKit.Css" );


includeJsFile( "JsKit/Css/Inline.js" );
includeJsFile( "JsKit/Css/Node.js" );

includeJsFile( "JsKit/Css/Static-Methods.js" );
