
JsKit.Gui.VerticalLayoutManager = function()
{
    this._children = new JsKit.Core.List();
}

JsKit.Gui.VerticalLayoutManager.prototype = new JsKit.Gui.LayoutManager();
