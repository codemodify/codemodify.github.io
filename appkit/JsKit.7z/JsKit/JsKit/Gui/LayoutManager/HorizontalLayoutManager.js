
JsKit.Gui.HorizontalLayoutManager = function()
{
    this._children = new JsKit.Core.List();
}

JsKit.Gui.HorizontalLayoutManager.prototype = new JsKit.Gui.LayoutManager();
